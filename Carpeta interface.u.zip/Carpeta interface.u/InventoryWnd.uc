//================================================================================
// InventoryWnd.
//================================================================================

class InventoryWnd extends UICommonAPI;

var string string_1;
var ItemWindowHandle m_invenItem;
var ItemWindowHandle item_2;
var ItemWindowHandle equipItem[15];
var ItemWindowHandle item_4;
var TextBoxHandle text_1;
var ItemWindowHandle item_5;
var ItemWindowHandle item_6;
var ItemWindowHandle item_7;
var ButtonHandle button_1;
var ButtonHandle button_2;
var ButtonHandle button_3;
var ButtonHandle button_4;
var ButtonHandle button_5;
var EditBoxHandle SearchBox;
var array<int> int_1;
var Vector vector_1;
var array<ItemInfo> info_1;
var array<ItemInfo> info_2;
var array<ItemInfo> AuxInventory;
var bool vvCanUseSetEquipment;
var bool bool_1;
var int int_2;
const CONST_26= 15;
const CONST_25= 14;
const CONST_24= 13;
const CONST_23= 12;
const CONST_22= 11;
const CONST_21= 10;
const CONST_20= 9;
const CONST_19= 8;
const CONST_18= 7;
const CONST_17= 6;
const CONST_16= 5;
const CONST_15= 4;
const CONST_14= 3;
const CONST_13= 2;
const CONST_12= 1;
const CONST_11= 0;
const CONST_10= 10000;
const CONST_9= 9999;
const CONST_8= 8888;
const CONST_7= 7777;
const CONST_6= 6666;
const CONST_5= 5555;
const CONST_4= 4444;
const CONST_3= 3333;
const CONST_2= 2222;
const CONST_1= 1111;

function OnLoad ()
{
	RegisterEvent(2570);
	RegisterEvent(2580);
	RegisterEvent(2590);
	RegisterEvent(2600);
	RegisterEvent(2610);
	RegisterEvent(2620);
	RegisterEvent(2630);
	RegisterEvent(2631);
	RegisterEvent(260);
	RegisterEvent(180);
	RegisterEvent(1710);
	RegisterEvent(260);
	RegisterEvent(150);
	InitHandle();
	function2();
	function3();
	SearchBox = EditBoxHandle(GetHandle("InventoryWnd.SearchBar"));
}

function InitHandle ()
{
	m_invenItem = ItemWindowHandle(GetHandle(StrCat(string_1,".InventoryItem")));
	item_2 = ItemWindowHandle(GetHandle(StrCat(string_1,".QuestItem")));
	item_5 = ItemWindowHandle(GetHandle(StrCat(string_1,".EquipmentItem")));
	item_6 = ItemWindowHandle(GetHandle(StrCat(string_1,".CraftingItem")));
	item_7 = ItemWindowHandle(GetHandle(StrCat(string_1,".SuppliesItem")));
	text_1 = TextBoxHandle(GetHandle(StrCat(string_1,".AdenaText")));
	equipItem[0] = ItemWindowHandle(GetHandle("EquipItem_Underwear"));
	equipItem[1] = ItemWindowHandle(GetHandle("EquipItem_Head"));
	equipItem[2] = ItemWindowHandle(GetHandle("EquipItem_Hair"));
	equipItem[3] = ItemWindowHandle(GetHandle("EquipItem_Hair2"));
	equipItem[4] = ItemWindowHandle(GetHandle("EquipItem_Neck"));
	equipItem[5] = ItemWindowHandle(GetHandle("EquipItem_RHand"));
	equipItem[6] = ItemWindowHandle(GetHandle("EquipItem_Chest"));
	equipItem[7] = ItemWindowHandle(GetHandle("EquipItem_LHand"));
	equipItem[8] = ItemWindowHandle(GetHandle("EquipItem_REar"));
	equipItem[9] = ItemWindowHandle(GetHandle("EquipItem_LEar"));
	equipItem[10] = ItemWindowHandle(GetHandle("EquipItem_Gloves"));
	equipItem[11] = ItemWindowHandle(GetHandle("EquipItem_Legs"));
	equipItem[12] = ItemWindowHandle(GetHandle("EquipItem_Feet"));
	equipItem[13] = ItemWindowHandle(GetHandle("EquipItem_RFinger"));
	equipItem[14] = ItemWindowHandle(GetHandle("EquipItem_LFinger"));
	equipItem[7].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	equipItem[1].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	equipItem[10].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	equipItem[11].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	equipItem[12].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	equipItem[3].SetDisableTex("L2UI.InventoryWnd.Icon_dualcap");
	item_4 = ItemWindowHandle(GetHandle("HennaItem"));
	button_1 = ButtonHandle(GetHandle("InventoryWnd.SortButton"));
	button_2 = ButtonHandle(GetHandle("InventoryWnd.EnchantButton"));
	button_3 = ButtonHandle(GetHandle("InventoryWnd.FastDelete"));
	button_1.SetTooltipCustomType(GetTooltip("Sorting"));
	button_2.SetTooltipCustomType(GetTooltip("Enchant Item"));
	button_3.SetTooltipCustomType(GetTooltip("Fast Item DeletenCtrl + Alt + Click"));
	button_4 = ButtonHandle(GetHandle("InventoryWnd.RefineButton"));
	button_4.SetTooltipCustomType(GetTooltip("Augment Item"));
	button_5 = ButtonHandle(GetHandle("InventoryWnd.TrashButton"));
}

function OnKeyUp (EInputKey nKey)
{
	if ( SearchBox.IsFocused() )
	{
		if ( UnknownFunction122(SearchBox.GetString(),"") )
		{
			RestoreInventory();
			return;
		}
		if ( UnknownFunction151(UnknownFunction125(SearchBox.GetString()),3) )
		{
			FilterInventory(SearchBox.GetString());
		}
	}
}

function CopyInventory ()
{
	local int i;
	local int curItem;
	local ItemInfo auxItem;

	curItem = 0;
	i = 0;
	if ( UnknownFunction150(i,m_invenItem.GetItemNum()) )
	{
		m_invenItem.GetItem(i,auxItem);
		AuxInventory[i] = auxItem;
		UnknownFunction165(i);
		goto JL000E;
	}
}

function RestoreInventory ()
{
	SearchBox.SetString("");
	RequestItemList();
	LoadItemOrder();
	CopyInventory();
}

function FilterInventory (string filterStr)
{
	local ItemInfo item;
	local ItemInfo nullItem;
	local int i;
	local array<ItemInfo> FilteredInventory;
	local int filteredItems;

	if ( UnknownFunction122(filterStr,"") )
	{
		return;
	}
	filteredItems = 0;
	i = 0;
	if ( UnknownFunction150(i,AuxInventory.Length) )
	{
		item = AuxInventory[i];
		if ( UnknownFunction132(UnknownFunction129(IsValidItemID(item)),IsEquipItem(item)) )
		{
			goto JL008B;
		}
		if ( StrContains(filterStr,item.Name) )
		{
			FilteredInventory[UnknownFunction165(filteredItems)] = item;
		}
		UnknownFunction165(i);
		goto JL001C;
	}
	i = 0;
	if ( UnknownFunction150(i,m_invenItem.GetItemNum()) )
	{
		if ( UnknownFunction150(i,filteredItems) )
		{
			m_invenItem.SetItem(i,FilteredInventory[i]);
		} else {
			m_invenItem.SetItem(i,nullItem);
		}
		UnknownFunction165(i);
		goto JL009C;
	}
}

function OnEvent (int Event_ID, string param)
{
	switch (Event_ID)
	{
		case 2570:
		HandleClear();
		break;
		case 2580:
		HandleOpenWindow();
		break;
		case 2590:
		HandleHideWindow();
		break;
		case 2600:
		function30(param);
		break;
		case 2610:
		HandleUpdateItem(param);
		break;
		case 2620:
		HandleItemListEnd();
		break;
		case 2630:
		function37(param);
		break;
		case 260:
		HandleUpdateHennaInfo(param);
		break;
		case 2631:
		HandleToggleWindow();
		break;
		case 1710:
		HandleDialogOK();
		break;
		case 180:
		HandleUpdateUserInfo();
		break;
		case 260:
		HandleUpdateHennaInfo(param);
		case 150:
		HandleGamingStateEnter();
		break;
		default:
		break;
	}
}

function OnShow ()
{
	if ( Class'UIDATA_PLAYER'.HasCrystallizeAbility() )
	{
		ShowWindow(StrCat(string_1,".CrystallizeButton"));
	} else {
		HideWindow(StrCat(string_1,".CrystallizeButton"));
	}
	SetAdenaText();
	SetItemCount();
	UpdateHennaInfo();
	Class'UIAPI_WINDOW'.ShowWindow("InventoryWnd.SortButton");
	SetFocus();
	SearchBox.SetString("");
	SearchBox.ReleaseFocus();
	CopyInventory();
}

function OnHide ()
{
	SaveItemOrder();
}

function HandleGamingStateEnter ()
{
	();
}

function OnDBClickItemWithHandle (ItemWindowHandle handle_1, int int_4)
{
	if (! LogicalAND(IsKeyDown(18),IsKeyDown(17)) ) goto JL0019;
	UseItem(handle_1,int_4);
}

function OnRClickItemWithHandle (ItemWindowHandle handle_2, int int_4)
{
	UseItem(handle_2,int_4);
}

function OnClickButton (string string_3)
{
	switch (string_3)
	{
		case "SortButton":
		SortItem();
		break;
		case "BtnClose":
		Class'UIAPI_WINDOW'.HideWindow("InventoryWnd");
		break;
		case "CancelBar":
		RestoreInventory();
		break;
		case "BtnMin":
		Class'UIAPI_WINDOW'.Iconize("InventoryWnd","Was.Icon_df_MenuWnd_Inventory",195);
		break;
		case "RefineButton":
		if ( NotBool(IsShowWindow("AugmentationWnd")) )
		{
			Class'UIAPI_WINDOW'.ShowWindow("AugmentationWnd");
			Class'UIAPI_WINDOW'.SetFocus("AugmentationWnd");
		} else {
			Class'UIAPI_WINDOW'.HideWindow("AugmentationWnd");
		}
		break;
		case "TrashButton":
		function13();
		break;
		case "BtnExpand":
		if ( BoolEquals(GetOptionBool("Options","ExpandedInventory"),True) )
		{
			SetOptionBool("Options","ExpandedInventory",False);
		} else {
			SetOptionBool("Options","ExpandedInventory",True);
		}
		function3();
		break;
		default:
	}
}

function SortItem ()
{
	local int i;
	local int j;
	local int invenLimit;
	local ItemInfo item;
	local EItemType EItemType;
	local int numAsset;
	local int numWeapon;
	local int numArmor;
	local int numAccessary;
	local int numEtcItem;
	local int numAncientCrystalEnchantAm;
	local int numAncientCrystalEnchantWp;
	local int numCrystalEnchantAm;
	local int numCrystalEnchantWp;
	local int numBlessEnchantAm;
	local int numBlessEnchantWp;
	local int numEnchantAm;
	local int numEnchantWp;
	local int numIncEnchantPropAm;
	local int numIncEnchantPropWp;
	local int numPotion;
	local int numElixir;
	local int numArrow;
	local int numBolt;
	local int numRecipe;
	local int nextSlot;
	local int testInt;
	local array<ItemInfo> AssetList;
	local array<ItemInfo> WeaponList;
	local array<ItemInfo> ArmorList;
	local array<ItemInfo> AccesaryList;
	local array<ItemInfo> EtcItemList;
	local array<ItemInfo> AncientCrystalEnchantAmList;
	local array<ItemInfo> AncientCrystalEnchantWpList;
	local array<ItemInfo> CrystalEnchantAmList;
	local array<ItemInfo> CrystalEnchantWpList;
	local array<ItemInfo> BlessEnchantAmList;
	local array<ItemInfo> BlessEnchantWpList;
	local array<ItemInfo> EnchantAmList;
	local array<ItemInfo> EnchantWpList;
	local array<ItemInfo> IncEnchantPropAmList;
	local array<ItemInfo> IncEnchantPropWpList;
	local array<ItemInfo> PotionList;
	local array<ItemInfo> ElixirList;
	local array<ItemInfo> ArrowList;
	local array<ItemInfo> BoltList;
	local array<ItemInfo> RecipeList;
	local ItemInfo temp;

	Debug("Sorting Inven Item");
	numAsset = 0;
	numWeapon = 0;
	numArmor = 0;
	numAccessary = 0;
	numPotion = 0;
	numEtcItem = 0;
	numAncientCrystalEnchantAm = 0;
	numAncientCrystalEnchantWp = 0;
	numCrystalEnchantAm = 0;
	numCrystalEnchantWp = 0;
	numBlessEnchantAm = 0;
	numBlessEnchantWp = 0;
	numIncEnchantPropAm = 0;
	numIncEnchantPropWp = 0;
	numEnchantAm = 0;
	numEnchantWp = 0;
	numPotion = 0;
	numElixir = 0;
	numArrow = 0;
	numBolt = 0;
	numRecipe = 0;
	nextSlot = 0;
	invenLimit = m_invenItem.GetItemNum();
	i = 0;
	if ( UnknownFunction150(i,invenLimit) )
	{
		m_invenItem.GetItem(i,item);
		if ( UnknownFunction129(IsValidItemID(item)) )
		{
			goto JL0376;
		}
		EItemType = item.ItemType;
		switch (EItemType)
		{
			case 4:
			AssetList[numAsset] = item;
			numAsset = UnknownFunction146(numAsset,1);
			break;
			case 0:
			WeaponList[numWeapon] = item;
			numWeapon = UnknownFunction146(numWeapon,1);
			break;
			case 1:
			ArmorList[numArmor] = item;
			numArmor = UnknownFunction146(numArmor,1);
			break;
			case 2:
			AccesaryList[numAccessary] = item;
			numAccessary = UnknownFunction146(numAccessary,1);
			break;
			case 5:
			testInt = item.ItemSubType;
			switch (item.ItemSubType)
			{
				case 22:
				BlessEnchantAmList[numBlessEnchantAm] = item;
				numBlessEnchantAm = UnknownFunction146(numBlessEnchantAm,1);
				break;
				case 21:
				BlessEnchantWpList[numBlessEnchantWp] = item;
				numBlessEnchantWp = UnknownFunction146(numBlessEnchantWp,1);
				break;
				case 20:
				EnchantAmList[numEnchantAm] = item;
				numEnchantAm = UnknownFunction146(numEnchantAm,1);
				break;
				case 19:
				EnchantWpList[numEnchantWp] = item;
				numEnchantWp = UnknownFunction146(numEnchantWp,1);
				break;
				case 3:
				PotionList[numPotion] = item;
				numPotion = UnknownFunction146(numPotion,1);
				break;
				case 24:
				ElixirList[numElixir] = item;
				numElixir = UnknownFunction146(numElixir,1);
				break;
				case 2:
				ArrowList[numArrow] = item;
				numArrow = UnknownFunction146(numArrow,1);
				break;
				case 5:
				RecipeList[numRecipe] = item;
				numRecipe = UnknownFunction146(numRecipe,1);
				break;
				default:
				EtcItemList[numEtcItem] = item;
				numEtcItem = UnknownFunction146(numEtcItem,1);
				break;
			}
			break;
			default:
			Debug("huh???");
			EtcItemList[numEtcItem] = item;
			numEtcItem = UnknownFunction146(numEtcItem,1);
			break;
		}
		UnknownFunction163(i);
		goto JL00D0;
	}
	i = 0;
	if ( UnknownFunction150(i,numAsset) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numAsset,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numAsset,1)) )
			{
				if ( UnknownFunction150(AssetList[j].Weight,AssetList[UnknownFunction146(j,1)].Weight) )
				{
					temp = AssetList[j];
					AssetList[j] = AssetList[UnknownFunction146(j,1)];
					AssetList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL039D;
		}
		UnknownFunction163(i);
		goto JL0387;
	}
	i = 0;
	if ( UnknownFunction150(i,numWeapon) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numWeapon,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numWeapon,1)) )
			{
				if ( UnknownFunction150(WeaponList[j].Weight,WeaponList[UnknownFunction146(j,1)].Weight) )
				{
					temp = WeaponList[j];
					WeaponList[j] = WeaponList[UnknownFunction146(j,1)];
					WeaponList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL045D;
		}
		UnknownFunction163(i);
		goto JL0447;
	}
	i = 0;
	if ( UnknownFunction150(i,numArmor) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numArmor,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numArmor,1)) )
			{
				if ( UnknownFunction150(ArmorList[j].Weight,ArmorList[UnknownFunction146(j,1)].Weight) )
				{
					temp = ArmorList[j];
					ArmorList[j] = ArmorList[UnknownFunction146(j,1)];
					ArmorList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL051D;
		}
		UnknownFunction163(i);
		goto JL0507;
	}
	i = 0;
	if ( UnknownFunction150(i,numAccessary) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numAccessary,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numAccessary,1)) )
			{
				if ( UnknownFunction150(AccesaryList[j].Weight,AccesaryList[UnknownFunction146(j,1)].Weight) )
				{
					temp = AccesaryList[j];
					AccesaryList[j] = AccesaryList[UnknownFunction146(j,1)];
					AccesaryList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL05DD;
		}
		UnknownFunction163(i);
		goto JL05C7;
	}
	i = 0;
	if ( UnknownFunction150(i,numAncientCrystalEnchantAm) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numAncientCrystalEnchantAm,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numAncientCrystalEnchantAm,1)) )
			{
				if ( UnknownFunction150(AncientCrystalEnchantAmList[j].Weight,AncientCrystalEnchantAmList[UnknownFunction146(j,1)].Weight) )
				{
					temp = AncientCrystalEnchantAmList[j];
					AncientCrystalEnchantAmList[j] = AncientCrystalEnchantAmList[UnknownFunction146(j,1)];
					AncientCrystalEnchantAmList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL069D;
		}
		UnknownFunction163(i);
		goto JL0687;
	}
	i = 0;
	if ( UnknownFunction150(i,numAncientCrystalEnchantWp) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numAncientCrystalEnchantWp,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numAncientCrystalEnchantWp,1)) )
			{
				if ( UnknownFunction150(AncientCrystalEnchantWpList[j].Weight,AncientCrystalEnchantWpList[UnknownFunction146(j,1)].Weight) )
				{
					temp = AncientCrystalEnchantWpList[j];
					AncientCrystalEnchantWpList[j] = AncientCrystalEnchantWpList[UnknownFunction146(j,1)];
					AncientCrystalEnchantWpList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL075D;
		}
		UnknownFunction163(i);
		goto JL0747;
	}
	i = 0;
	if ( UnknownFunction150(i,numCrystalEnchantAm) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numCrystalEnchantAm,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numCrystalEnchantAm,1)) )
			{
				if ( UnknownFunction150(CrystalEnchantAmList[j].Weight,CrystalEnchantAmList[UnknownFunction146(j,1)].Weight) )
				{
					temp = CrystalEnchantAmList[j];
					CrystalEnchantAmList[j] = CrystalEnchantAmList[UnknownFunction146(j,1)];
					CrystalEnchantAmList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL081D;
		}
		UnknownFunction163(i);
		goto JL0807;
	}
	i = 0;
	if ( UnknownFunction150(i,numCrystalEnchantWp) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numCrystalEnchantWp,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numCrystalEnchantWp,1)) )
			{
				if ( UnknownFunction150(CrystalEnchantWpList[j].Weight,CrystalEnchantWpList[UnknownFunction146(j,1)].Weight) )
				{
					temp = CrystalEnchantWpList[j];
					CrystalEnchantWpList[j] = CrystalEnchantWpList[UnknownFunction146(j,1)];
					CrystalEnchantWpList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL08DD;
		}
		UnknownFunction163(i);
		goto JL08C7;
	}
	i = 0;
	if ( UnknownFunction150(i,numBlessEnchantAm) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numBlessEnchantAm,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numBlessEnchantAm,1)) )
			{
				if ( UnknownFunction150(BlessEnchantAmList[j].Weight,BlessEnchantAmList[UnknownFunction146(j,1)].Weight) )
				{
					temp = BlessEnchantAmList[j];
					BlessEnchantAmList[j] = BlessEnchantAmList[UnknownFunction146(j,1)];
					BlessEnchantAmList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL099D;
		}
		UnknownFunction163(i);
		goto JL0987;
	}
	i = 0;
	if ( UnknownFunction150(i,numBlessEnchantWp) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numBlessEnchantWp,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numBlessEnchantWp,1)) )
			{
				if ( UnknownFunction150(BlessEnchantWpList[j].Weight,BlessEnchantWpList[UnknownFunction146(j,1)].Weight) )
				{
					temp = BlessEnchantWpList[j];
					BlessEnchantWpList[j] = BlessEnchantWpList[UnknownFunction146(j,1)];
					BlessEnchantWpList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
JL075D:
			goto JL0A5D;
		}
		UnknownFunction163(i);
		goto JL0A47;
	}
	i = 0;
	if ( UnknownFunction150(i,numEnchantAm) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numEnchantAm,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numEnchantAm,1)) )
			{
				if ( UnknownFunction150(EnchantAmList[j].Weight,EnchantAmList[UnknownFunction146(j,1)].Weight) )
				{
					temp = EnchantAmList[j];
					EnchantAmList[j] = EnchantAmList[UnknownFunction146(j,1)];
					EnchantAmList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0B1D;
		}
		UnknownFunction163(i);
		goto JL0B07;
	}
	i = 0;
	if ( UnknownFunction150(i,numEnchantWp) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numEnchantWp,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numEnchantWp,1)) )
			{
				if ( UnknownFunction150(EnchantWpList[j].Weight,EnchantWpList[UnknownFunction146(j,1)].Weight) )
				{
					temp = EnchantWpList[j];
					EnchantWpList[j] = EnchantWpList[UnknownFunction146(j,1)];
					EnchantWpList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0BDD;
		}
		UnknownFunction163(i);
		goto JL0BC7;
	}
	i = 0;
	if ( UnknownFunction150(i,numIncEnchantPropAm) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numIncEnchantPropAm,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numIncEnchantPropAm,1)) )
			{
				if ( UnknownFunction150(IncEnchantPropAmList[j].Weight,IncEnchantPropAmList[UnknownFunction146(j,1)].Weight) )
				{
					temp = IncEnchantPropAmList[j];
					IncEnchantPropAmList[j] = IncEnchantPropAmList[UnknownFunction146(j,1)];
					IncEnchantPropAmList[UnknownFunction146(j,1)] = temp;
				}
			}
JL08C7:
			UnknownFunction163(j);
			goto JL0C9D;
		}
		UnknownFunction163(i);
		goto JL0C87;
	}
	i = 0;
	if ( UnknownFunction150(i,numIncEnchantPropWp) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numIncEnchantPropWp,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numIncEnchantPropWp,1)) )
			{
				if ( UnknownFunction150(IncEnchantPropWpList[j].Weight,IncEnchantPropWpList[UnknownFunction146(j,1)].Weight) )
				{
					temp = IncEnchantPropWpList[j];
					IncEnchantPropWpList[j] = IncEnchantPropWpList[UnknownFunction146(j,1)];
					IncEnchantPropWpList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0D5D;
		}
		UnknownFunction163(i);
		goto JL0D47;
	}
	i = 0;
	if ( UnknownFunction150(i,numPotion) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numPotion,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numPotion,1)) )
			{
				if ( UnknownFunction150(PotionList[j].Weight,PotionList[UnknownFunction146(j,1)].Weight) )
				{
					temp = PotionList[j];
					PotionList[j] = PotionList[UnknownFunction146(j,1)];
					PotionList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0E1D;
		}
		UnknownFunction163(i);
		goto JL0E07;
	}
	i = 0;
	if ( UnknownFunction150(i,numElixir) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numElixir,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numElixir,1)) )
			{
				if ( UnknownFunction150(ElixirList[j].Weight,ElixirList[UnknownFunction146(j,1)].Weight) )
				{
					temp = ElixirList[j];
					ElixirList[j] = ElixirList[UnknownFunction146(j,1)];
					ElixirList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0EDD;
		}
		UnknownFunction163(i);
		goto JL0EC7;
	}
	i = 0;
JL0A47:
	if ( UnknownFunction150(i,numArrow) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numArrow,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numArrow,1)) )
			{
				if ( UnknownFunction150(ArrowList[j].Weight,ArrowList[UnknownFunction146(j,1)].Weight) )
				{
					temp = ArrowList[j];
					ArrowList[j] = ArrowList[UnknownFunction146(j,1)];
					ArrowList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL0F9D;
		}
		UnknownFunction163(i);
		goto JL0F87;
	}
	i = 0;
	if ( UnknownFunction150(i,numBolt) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numBolt,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numBolt,1)) )
			{
				if ( UnknownFunction150(BoltList[j].Weight,BoltList[UnknownFunction146(j,1)].Weight) )
				{
					temp = BoltList[j];
					BoltList[j] = BoltList[UnknownFunction146(j,1)];
JL0B1D:
					BoltList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL105D;
		}
		UnknownFunction163(i);
		goto JL1047;
	}
	i = 0;
	if ( UnknownFunction150(i,numRecipe) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numRecipe,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numRecipe,1)) )
			{
				if ( UnknownFunction150(RecipeList[j].Weight,RecipeList[UnknownFunction146(j,1)].Weight) )
				{
					temp = BoltList[j];
					RecipeList[j] = RecipeList[UnknownFunction146(j,1)];
					RecipeList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL111D;
		}
		UnknownFunction163(i);
		goto JL1107;
	}
	i = 0;
	if ( UnknownFunction150(i,numEtcItem) )
	{
		j = 0;
		if ( UnknownFunction150(j,UnknownFunction147(numEtcItem,i)) )
		{
			if ( UnknownFunction150(j,UnknownFunction147(numEtcItem,1)) )
			{
				if ( UnknownFunction150(EtcItemList[j].Weight,EtcItemList[UnknownFunction146(j,1)].Weight) )
				{
					temp = EtcItemList[j];
					EtcItemList[j] = EtcItemList[UnknownFunction146(j,1)];
					EtcItemList[UnknownFunction146(j,1)] = temp;
				}
			}
			UnknownFunction163(j);
			goto JL11DD;
		}
		UnknownFunction163(i);
		goto JL11C7;
	}
	i = 0;
	if ( UnknownFunction150(i,numAsset) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),AssetList[i]);
		UnknownFunction163(i);
		goto JL1287;
	}
	nextSlot = UnknownFunction146(nextSlot,numAsset);
	i = 0;
	if ( UnknownFunction150(i,numWeapon) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),WeaponList[i]);
		UnknownFunction163(i);
		goto JL12DF;
	}
	nextSlot = UnknownFunction146(nextSlot,numWeapon);
	i = 0;
	if ( UnknownFunction150(i,numArmor) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),ArmorList[i]);
		UnknownFunction163(i);
		goto JL1337;
	}
	nextSlot = UnknownFunction146(nextSlot,numArmor);
	i = 0;
	if ( UnknownFunction150(i,numAccessary) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),AccesaryList[i]);
		UnknownFunction163(i);
		goto JL138F;
	}
	nextSlot = UnknownFunction146(nextSlot,numAccessary);
	i = 0;
	if ( UnknownFunction150(i,numCrystalEnchantAm) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),CrystalEnchantAmList[i]);
		UnknownFunction163(i);
		goto JL13E7;
	}
	nextSlot = UnknownFunction146(nextSlot,numCrystalEnchantAm);
	i = 0;
	if ( UnknownFunction150(i,numCrystalEnchantWp) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),CrystalEnchantWpList[i]);
		UnknownFunction163(i);
		goto JL143F;
	}
	nextSlot = UnknownFunction146(nextSlot,numCrystalEnchantWp);
	i = 0;
	if ( UnknownFunction150(i,numBlessEnchantAm) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),BlessEnchantAmList[i]);
		UnknownFunction163(i);
		goto JL1497;
	}
	nextSlot = UnknownFunction146(nextSlot,numBlessEnchantAm);
	i = 0;
	if ( UnknownFunction150(i,numBlessEnchantWp) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),BlessEnchantWpList[i]);
		UnknownFunction163(i);
		goto JL14EF;
	}
	nextSlot = UnknownFunction146(nextSlot,numBlessEnchantWp);
	i = 0;
	if ( UnknownFunction150(i,numEnchantAm) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),EnchantAmList[i]);
		UnknownFunction163(i);
		goto JL1547;
	}
	nextSlot = UnknownFunction146(nextSlot,numEnchantAm);
	i = 0;
	if ( UnknownFunction150(i,numEnchantWp) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),EnchantWpList[i]);
		UnknownFunction163(i);
		goto JL159F;
	}
	nextSlot = UnknownFunction146(nextSlot,numEnchantWp);
	i = 0;
	if ( UnknownFunction150(i,numPotion) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),PotionList[i]);
		UnknownFunction163(i);
		goto JL15F7;
	}
	nextSlot = UnknownFunction146(nextSlot,numPotion);
	i = 0;
	if ( UnknownFunction150(i,numElixir) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),ElixirList[i]);
		UnknownFunction163(i);
		goto JL164F;
	}
	nextSlot = UnknownFunction146(nextSlot,numElixir);
	i = 0;
	if ( UnknownFunction150(i,numArrow) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),ArrowList[i]);
		UnknownFunction163(i);
		goto JL16A7;
	}
	nextSlot = UnknownFunction146(nextSlot,numArrow);
	i = 0;
	if ( UnknownFunction150(i,numRecipe) )
	{
JL0EDD:
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),RecipeList[i]);
		UnknownFunction163(i);
		goto JL16FF;
	}
	nextSlot = UnknownFunction146(nextSlot,numRecipe);
	i = 0;
	if ( UnknownFunction150(i,numEtcItem) )
	{
		m_invenItem.SetItem(UnknownFunction146(nextSlot,i),EtcItemList[i]);
		UnknownFunction163(i);
		goto JL1757;
	}
	nextSlot = UnknownFunction146(nextSlot,numEtcItem);
}

function OnSelectItemWithHandle (ItemWindowHandle item_10, int int_5)
{
	local int int_6;
	local string string_4;
	local ItemInfo info_3;

	string_4 = Class'UIAPI_EDITBOX'.GetString("ChatWnd.ChatEditBox");
	if ( LogicalAND(IsKeyDown(18),IsKeyDown(17)) )
	{
		item_10.GetSelectedItem(info_3);
		RequestDestroyItem(info_3.ServerID,info_3.ItemNum);
	}
	if ( LogicalAND(IsKeyDown(162),NotBool(IsKeyDown(18))) )
	{
		item_10.GetSelectedItem(info_3);
		function14(info_3);
	}
	if ( IsKeyDown(16) )
	{
		item_10.GetSelectedItem(info_3);
		if ( GreaterThan(info_3.ItemNum,1) )
		{
			SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"("),string(info_3.ItemNum)),") "));
		} else {
			if ( Equals(info_3.ItemType,0) )
			{
				if ( LogicalAND(NotEquals(info_3.AdditionalName,""),GreaterThan(info_3.Enchanted,0)) )
				{
					SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"+"),string(info_3.Enchanted)),"")," ("),info_3.AdditionalName),") "));
				} else {
					if ( GreaterThan(info_3.Enchanted,0) )
					{
						SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"+"),string(info_3.Enchanted))," "));
					} else {
						if ( NotEquals(info_3.AdditionalName,"") )
						{
							SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"("),info_3.AdditionalName),") "));
						} else {
							SetChatMessage(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "));
						}
					}
				}
			} else {
				if ( LogicalOR(Equals(info_3.ItemType,1),Equals(info_3.ItemType,2)) )
				{
					if ( LogicalAND(NotEquals(info_3.AdditionalName,""),GreaterThan(info_3.Enchanted,0)) )
					{
						SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"+"),string(info_3.Enchanted)),"")," ("),info_3.AdditionalName),") "));
					} else {
						if ( GreaterThan(info_3.Enchanted,0) )
						{
							SetChatMessage(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "),"+"),string(info_3.Enchanted))," "));
						} else {
							SetChatMessage(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "));
						}
					}
				} else {
					SetChatMessage(StrCat(StrCat(StrCat(StrCat("",string_4),""),info_3.Name)," "));
				}
			}
		}
		Class'UIAPI_WINDOW'.SetFocus("ChatWnd.ChatEditBox");
	}
	if ( LogicalOR(LogicalOR(LogicalOR(ItemWindowEquals(item_10,m_invenItem),ItemWindowEquals(item_10,item_5)),ItemWindowEquals(item_10,item_6)),ItemWindowEquals(item_10,item_7)) )
	{
		return;
	}
	if ( ItemWindowEquals(item_10,item_2) )
	{
		return;
	}
	int_6 = 0;
	if ( UnknownFunction150(int_6,15) )
	{
		if ( UnknownFunction119(item_10,equipItem[int_6]) )
		{
			equipItem[int_6].ClearSelect();
		}
		UnknownFunction165(int_6);
		goto JL0558;
	}
}

function OnDropItem (string string_5, ItemInfo info_3, int X, int Y)
{
	local int int_7;
	local int int_8;
	local int int_6;
	local int string_4;

	if ( UnknownFunction129(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(info_3.DragSrcName,"EquipmentItem"),UnknownFunction122(info_3.DragSrcName,"CraftingItem")),UnknownFunction122(info_3.DragSrcName,"SuppliesItem")),UnknownFunction122(info_3.DragSrcName,"InventoryItem")),UnknownFunction122(info_3.DragSrcName,"QuestItem")),UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem"))),UnknownFunction122(info_3.DragSrcName,"PetInvenWnd"))) )
	{
		return;
	}
	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(string_5,"InventoryItem"),UnknownFunction122(string_5,"EquipmentItem")),UnknownFunction122(string_5,"CraftingItem")),UnknownFunction122(string_5,"SuppliesItem")) )
	{
		if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(info_3.DragSrcName,"InventoryItem"),UnknownFunction122(info_3.DragSrcName,"EquipmentItem")),UnknownFunction122(info_3.DragSrcName,"CraftingItem")),UnknownFunction122(info_3.DragSrcName,"SuppliesItem")) )
		{
			int_7 = GetCurrentTab().GetIndexAt(X,Y,1,1);
			if ( UnknownFunction153(int_7,0) )
			{
				int_8 = GetCurrentTab().FindItemWithServerID(info_3.ServerID);
				if ( UnknownFunction155(int_7,int_8) )
				{
					if ( UnknownFunction150(int_8,int_7) )
					{
						GetCurrentTab().SwapItems(int_8,UnknownFunction146(int_8,1));
						UnknownFunction163(int_8);
						goto JL021D;
					}
					if ( UnknownFunction150(int_7,int_8) )
					{
						GetCurrentTab().SwapItems(int_8,UnknownFunction147(int_8,1));
						UnknownFunction164(int_8);
						goto JL0253;
					}
				}
			} else {
				int_8 = GetCurrentTab().GetItemNum();
				if ( UnknownFunction150(int_7,UnknownFunction147(int_8,1)) )
				{
					GetCurrentTab().SwapItems(int_7,UnknownFunction146(int_7,1));
					UnknownFunction163(int_7);
					goto JL02A2;
				}
			}
		} else {
			if ( UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem")) )
			{
				RequestUnequipItem(info_3.ServerID,info_3.SlotBitType);
				RestoreInventory();
			} else {
				if ( StrEquals(info_3.DragSrcName,"PetInvenWnd") )
				{
					if ( LogicalAND(IsStackableItem(info_3.ConsumeType),GreaterThan(info_3.ItemNum,1)) )
					{
						if ( GreaterThan(info_3.AllItemCount,0) )
						{
							if ( CheckItemLimit(info_3.ClassID,info_3.AllItemCount) )
							{
								Class'PetAPI'.RequestGetItemFromPet(info_3.ServerID,info_3.AllItemCount,False);
							}
						} else {
							DialogSetID(10000);
							DialogSetReservedInt(info_3.ServerID);
							DialogSetParamInt(info_3.ItemNum);
							DialogShow(6,MakeFullSystemMsg(GetSystemMessage(72),info_3.Name));
						}
					} else {
						Class'PetAPI'.RequestGetItemFromPet(info_3.ServerID,1,False);
					}
				}
			}
		}
	} else {
		if ( StrEquals(string_5,"QuestItem") )
		{
			if ( StrEquals(info_3.DragSrcName,"QuestItem") )
			{
				int_7 = item_2.GetIndexAt(X,Y,1,1);
				if ( UnknownFunction153(int_7,0) )
				{
					int_8 = item_2.FindItemWithServerID(info_3.ServerID);
					if ( UnknownFunction155(int_7,int_8) )
					{
						if ( UnknownFunction150(int_8,int_7) )
						{
							item_2.SwapItems(int_8,UnknownFunction146(int_8,1));
							UnknownFunction163(int_8);
							goto JL04C1;
						}
						if ( UnknownFunction150(int_7,int_8) )
						{
							item_2.SwapItems(int_8,UnknownFunction147(int_8,1));
							UnknownFunction164(int_8);
							goto JL04F6;
						}
					}
				} else {
					int_8 = m_invenItem.GetItemNum();
					if ( UnknownFunction150(int_7,UnknownFunction147(int_8,1)) )
					{
						m_invenItem.SwapItems(int_7,UnknownFunction146(int_7,1));
						UnknownFunction163(int_7);
						goto JL0543;
					}
				}
			}
		} else {
			if ( UnknownFunction155(-1,UnknownFunction126(string_5,"EquipItem")) )
			{
				if ( StrEquals(info_3.DragSrcName,"PetInvenWnd") )
				{
					Class'PetAPI'.RequestGetItemFromPet(info_3.ServerID,1,True);
				} else {
					if ( UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem")) )
					{
						goto JL0621;
					}
					if ( IntNotEquals(info_3.ItemType,5) )
					{
						RequestUseItem(info_3.ServerID);
					}
				}
			} else {
				if ( UnknownFunction122(string_5,"TrashButton") )
				{
					if ( bool_1 )
					{
						int_6 = 1;
						if ( UnknownFunction150(int_6,100) )
						{
							GetINIInt("TrashList",StrCat("",string(int_6)),string_4,"TrashGrp");
							if ( Equals(string_4,info_3.ClassID) )
							{
								return;
							}
							UnknownFunction165(int_6);
							goto JL064B;
						}
						SetINIInt("TrashList",string(DoAdd(int_2,1)),info_3.ClassID,"TrashGrp");
						SetINIInt("TrashList",string(DoAdd(int_2,2)),0,"TrashGrp");
						IntIncrement(int_2);
					}
					if ( UnknownFunction130(IsStackableItem(info_3.ConsumeType),UnknownFunction151(info_3.ItemNum,1)) )
					{
						if ( GreaterThan(info_3.AllItemCount,0) )
						{
							DialogSetID(7777);
							DialogSetReservedInt(info_3.ServerID);
							DialogSetReservedInt2(info_3.AllItemCount);
							DialogShow(4,MakeFullSystemMsg(GetSystemMessage(74),info_3.Name,""));
						} else {
							DialogSetID(8888);
							DialogSetReservedInt(info_3.ServerID);
							DialogSetParamInt(info_3.ItemNum);
							DialogShow(6,MakeFullSystemMsg(GetSystemMessage(73),info_3.Name));
						}
					} else {
						DialogSetID(6666);
						DialogSetReservedInt(info_3.ServerID);
						DialogShow(4,MakeFullSystemMsg(GetSystemMessage(74),info_3.Name));
					}
				} else {
					if ( StrEquals(string_5,"CrystallizeButton") )
					{
						if ( LogicalOR(StrEquals(info_3.DragSrcName,"InventoryItem"),UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem"))) )
						{
							if ( LogicalAND(Class'UIDATA_PLAYER'.HasCrystallizeAbility(),Class'UIDATA_ITEM'.IsCrystallizable(info_3.ClassID)) )
							{
								DialogSetID(9999);
								DialogSetReservedInt(info_3.ServerID);
								DialogShow(4,MakeFullSystemMsg(GetSystemMessage(336),info_3.Name));
							}
						}
					}
				}
			}
		}
	}
}

function OnDropItemSource (string string_5, ItemInfo info_3)
{
	if ( StrEquals(string_5,"Console") )
	{
		if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(info_3.DragSrcName,"InventoryItem"),UnknownFunction122(info_3.DragSrcName,"QuestItem")),UnknownFunction122(info_3.DragSrcName,"EquipmentItem")),UnknownFunction122(info_3.DragSrcName,"SuppliesItem")),UnknownFunction122(info_3.DragSrcName,"CraftingItem")),UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem"))) )
		{
			vector_1 = GetClickLocation();
			if ( LogicalAND(IsStackableItem(info_3.ConsumeType),GreaterThan(info_3.ItemNum,1)) )
			{
				if ( GreaterThan(info_3.AllItemCount,0) )
				{
					DialogHide();
					DialogSetID(5555);
					DialogSetReservedInt(info_3.ServerID);
					DialogSetReservedInt2(info_3.AllItemCount);
					DialogShow(4,MakeFullSystemMsg(GetSystemMessage(1833),info_3.Name,""));
				} else {
					DialogHide();
					DialogSetID(4444);
					DialogSetReservedInt(info_3.ServerID);
					DialogSetParamInt(info_3.ItemNum);
					DialogShow(6,MakeFullSystemMsg(GetSystemMessage(71),info_3.Name,""));
				}
			} else {
				DialogHide();
				DialogSetID(3333);
				DialogSetReservedInt(info_3.ServerID);
				DialogShow(4,MakeFullSystemMsg(GetSystemMessage(400),info_3.Name,""));
			}
		}
	} else {
		if ( LogicalOR(StrEquals(string_5,"AdenaText"),StrEquals(string_5,"NPHRN_BeltWnd")) )
		{
			if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(info_3.DragSrcName,"InventoryItem"),UnknownFunction122(info_3.DragSrcName,"QuestItem")),UnknownFunction122(info_3.DragSrcName,"EquipmentItem")),UnknownFunction122(info_3.DragSrcName,"SuppliesItem")),UnknownFunction122(info_3.DragSrcName,"CraftingItem")),UnknownFunction155(-1,UnknownFunction126(info_3.DragSrcName,"EquipItem"))) )
			{
				function14(info_3);
			}
		}
	}
}

function function14 (ItemInfo info_4)
{
}

function bool IsEquipItem (out ItemInfo info_3)
{
	return info_3.bEquipped;
}

function bool IsQuestItem (out ItemInfo info_3)
{
	return Equals(info_3.ItemType,3);
}

function HandleClear ()
{
	EquipItemClear();
	m_invenItem.Clear();
	item_2.Clear();
	info_1.Length = 0;
	info_2.Length = 0;
	item_5.Clear();
	item_6.Clear();
	item_7.Clear();
}

function int EquipItemGetItemNum ()
{
	local int int_6;
	local int ItemNum;

	int_6 = 0;
	if ( UnknownFunction150(int_6,15) )
	{
		if ( equipItem[int_6].IsEnableWindow() )
		{
			ItemNum = DoAdd(ItemNum,equipItem[int_6].GetItemNum());
		}
		UnknownFunction165(int_6);
		goto JL0007;
	}
	return ItemNum;
}

function EquipItemClear ()
{
	local int int_6;

	int_6 = 0;
	if ( UnknownFunction150(int_6,15) )
	{
		equipItem[int_6].Clear();
		UnknownFunction165(int_6);
		goto JL0007;
	}
}

function bool EquipItemFind (int int_9)
{
	local int int_6;
	local int int_4;

	int_6 = 0;
	if ( UnknownFunction150(int_6,15) )
	{
		int_4 = equipItem[int_6].FindItemWithServerID(int_9);
		if ( IntNotEquals(-1,int_4) )
		{
			return True;
		}
		UnknownFunction165(int_6);
		goto JL0007;
	}
	return False;
}

function EquipItemDelete (int int_9)
{
	local int int_6;
	local int int_4;
	local ItemInfo info_5;

	int_6 = 0;
	if ( UnknownFunction150(int_6,15) )
	{
		int_4 = equipItem[int_6].FindItemWithServerID(int_9);
		if ( IntNotEquals(-1,int_4) )
		{
			equipItem[int_6].Clear();
			if ( Equals(int_6,7) )
			{
				if ( equipItem[5].GetItem(0,info_5) )
				{
					if ( Equals(info_5.SlotBitType,16384) )
					{
						equipItem[7].Clear();
						equipItem[7].AddItem(info_5);
						equipItem[7].DisableWindow();
					}
				}
			}
		}
		UnknownFunction165(int_6);
		goto JL0007;
	}
}

function EarItemUpdate ()
{
	local int int_6;
	local int int_10;
	local int int_11;

	int_10 = -1;
	int_11 = -1;
	int_6 = 0;
	if ( UnknownFunction150(int_6,info_1.Length) )
	{
		switch (function44(info_1[int_6].ServerID))
		{
			case -1:
			int_10 = int_6;
			break;
			case 0:
			info_1.Remove (int_6,1);
			break;
			case 1:
			int_11 = int_6;
			break;
			default:
		}
		UnknownFunction165(int_6);
		goto JL001D;
	}
	if ( IntNotEquals(-1,int_10) )
	{
		equipItem[9].Clear();
		equipItem[9].AddItem(info_1[int_10]);
	}
	if ( IntNotEquals(-1,int_11) )
	{
		equipItem[8].Clear();
		equipItem[8].AddItem(info_1[int_11]);
	}
}

function FingerItemUpdate ()
{
	local int int_6;
	local int int_12;
	local int int_13;

	int_12 = -1;
	int_13 = -1;
	int_6 = 0;
	if ( UnknownFunction150(int_6,info_2.Length) )
	{
		switch (IsLOrREar(info_2[int_6].ServerID))
		{
			case -1:
			int_12 = int_6;
			break;
			case 0:
			info_2.Remove (int_6,1);
			break;
			case 1:
			int_13 = int_6;
			break;
			default:
		}
		UnknownFunction165(int_6);
		goto JL001D;
	}
	if ( IntNotEquals(-1,int_12) )
	{
		equipItem[14].Clear();
		equipItem[14].AddItem(info_2[int_12]);
	}
	if ( IntNotEquals(-1,int_13) )
	{
		equipItem[13].Clear();
		equipItem[13].AddItem(info_2[int_13]);
	}
}

function  ()
{
	local UserInfo UserInfo;

	vvCanUseSetEquipment = True;
	return;
	if ( GetPlayerInfo(UserInfo) )
	{
		vvCanUseSetEquipment = UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction122(UserInfo.Name,"BerserkdGG"),UnknownFunction122(UserInfo.Name,"TomFord")),UnknownFunction122(UserInfo.Name,"Akila")),UnknownFunction122(UserInfo.Name,"Jain")),UnknownFunction122(UserInfo.Name,"ElTocaNene")),UnknownFunction122(UserInfo.Name,"TommyMerlyn")),UnknownFunction122(UserInfo.Name,"GlazingInMotion"));
	}
}

function ! (ItemInfo paramItemInfo)
{
	local array<int> setParts;
	local int auxItemPos;
	local string auxItemName;
	local ItemInfo auxItemInfo;
	local int idx;

	if ( UnknownFunction129(vvCanUseSetEquipment) )
	{
		return;
	}
	Class'UIDATA_ITEM'.GetSetItemIDList(paramItemInfo.ClassID,0,setParts);
	idx = 0;
	if ( UnknownFunction150(idx,setParts.Length) )
	{
		if ( UnknownFunction154(setParts[idx],paramItemInfo.ClassID) )
		{
			goto JL00D7;
		}
		auxItemName = Class'UIDATA_ITEM'.GetItemName(setParts[idx]);
		auxItemPos = m_invenItem.FindItemWithClassID(setParts[idx]);
		if ( UnknownFunction150(auxItemPos,0) )
		{
			goto JL00D7;
		}
		m_invenItem.GetItem(auxItemPos,auxItemInfo);
		RequestUseItem(auxItemInfo.ServerID);
		UnknownFunction165(idx);
		goto JL0033;
	}
}

function EquipItemUpdate (ItemInfo paramItemInfo)
{
	local ItemWindowHandle item;
	local ItemInfo info_5;
	local bool bool_1;
	local ItemInfo info_9;
	local ItemInfo info_10;
	local ItemInfo info_3;
	local ItemInfo info_4;
	local ItemInfo info_7;
	local ItemInfo info_8;
	local int int_6;

	if ( UnknownFunction132(UnknownFunction154(paramItemInfo.SlotBitType,1024),UnknownFunction154(paramItemInfo.SlotBitType,32768)) )
	{
		!(paramItemInfo);
	}
	switch (paramItemInfo.SlotBitType)
	{
		case 1:
		item = equipItem[0];
		break;
		case 2:
		case 4:
		case 6:
		int_6 = 0;
JL006B:
		if ( UnknownFunction150(int_6,info_1.Length) )
		{
			if (! Equals(info_1[int_6].ServerID,paramItemInfo.ServerID) ) goto JL009E;
			UnknownFunction165(int_6);
			goto JL006B;
		}
		if ( Equals(int_6,info_1.Length) )
		{
			info_1.Length = DoAdd(info_1.Length,1);
			info_1[IntSub(info_1.Length,1)] = paramItemInfo;
		}
		item = None;
		EarItemUpdate();
		break;
		case 8:
		item = equipItem[4];
		break;
		case 16:
		case 32:
		case 48:
		int_6 = 0;
		if ( UnknownFunction150(int_6,info_2.Length) )
		{
			if (! Equals(info_2[int_6].ServerID,paramItemInfo.ServerID) ) goto JL0158;
			UnknownFunction165(int_6);
			goto JL0125;
		}
		if ( Equals(int_6,info_2.Length) )
		{
			info_2.Length = DoAdd(info_2.Length,1);
			info_2[IntSub(info_2.Length,1)] = paramItemInfo;
		}
		item = None;
		FingerItemUpdate();
		break;
		case 64:
		item = equipItem[1];
		item.EnableWindow();
		break;
		case 128:
		item = equipItem[5];
		break;
		case 256:
		item = equipItem[7];
		item.EnableWindow();
		break;
		case 512:
		item = equipItem[10];
		item.EnableWindow();
		break;
		case 1024:
		item = equipItem[6];
		break;
		case 2048:
		item = equipItem[11];
		item.EnableWindow();
		break;
		case 4096:
		item = equipItem[12];
		item.EnableWindow();
		break;
		case 8192:
		item = equipItem[0];
		break;
		case 16384:
		item = equipItem[5];
		bool_1 = True;
		if ( IsBowOrFishingRod(paramItemInfo) )
		{
			if ( equipItem[7].GetItem(0,info_5) )
			{
				if ( function26(info_5) )
				{
					bool_1 = False;
				}
			}
		}
		if ( bool_1 )
		{
			if ( IntNotEquals(StrLen(paramItemInfo.IconNameEx1),0) )
			{
				info_9 = paramItemInfo;
				info_10 = paramItemInfo;
				info_9.IconIndex = 1;
				info_10.IconIndex = 2;
				equipItem[5].Clear();
				equipItem[5].AddItem(info_9);
				equipItem[7].Clear();
				equipItem[7].AddItem(info_10);
				equipItem[7].DisableWindow();
				item = None;
			} else {
				equipItem[7].Clear();
				equipItem[7].AddItem(paramItemInfo);
				equipItem[7].DisableWindow();
			}
		}
		break;
		case 32768:
		item = equipItem[6];
		info_3 = paramItemInfo;
		info_3.IconName = paramItemInfo.IconNameEx2;
		equipItem[11].Clear();
		equipItem[11].AddItem(info_3);
		equipItem[11].DisableWindow();
		break;
		case 65536:
		item = equipItem[2];
		break;
		case 131072:
		item = equipItem[6];
		info_8 = paramItemInfo;
		info_4 = paramItemInfo;
		info_3 = paramItemInfo;
		info_7 = paramItemInfo;
		info_8.IconName = paramItemInfo.IconNameEx1;
		info_4.IconName = paramItemInfo.IconNameEx2;
		info_3.IconName = paramItemInfo.IconNameEx3;
		info_7.IconName = paramItemInfo.IconNameEx4;
		equipItem[1].Clear();
		equipItem[1].AddItem(info_8);
		equipItem[1].DisableWindow();
		equipItem[10].Clear();
		equipItem[10].AddItem(info_4);
		equipItem[10].DisableWindow();
		equipItem[11].Clear();
		equipItem[11].AddItem(info_3);
		equipItem[11].DisableWindow();
		equipItem[12].Clear();
		equipItem[12].AddItem(info_7);
		equipItem[12].DisableWindow();
		break;
		case 262144:
		item = equipItem[3];
		item.EnableWindow();
		break;
		case 524288:
		item = equipItem[2];
		equipItem[3].Clear();
		equipItem[3].AddItem(paramItemInfo);
		equipItem[3].DisableWindow();
		break;
		default:
	}
	if ( UnknownFunction119(None,item) )
	{
		item.Clear();
		item.AddItem(paramItemInfo);
	}
	UpdateEquipmentItemList();
}

function UpdateEquipmentItemList ()
{
	local int idx;
	local ItemInfo auxItemInfo;

	idx = 0;
	if ( UnknownFunction150(idx,15) )
	{
		equipItem[idx].GetItem(0,auxItemInfo);
		equippedItems[idx] = auxItemInfo.ServerID;
		UnknownFunction165(idx);
		goto JL0007;
	}
}

function HandleOpenWindow ()
{
	LoadItemOrder();
	CopyInventory();
	ShowWindow(string_1);
	Class'UIAPI_WINDOW'.SetFocus(string_1);
}

function HandleHideWindow ()
{
	HideWindow(string_1);
}

function function30 (string string_2)
{
	local ItemInfo info_4;

	ParamToItemInfo(string_2,info_4);
	if ( IsEquipItem(info_4) )
	{
		EquipItemUpdate(info_4);
	} else {
		if ( IsQuestItem(info_4) )
		{
			item_2.AddItem(info_4);
		} else {
			m_invenItem.AddItem(info_4);
			if ( function31(info_4) )
			{
				item_5.AddItem(info_4);
			} else {
				if ( function32(info_4) )
				{
					item_6.AddItem(info_4);
				} else {
					if ( HandleAddItem(info_4) )
					{
						item_7.AddItem(info_4);
					}
				}
			}
		}
	}
}

function bool function31 (ItemInfo info_4)
{
	if ( LogicalOR(LogicalOR(Equals(info_4.ItemType,0),Equals(info_4.ItemType,1)),Equals(info_4.ItemType,2)) )
	{
		return True;
	}
}

function bool function32 (ItemInfo info_4)
{
	if ( LogicalOR(Equals(info_4.ItemSubType,5),Equals(info_4.ItemSubType,6)) )
	{
		return True;
	}
}

function bool HandleAddItem (ItemInfo info_4)
{
	if ( LogicalOR(LogicalOR(LogicalOR(LogicalOR(LogicalOR(Equals(info_4.ItemSubType,1),Equals(info_4.ItemSubType,2)),Equals(info_4.ItemSubType,24)),Equals(info_4.ItemSubType,3)),StrEquals(StrLeft(info_4.Name,6),"Elixir")),StrEquals(StrLeft(info_4.Name,8),"Soulshot")) )
	{
		return True;
	}
}

function HandleUpdateItem (string string_2)
{
	local string string_1;
	local ItemInfo info_3;
	local int int_4;

	ParseString(string_2,"type",string_1);
	ParamToItemInfo(string_2,info_3);
	if ( StrEquals(string_1,"add") )
	{
		if ( IsEquipItem(info_3) )
		{
			EquipItemUpdate(info_3);
		} else {
			if ( IsQuestItem(info_3) )
			{
				item_2.AddItem(info_3);
				int_4 = UnknownFunction147(item_2.GetItemNum(),1);
				if ( UnknownFunction151(int_4,0) )
				{
					item_2.SwapItems(UnknownFunction147(int_4,1),int_4);
JL008F:
					UnknownFunction164(int_4);
					goto JL008F;
				}
			} else {
				m_invenItem.AddItem(info_3);
				int_4 = UnknownFunction147(m_invenItem.GetItemNum(),1);
				if ( UnknownFunction151(int_4,0) )
				{
					m_invenItem.SwapItems(UnknownFunction147(int_4,1),int_4);
					UnknownFunction164(int_4);
					goto JL00EF;
				}
				if ( function31(info_3) )
				{
					item_5.AddItem(info_3);
					int_4 = UnknownFunction147(item_5.GetItemNum(),1);
					if ( UnknownFunction151(int_4,0) )
					{
						item_5.SwapItems(UnknownFunction147(int_4,1),int_4);
						UnknownFunction164(int_4);
						goto JL015A;
					}
				} else {
					if ( function32(info_3) )
					{
						item_6.AddItem(info_3);
						int_4 = UnknownFunction147(item_6.GetItemNum(),1);
						if ( UnknownFunction151(int_4,0) )
						{
							item_6.SwapItems(UnknownFunction147(int_4,1),int_4);
							UnknownFunction164(int_4);
							goto JL01C8;
						}
					} else {
						if ( HandleAddItem(info_3) )
						{
							item_7.AddItem(info_3);
							int_4 = UnknownFunction147(item_7.GetItemNum(),1);
							if ( UnknownFunction151(int_4,0) )
							{
								item_7.SwapItems(UnknownFunction147(int_4,1),int_4);
								UnknownFunction164(int_4);
								goto JL0236;
							}
						}
					}
				}
			}
		}
	} else {
		if ( StrEquals(string_1,"update") )
		{
			if ( IsEquipItem(info_3) )
			{
				if ( EquipItemFind(info_3.ServerID) )
				{
					EquipItemUpdate(info_3);
				} else {
					int_4 = m_invenItem.FindItemWithServerID(info_3.ServerID);
					if ( IntNotEquals(int_4,-1) )
					{
						m_invenItem.DeleteItem(int_4);
					}
					if ( function31(info_3) )
					{
						int_4 = item_5.FindItemWithServerID(info_3.ServerID);
						if ( IntNotEquals(int_4,-1) )
						{
							item_5.DeleteItem(int_4);
						}
					} else {
						if ( function32(info_3) )
						{
							int_4 = item_6.FindItemWithServerID(info_3.ServerID);
							if ( IntNotEquals(int_4,-1) )
							{
								item_6.DeleteItem(int_4);
							}
						} else {
							if ( HandleAddItem(info_3) )
							{
								int_4 = item_7.FindItemWithServerID(info_3.ServerID);
								if ( IntNotEquals(int_4,-1) )
								{
									item_7.DeleteItem(int_4);
								}
							}
						}
					}
					EquipItemUpdate(info_3);
				}
			} else {
				if ( IsQuestItem(info_3) )
				{
					int_4 = item_2.FindItemWithServerID(info_3.ServerID);
					if ( IntNotEquals(int_4,-1) )
					{
						item_2.SetItem(int_4,info_3);
					} else {
						EquipItemDelete(info_3.ServerID);
						item_2.AddItem(info_3);
					}
				} else {
					if ( function31(info_3) )
					{
						int_4 = item_5.FindItemWithServerID(info_3.ServerID);
						if ( IntNotEquals(int_4,-1) )
						{
							item_5.SetItem(int_4,info_3);
						}
					} else {
						if ( function32(info_3) )
						{
							int_4 = item_6.FindItemWithServerID(info_3.ServerID);
							if ( IntNotEquals(int_4,-1) )
							{
								item_6.SetItem(int_4,info_3);
							}
						} else {
							if ( HandleAddItem(info_3) )
							{
								int_4 = item_7.FindItemWithServerID(info_3.ServerID);
								if ( IntNotEquals(int_4,-1) )
								{
									item_7.SetItem(int_4,info_3);
								}
							}
						}
					}
					int_4 = m_invenItem.FindItemWithServerID(info_3.ServerID);
					if ( IntNotEquals(int_4,-1) )
					{
						m_invenItem.SetItem(int_4,info_3);
					} else {
						EquipItemDelete(info_3.ServerID);
						m_invenItem.AddItem(info_3);
						int_4 = UnknownFunction147(m_invenItem.GetItemNum(),1);
						if ( UnknownFunction151(int_4,0) )
						{
							m_invenItem.SwapItems(UnknownFunction147(int_4,1),int_4);
							UnknownFunction164(int_4);
							goto JL0623;
						}
						if ( function31(info_3) )
						{
							item_5.AddItem(info_3);
							int_4 = UnknownFunction147(item_5.GetItemNum(),1);
							if ( UnknownFunction151(int_4,0) )
							{
								item_5.SwapItems(UnknownFunction147(int_4,1),int_4);
								UnknownFunction164(int_4);
								goto JL068E;
							}
						}
					}
				}
			}
		} else {
			if ( StrEquals(string_1,"delete") )
			{
				if ( IsEquipItem(info_3) )
				{
					EquipItemDelete(info_3.ServerID);
				} else {
					if ( IsQuestItem(info_3) )
					{
						int_4 = item_2.FindItemWithServerID(info_3.ServerID);
						item_2.DeleteItem(int_4);
					} else {
						int_4 = m_invenItem.FindItemWithServerID(info_3.ServerID);
						m_invenItem.DeleteItem(int_4);
						if ( function31(info_3) )
						{
							int_4 = item_5.FindItemWithServerID(info_3.ServerID);
							item_5.DeleteItem(int_4);
						}
						if ( function32(info_3) )
						{
							int_4 = item_6.FindItemWithServerID(info_3.ServerID);
							item_6.DeleteItem(int_4);
						}
						if ( HandleAddItem(info_3) )
						{
							int_4 = item_7.FindItemWithServerID(info_3.ServerID);
							item_7.DeleteItem(int_4);
						}
					}
				}
			}
		}
	}
	SetAdenaText();
	SetItemCount();
}

function HandleItemListEnd ()
{
	SetAdenaText();
	SetItemCount();
	OrderItem();
}

function function37 (string string_2)
{
	UpdateHennaInfo();
}

function HandleUpdateHennaInfo (string string_2)
{
	UpdateHennaInfo();
}

function UpdateHennaInfo ()
{
	local int int_6;
	local int int_1;
	local int HennaID;
	local int int_2;
	local ItemInfo Info;
	local UserInfo UserInfo;
	local int int_3;

	if ( GetPlayerInfo(UserInfo) )
	{
		int_3 = GetClassStep(UserInfo.nSubClass);
		switch (int_3)
		{
			case 1:
			case 2:
			case 3:
			item_4.SetRow(int_3);
			break;
			default:
		}
		item_4.SetRow(0);
	} else {
	}
	item_4.Clear();
	int_1 = Class'HennaAPI'.GetHennaInfoCount();
	if ( GreaterThan(int_1,int_3) )
	{
		int_1 = int_3;
	}
	int_6 = 0;
	if ( UnknownFunction150(int_6,int_1) )
	{
		if ( Class'HennaAPI'.GetHennaInfo(int_6,HennaID,int_2) )
		{
			if ( NotBool(Class'UIDATA_HENNA'.GetItemName(HennaID,Info.Name)) )
			{
				goto JL01A7;
			}
			if ( NotBool(Class'UIDATA_HENNA'.GetDescription(HennaID,Info.Description)) )
			{
				goto JL01A7;
			}
			if ( NotBool(Class'UIDATA_HENNA'.GetIconTex(HennaID,Info.IconName)) )
			{
				goto JL01A7;
			}
			if ( Equals(0,int_2) )
			{
				Info.bDisabled = True;
			} else {
				Info.bDisabled = False;
			}
			item_4.AddItem(Info);
		}
		UnknownFunction165(int_6);
		goto JL00AF;
	}
}

function SetAdenaText ()
{
	local string string_1;

	string_1 = MakeCostString(string(GetAdena()));
	text_1.SetText(string_1);
	text_1.SetTooltipString(ConvertNumToText(string(GetAdena())));
}

function UseItem (ItemWindowHandle Handle, int int_4)
{
	local ItemInfo info_3;

	if ( Handle.GetItem(int_4,info_3) )
	{
		if ( info_3.bRecipe )
		{
			DialogSetReservedInt(info_3.ServerID);
			DialogSetID(1111);
			DialogShow(4,GetSystemMessage(798));
		} else {
			if ( GreaterThan(info_3.PopMsgNum,0) )
			{
				DialogSetID(2222);
				DialogSetReservedInt(info_3.ServerID);
				DialogShow(4,GetSystemMessage(info_3.PopMsgNum));
			} else {
				RequestUseItem(info_3.ServerID);
			}
		}
	}
}

function SaveItemOrder ()
{
	local ItemInfo info_3;
	local int int_6;

	int_1.Length = m_invenItem.GetItemNum();
	int_6 = 0;
	if ( UnknownFunction150(int_6,int_1.Length) )
	{
		m_invenItem.GetItem(int_6,info_3);
		int_1[int_6] = info_3.ClassID;
		UnknownFunction165(int_6);
		goto JL001D;
	}
	SaveInventoryOrder(int_1);
}

function LoadItemOrder ()
{
	LoadInventoryOrder(int_1);
}

function OrderItem ()
{
	local int int_4;
	local int ItemNum;
	local int int_2;
	local int int_3;
	local ItemInfo info_3;
	local bool bool_1;

	int_4 = 0;
	ItemNum = m_invenItem.GetItemNum();
	int_2 = 0;
	if ( UnknownFunction150(int_2,ItemNum) )
	{
		m_invenItem.GetItem(int_2,info_3);
		bool_1 = False;
		int_3 = 0;
		if ( UnknownFunction150(int_3,int_1.Length) )
		{
			if ( Equals(info_3.ClassID,int_1[int_3]) )
			{
				bool_1 = True;
			} else {
			}
			UnknownFunction165(int_3);
			goto JL005A;
		}
		if ( NotBool(bool_1) )
		{
			m_invenItem.SwapItems(int_2,int_4);
			IntPreIncrement(int_4);
		}
		UnknownFunction165(int_2);
		goto JL0023;
	}
	int_3 = 0;
	if ( UnknownFunction150(int_3,int_1.Length) )
	{
		int_2 = 0;
		if ( UnknownFunction150(int_2,ItemNum) )
		{
			m_invenItem.GetItem(int_2,info_3);
			if ( Equals(info_3.ClassID,int_1[int_3]) )
			{
				m_invenItem.SwapItems(int_2,int_4);
				IntPreIncrement(int_4);
			} else {
			}
			UnknownFunction165(int_2);
			goto JL00F8;
		}
		UnknownFunction165(int_3);
		goto JL00E1;
	}
}

function int GetMyInventoryLimit ()
{
	return Class'UIDATA_PLAYER'.GetInventoryLimit();
}

function SetItemCount ()
{
	local int int_1;
	local int int_2;
	local TextBoxHandle text_1;

	int_2 = DoAdd(DoAdd(m_invenItem.GetItemNum(),item_2.GetItemNum()),EquipItemGetItemNum());
	int_1 = GetMyInventoryLimit();
	text_1 = TextBoxHandle(GetHandle(StrCat(string_1,".ItemCount")));
	text_1.SetText(StrCat(StrCat(StrCat(StrCat("(",string(int_2)),"/"),string(int_1)),")"));
}

function HandleDialogOK ()
{
	local int Id;
	local int Reserved;
	local int int_1;
	local int int_2;

	if ( DialogIsMine() )
	{
		Id = DialogGetID();
		Reserved = DialogGetReservedInt();
		int_1 = DialogGetReservedInt2();
		int_2 = int(DialogGetString());
		if ( UnknownFunction132(UnknownFunction154(Id,1111),UnknownFunction154(Id,2222)) )
		{
			RequestUseItem(Reserved);
		} else {
			if ( UnknownFunction154(Id,3333) )
			{
				RequestDropItem(Reserved,1,vector_1);
			} else {
				if ( UnknownFunction154(Id,4444) )
				{
					if ( UnknownFunction154(int_2,0) )
					{
						int_2 = 1;
					}
					RequestDropItem(Reserved,int_2,vector_1);
				} else {
					if ( UnknownFunction154(Id,5555) )
					{
						RequestDropItem(Reserved,int_1,vector_1);
					} else {
						if ( UnknownFunction154(Id,6666) )
						{
							RequestDestroyItem(Reserved,1);
						} else {
							if ( UnknownFunction154(Id,8888) )
							{
								RequestDestroyItem(Reserved,int_2);
							} else {
								if ( UnknownFunction154(Id,7777) )
								{
									RequestDestroyItem(Reserved,int_1);
								} else {
									if ( UnknownFunction154(Id,9999) )
									{
										RequestCrystallizeItem(Reserved,1);
									} else {
										if ( UnknownFunction154(Id,10000) )
										{
											Class'PetAPI'.RequestGetItemFromPet(Reserved,int_2,False);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function HandleUpdateUserInfo ()
{
	if ( m_hOwnerWnd.IsShowWindow() )
	{
		EarItemUpdate();
		FingerItemUpdate();
	}
}

function HandleToggleWindow ()
{
	if ( m_hOwnerWnd.IsShowWindow() )
	{
		m_hOwnerWnd.HideWindow();
	} else {
		if ( IsShowInventoryWndUponEvent() )
		{
			RequestItemList();
			m_hOwnerWnd.ShowWindow();
		}
	}
}

function bool IsShowInventoryWndUponEvent ()
{
	local WindowHandle window_1;
	local WindowHandle window_2;
	local WindowHandle window_3;
	local WindowHandle window_4;
	local WindowHandle window_5;
	local WindowHandle window_6;
	local PrivateShopWnd PrivateShopWnd;

	window_1 = GetHandle("WarehouseWnd");
	window_2 = GetHandle("PrivateShopWnd");
	window_3 = GetHandle("TradeWnd");
	window_4 = GetHandle("ShopWnd");
	window_5 = GetHandle("MultiSellWnd");
	window_6 = GetHandle("DeliverWnd");
	PrivateShopWnd = PrivateShopWnd(GetScript("PrivateShopWnd"));
	if ( window_1.IsShowWindow() )
	{
		return False;
	}
	if ( window_1.IsShowWindow() )
	{
		return False;
	}
	if ( window_3.IsShowWindow() )
	{
		return False;
	}
	if ( window_4.IsShowWindow() )
	{
		return False;
	}
	if ( window_5.IsShowWindow() )
	{
		return False;
	}
	if ( window_6.IsShowWindow() )
	{
		return False;
	}
	if ( LogicalAND(window_2.IsShowWindow(),Equals(PrivateShopWnd.m_type,2)) )
	{
		return False;
	}
	return True;
}

function int function44 (int int_9)
{
	local int int_1;
	local int int_2;
	local int int_3;
	local int int_4;

	GetAccessoryServerID(int_1,int_2,int_3,int_4);
	if ( Equals(int_9,int_1) )
	{
		return -1;
	} else {
		if ( Equals(int_9,int_2) )
		{
			return 1;
		} else {
			return 0;
		}
	}
}

function int IsLOrREar (int int_9)
{
	local int int_1;
	local int int_2;
	local int int_3;
	local int int_4;

	GetAccessoryServerID(int_1,int_2,int_3,int_4);
	if ( Equals(int_9,int_3) )
	{
		return -1;
	} else {
		if ( Equals(int_9,int_4) )
		{
			return 1;
		} else {
			return 0;
		}
	}
}

function bool IsBowOrFishingRod (ItemInfo paramItemInfo)
{
	if ( LogicalOR(Equals(6,paramItemInfo.WeaponType),Equals(10,paramItemInfo.WeaponType)) )
	{
		return True;
	}
	return False;
}

function bool function26 (ItemInfo paramItemInfo)
{
	return paramItemInfo.bArrow;
}

function CustomTooltip GetTooltip (string string_1)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo info_3;

	ToolTip.DrawList.Length = 1;
	info_3.eType = 1;
	info_3.t_strText = string_1;
	ToolTip.DrawList[0] = info_3;
	return ToolTip;
}

function function2 ()
{
	local int int_6;
	local int string_4;

	int_6 = 1;
	if ( UnknownFunction150(int_6,100) )
	{
		GetINIInt("TrashList",StrCat("",string(int_6)),string_4,"TrashGrp");
		if ( Equals(string_4,0) )
		{
			int_2 = IntSub(int_6,1);
		} else {
		}
		UnknownFunction165(int_6);
		goto JL0007;
	}
}

function function13 ()
{
	if ( NotBool(bool_1) )
	{
		bool_1 = True;
		button_5.SetTexture("Was.Inventory_Btn_Trash_Auto","Was.Inventory_Btn_Trash_Auto_Down","Was.Inventory_Btn_Trash_Auto_Over");
		function46();
	} else {
		bool_1 = False;
		button_5.SetTexture("Was.Inventory_Btn_Trash","Was.Inventory_Btn_Trash_Down","Was.Inventory_Btn_Trash_Drag");
	}
}

function function47 ()
{
	SetINIInt("TrashList",StrCat("",string(int_2)),-1,"TrashGrp");
}

function function46 ()
{
	local int int_6;
	local int int_4;
	local int string_4;
	local ItemInfo info_3;

	int_6 = 1;
	if ( UnknownFunction152(int_6,int_2) )
	{
		GetINIInt("TrashList",StrCat("",string(int_6)),string_4,"TrashGrp");
		if ( IntNotEquals(string_4,0) )
		{
			int_4 = m_invenItem.FindItemWithClassID(string_4);
			if ( m_invenItem.GetItem(int_4,info_3) )
			{
				RequestDestroyItem(info_3.ServerID,info_3.ItemNum);
			}
		} else {
			return;
		}
		UnknownFunction165(int_6);
		goto JL0007;
	}
}

function ItemWindowHandle GetCurrentTab ()
{
	if ( m_invenItem.IsShowWindow() )
	{
		return m_invenItem;
	} else {
		if ( item_5.IsShowWindow() )
		{
			return item_5;
		} else {
			if ( item_7.IsShowWindow() )
			{
				return item_7;
			} else {
				if ( item_6.IsShowWindow() )
				{
					return item_6;
				} else {
					if ( item_2.IsShowWindow() )
					{
						return item_2;
					}
				}
			}
		}
	}
}

function function3 ()
{
	local WindowHandle window_1;
	local TextureHandle texture_1;
	local TextureHandle texture_2;
	local ButtonHandle text_1;

	return;
	window_1 = GetHandle("InventoryWnd");
	texture_1 = TextureHandle(GetHandle("InventoryWnd.Tex"));
	texture_2 = TextureHandle(GetHandle("InventoryWnd.Slots2"));
	text_1 = ButtonHandle(GetHandle("InventoryWnd.BtnExpand"));
	if ( BoolEquals(GetOptionBool("Options","ExpandedInventory"),True) )
	{
		window_1.SetWindowSize(673,400);
		texture_1.SetWindowSize(680,412);
		texture_1.SetTexture("Was.InventoryWnd_Max");
		texture_2.SetWindowSize(216,288);
		m_invenItem.SetWindowSize(447,288);
		item_2.SetWindowSize(447,288);
		item_5.SetWindowSize(447,288);
		item_6.SetWindowSize(447,288);
		item_7.SetWindowSize(447,288);
		m_invenItem.SetCol(12);
		item_2.SetCol(12);
		item_5.SetCol(12);
		item_6.SetCol(12);
		item_7.SetCol(12);
		text_1.SetTexture("Was.Frames_df_Btn_Minimize","Was.Frames_df_Btn_Minimize_Down","Was.Frames_df_Btn_Minimize_Over");
	} else {
		window_1.SetWindowSize(566,400);
		texture_1.SetWindowSize(573,412);
		texture_1.SetTexture("Was.InventoryWnd_Min");
		texture_2.SetWindowSize(108,288);
		m_invenItem.SetWindowSize(339,288);
		item_2.SetWindowSize(339,288);
		item_5.SetWindowSize(339,288);
		item_6.SetWindowSize(339,288);
		item_7.SetWindowSize(339,288);
		m_invenItem.SetCol(9);
		item_2.SetCol(9);
		item_5.SetCol(9);
		item_6.SetCol(9);
		item_7.SetCol(9);
		text_1.SetTexture("Was.Frames_df_Btn_Expand","Was.Frames_df_Btn_Expand_Down","Was.Frames_df_Btn_Expand_Over");
	}
	function48("InventoryWnd.BtnClose","InventoryWnd.Tex",3,-18,18);
	function48("InventoryWnd.BtnMin","InventoryWnd.Tex",3,-34,18);
	function48("InventoryWnd.BtnExpand","InventoryWnd.Tex",3,-50,16);
	function48("InventoryWnd.ItemCount","InventoryWnd",3,-78,5);
	function48("InventoryWnd.b_FastDelete","InventoryWnd",3,-61,6);
	function48("InventoryWnd.Title","InventoryWnd.Tex",2,0,19);
}

function function48 (string string_1, string string_2, int string_4, int X, int Y)
{
	switch (string_4)
	{
		case 1:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"TopLeft","TopLeft",X,Y);
		break;
		case 2:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"TopCenter","TopCenter",X,Y);
		break;
		case 3:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"TopRight","TopRight",X,Y);
		break;
		case 4:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"CenterLeft","CenterLeft",X,Y);
		break;
		case 5:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"Center","Center",X,Y);
		break;
		case 6:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"CenterRight","CenterRight",X,Y);
		break;
		case 7:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"BottomLeft","BottomLeft",X,Y);
		break;
		case 8:
		Class'UIAPI_WINDOW'.SetAnchor(string_1,string_2,"BottomCenter","BottomCenter",X,Y);
		break;
		default:
	}
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.ItemCount");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Underwear");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Head");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Hair");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Hair2");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Neck");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_RHand");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Chest");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_LHand");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_REar");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_LEar");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Gloves");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Legs");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_Feet");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_RFinger");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.EquipItem_LFinger");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.HennaItem");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.InventoryItem");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.QuestItem");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.InventoryTab");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.CrystallizeButton");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.TrashButton");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.AdenaText");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.AdenaIcon");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.InvenWeight");
	Class'UIAPI_WINDOW'.SetFocus("InventoryWnd.BtnClose");
}

function PrintInventory ()
{
	local ItemInfo item;
	local int i;

	i = 0;
	if ( UnknownFunction150(i,15) )
	{
		if ( UnknownFunction114(equipItem[i],None) )
		{
			goto JL0080;
		}
		equipItem[i].GetItem(0,item);
		Debug2(UnknownFunction112(UnknownFunction112(UnknownFunction112("Item name: ",item.Name),". Server ID: "),string(item.ServerID)));
		UnknownFunction165(i);
		goto JL0007;
	}
}

defaultproperties
{
    string_1="InventoryWnd"

}

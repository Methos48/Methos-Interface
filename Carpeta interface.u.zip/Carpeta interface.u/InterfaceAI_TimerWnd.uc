//================================================================================
// InterfaceAI_TimerWnd.
//================================================================================

class InterfaceAI_TimerWnd extends UICommonAPI;

var WindowHandle Me;
var ButtonHandle SecondStart;
var ButtonHandle SecondStop;
var ButtonHandle Timer1Start;
var ButtonHandle Timer2Start;
var ButtonHandle Timer3Start;
var ButtonHandle Timer4Start;
var ButtonHandle Timer1Stop;
var ButtonHandle Timer2Stop;
var ButtonHandle Timer3Stop;
var ButtonHandle Timer4Stop;
var CheckBoxHandle checkAlarmT1;
var CheckBoxHandle checkAlarmT2;
var CheckBoxHandle checkAlarmT3;
var CheckBoxHandle checkAlarmT4;
var EditBoxHandle editNameT1;
var EditBoxHandle editNameT2;
var EditBoxHandle editNameT3;
var EditBoxHandle editNameT4;
var EditBoxHandle editValueTimer1;
var EditBoxHandle editValueTimer2;
var EditBoxHandle editValueTimer3;
var EditBoxHandle editValueTimer4;
var bool IsMinimized;
var int Timer_1;
var int CurTimer_1_mil;
var int CurTimer_1_sec;
var int CurTimer_1_min;
var string Timer_1_string;
var int CurUserTime;
var string Timer_NotificationText_60;
var string Timer_NotificationText_30;
var string Timer_NotificationText_0;
var string Timer_NotificationText_Over;
var string Timer_NotificationText_OverFinal;
var array<string> Timer_Name;
var array<int> CurUserTime_Timer;
var array<int> Timer_UserSerconds;
var array<int> TIMER_A_ID;
var array<int> UserUseAlarm;
var Color Red;
var Color Green;
var Color Gold;
var Color Orange;
var InterfaceAI_TimerAlarmWnd script;
const TIMER_DELAY=1000;
const TIMER_ID=9900;

function OnLoad ()
{
	RegisterEvent(19002);
	InitHandle();
	LoadData();
}

function LoadData ()
{
	local string Timer1_Name;
	local string Timer3_Name;
	local string Timer2_Name;
	local string Timer4_Name;
	local int Timer1_UserSerconds;
	local int Timer2_UserSerconds;
	local int Timer3_UserSerconds;
	local int Timer4_UserSerconds;
	local int UserUseAlarm1;
	local int UserUseAlarm2;
	local int UserUseAlarm3;
	local int UserUseAlarm4;

	CurUserTime_Timer[0] = 0;
	TIMER_A_ID[0] = 0;
	TIMER_A_ID[1] = 9901;
	TIMER_A_ID[2] = 9902;
	TIMER_A_ID[3] = 9903;
	TIMER_A_ID[4] = 9904;
	Red.R = 255;
	Red.G = 0;
	Red.B = 0;
	Orange.R = 255;
	Orange.G = 90;
	Orange.B = 0;
	Gold.R = 255;
	Gold.G = 170;
	Gold.B = 0;
	Green.R = 0;
	Green.G = 255;
	Green.B = 0;
	GetINIString("Timer","Timer1_Name",Timer1_Name,"Option");
	GetINIString("Timer","Timer2_Name",Timer2_Name,"Option");
	GetINIString("Timer","Timer3_Name",Timer3_Name,"Option");
	GetINIString("Timer","Timer4_Name",Timer4_Name,"Option");
	GetINIInt("Timer","Timer1_UserSerconds",Timer1_UserSerconds,"Option");
	GetINIInt("Timer","Timer2_UserSerconds",Timer2_UserSerconds,"Option");
	GetINIInt("Timer","Timer3_UserSerconds",Timer3_UserSerconds,"Option");
	GetINIInt("Timer","Timer4_UserSerconds",Timer4_UserSerconds,"Option");
	GetINIBool("Timer","Timer1_UserUseAlarm",UserUseAlarm1,"Option");
	GetINIBool("Timer","Timer2_UserUseAlarm",UserUseAlarm2,"Option");
	GetINIBool("Timer","Timer3_UserUseAlarm",UserUseAlarm3,"Option");
	GetINIBool("Timer","Timer4_UserUseAlarm",UserUseAlarm4,"Option");
	Timer_Name[0] = "";
	Timer_Name[1] = Timer1_Name;
	Timer_Name[2] = Timer2_Name;
	Timer_Name[3] = Timer3_Name;
	Timer_Name[4] = Timer4_Name;
	Timer_UserSerconds[0] = 0;
	Timer_UserSerconds[1] = Timer1_UserSerconds;
	Timer_UserSerconds[2] = Timer2_UserSerconds;
	Timer_UserSerconds[3] = Timer2_UserSerconds;
	Timer_UserSerconds[4] = Timer4_UserSerconds;
	UserUseAlarm[0] = 0;
	UserUseAlarm[1] = UserUseAlarm1;
	UserUseAlarm[2] = UserUseAlarm2;
	UserUseAlarm[3] = UserUseAlarm3;
	UserUseAlarm[4] = UserUseAlarm4;
	script = InterfaceAI_TimerAlarmWnd(GetScript("InterfaceAI_TimerAlarmWnd"));
}

function InitHandle ()
{
	Me = GetHandle("InterfaceAI_TimerWnd");
	SecondStart = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnSecondStart"));
	SecondStop = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnSecondStop"));
	Timer1Start = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStart1"));
	Timer2Start = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStart2"));
	Timer3Start = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStart3"));
	Timer4Start = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStart4"));
	Timer1Stop = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStop1"));
	Timer2Stop = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStop2"));
	Timer3Stop = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStop3"));
	Timer4Stop = ButtonHandle(GetHandle("InterfaceAI_TimerWnd.btnTimerStop4"));
	checkAlarmT1 = CheckBoxHandle(GetHandle("InterfaceAI_TimerWnd.checkAlarmT1"));
	checkAlarmT2 = CheckBoxHandle(GetHandle("InterfaceAI_TimerWnd.checkAlarmT2"));
	checkAlarmT3 = CheckBoxHandle(GetHandle("InterfaceAI_TimerWnd.checkAlarmT3"));
	checkAlarmT4 = CheckBoxHandle(GetHandle("InterfaceAI_TimerWnd.checkAlarmT4"));
	editNameT1 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editNameT1"));
	editNameT2 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editNameT2"));
	editNameT3 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editNameT3"));
	editNameT4 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editNameT4"));
	editValueTimer1 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editValueTimer1"));
	editValueTimer2 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editValueTimer2"));
	editValueTimer3 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editValueTimer3"));
	editValueTimer4 = EditBoxHandle(GetHandle("InterfaceAI_TimerWnd.editValueTimer4"));
}

function string GetTimerName (int Nomber)
{
	return Timer_Name[Nomber];
}

function OnShow ()
{
	if ( IsMinimized )
	{
		IsMinimized = False;
	} else {
		Reset();
		InitLocalization();
		IsMinimized = False;
	}
}

function OnMinimize ()
{
	IsMinimized = True;
}

function OnHide ()
{
	if ( IsMinimized )
	{
		goto JL0012;
	}
	Reset();
}

function Reset ()
{
	local int i;

	i = 0;
	if ( UnknownFunction152(i,4) )
	{
		ResetTimer(i);
		UnknownFunction163(i);
		goto JL0007;
	}
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.valSeconds","00:00");
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editNameT1",Timer_Name[1]);
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editNameT2",Timer_Name[2]);
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editNameT3",Timer_Name[3]);
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editNameT4",Timer_Name[4]);
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editValueTimer1",string(Timer_UserSerconds[1]));
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editValueTimer2",string(Timer_UserSerconds[2]));
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editValueTimer3",string(Timer_UserSerconds[3]));
	Class'UIAPI_EDITBOX'.SetString("InterfaceAI_TimerWnd.editValueTimer4",string(Timer_UserSerconds[4]));
	Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",9900);
	checkAlarmT1.SetCheck(bool(UserUseAlarm[1]));
	checkAlarmT2.SetCheck(bool(UserUseAlarm[2]));
	checkAlarmT3.SetCheck(bool(UserUseAlarm[3]));
	checkAlarmT4.SetCheck(bool(UserUseAlarm[4]));
}

function ResetTimer (int UserTimerID)
{
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(UserTimerID)),ConvertSecondToStr(Timer_UserSerconds[UserTimerID]));
	Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[UserTimerID]);
}

function InitLocalization ()
{
	local string Timer_WindowName;
	local string Timer_Name;
	local string Timer_Time;
	local string Timer_Alarm;
	local string Timer_AlarmTooltip;
	local string Timer_Secondmetr;
	local string Timer_NameTooltip;
	local string Timer_ValTooltip;

	Timer_WindowName = "Interface AI: Timer";
	Timer_Name = "Timer name:";
	Timer_Time = "Time:";
	Timer_Alarm = "Notif.?";
	Timer_AlarmTooltip = "Notification about the end of the timer?";
	Timer_Secondmetr = "Stopwatch:";
	Timer_NameTooltip = "Enter the name of the timer.";
	Timer_ValTooltip = "Enter the time in seconds.";
	Timer_NotificationText_60 = "One minute later, the timer";
	Timer_NotificationText_30 = "30 seconds later, the timer";
	Timer_NotificationText_0 = "The timer";
	Timer_NotificationText_Over = "is over!";
	Timer_NotificationText_OverFinal = "is over!";
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtSecondomer",Timer_Secondmetr);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerName1",Timer_Name);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerName2",Timer_Name);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerName3",Timer_Name);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerName4",Timer_Name);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtAlarmT1",Timer_Alarm);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtAlarmT2",Timer_Alarm);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtAlarmT3",Timer_Alarm);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtAlarmT4",Timer_Alarm);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerValT1",Timer_Time);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerValT2",Timer_Time);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerValT3",Timer_Time);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.txtTimerValT4",Timer_Time);
	SecondStart.SetTooltipCustomType(SetTooltip("Start/Reset"));
	SecondStop.SetTooltipCustomType(SetTooltip("Pause"));
	Timer1Start.SetTooltipCustomType(SetTooltip("Start"));
	Timer2Start.SetTooltipCustomType(SetTooltip("Start"));
	Timer3Start.SetTooltipCustomType(SetTooltip("Start"));
	Timer4Start.SetTooltipCustomType(SetTooltip("Start"));
	Timer1Stop.SetTooltipCustomType(SetTooltip("Stop/Reset"));
	Timer2Stop.SetTooltipCustomType(SetTooltip("Stop/Reset"));
	Timer3Stop.SetTooltipCustomType(SetTooltip("Stop/Reset"));
	Timer4Stop.SetTooltipCustomType(SetTooltip("Stop/Reset"));
	checkAlarmT1.SetTooltipCustomType(SetTooltip(Timer_AlarmTooltip));
	checkAlarmT2.SetTooltipCustomType(SetTooltip(Timer_AlarmTooltip));
	checkAlarmT3.SetTooltipCustomType(SetTooltip(Timer_AlarmTooltip));
	checkAlarmT4.SetTooltipCustomType(SetTooltip(Timer_AlarmTooltip));
	editNameT1.SetTooltipCustomType(SetTooltip(Timer_NameTooltip));
	editNameT2.SetTooltipCustomType(SetTooltip(Timer_NameTooltip));
	editNameT3.SetTooltipCustomType(SetTooltip(Timer_NameTooltip));
	editNameT4.SetTooltipCustomType(SetTooltip(Timer_NameTooltip));
	editValueTimer1.SetTooltipCustomType(SetTooltip(Timer_ValTooltip));
	editValueTimer2.SetTooltipCustomType(SetTooltip(Timer_ValTooltip));
	editValueTimer3.SetTooltipCustomType(SetTooltip(Timer_ValTooltip));
	editValueTimer4.SetTooltipCustomType(SetTooltip(Timer_ValTooltip));
	Me.SetWindowTitle(Timer_WindowName);
}

function OnChangeEditBox (string strID)
{
	switch (strID)
	{
		case "editNameT1":
		Timer_Name[1] = Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editNameT1");
		SetINIString("Timer","Timer1_Name",Timer_Name[1],"Option");
		break;
		case "editNameT2":
		Timer_Name[2] = Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editNameT2");
		SetINIString("Timer","Timer2_Name",Timer_Name[2],"Option");
		break;
		case "editNameT3":
		Timer_Name[3] = Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editNameT3");
		SetINIString("Timer","Timer3_Name",Timer_Name[3],"Option");
		break;
		case "editNameT4":
		Timer_Name[4] = Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editNameT4");
		SetINIString("Timer","Timer4_Name",Timer_Name[4],"Option");
		break;
		case "editValueTimer1":
		Timer_UserSerconds[1] = int(Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editValueTimer1"));
		SetINIInt("Timer","Timer1_UserSerconds",Timer_UserSerconds[1],"Option");
		break;
		case "editValueTimer2":
		Timer_UserSerconds[2] = int(Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editValueTimer2"));
		SetINIInt("Timer","Timer2_UserSerconds",Timer_UserSerconds[2],"Option");
		break;
		case "editValueTimer3":
		Timer_UserSerconds[3] = int(Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editValueTimer3"));
		SetINIInt("Timer","Timer3_UserSerconds",Timer_UserSerconds[3],"Option");
		break;
		case "editValueTimer4":
		Timer_UserSerconds[4] = int(Class'UIAPI_EDITBOX'.GetString("InterfaceAI_TimerWnd.editValueTimer4"));
		SetINIInt("Timer","Timer4_UserSerconds",Timer_UserSerconds[4],"Option");
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnTimerStart1":
		OnClickTimerStart(1);
		break;
		case "btnTimerStart2":
		OnClickTimerStart(2);
		break;
		case "btnTimerStart3":
		OnClickTimerStart(3);
		break;
		case "btnTimerStart4":
		OnClickTimerStart(4);
		break;
		case "btnTimerStop1":
		ResetTimer(1);
		break;
		case "btnTimerStop2":
		ResetTimer(2);
		break;
		case "btnTimerStop3":
		ResetTimer(3);
		break;
		case "btnTimerStop4":
		ResetTimer(4);
		break;
		case "btnSecondStart":
		OnClickStartSeconds();
		break;
		case "btnSecondStop":
		OnClickStopSeconds();
		break;
		default:
	}
}

function OnClickCheckBox (string strID)
{
	switch (strID)
	{
		case "checkAlarmT1":
		if ( checkAlarmT1.IsChecked() )
		{
			UserUseAlarm[1] = 1;
		} else {
			UserUseAlarm[1] = 0;
		}
		SetINIBool("Timer","Timer1_UserUseAlarm",bool(UserUseAlarm[1]),"Option");
		break;
		case "checkAlarmT2":
		if ( checkAlarmT2.IsChecked() )
		{
			UserUseAlarm[2] = 1;
		} else {
			UserUseAlarm[2] = 0;
		}
		SetINIBool("Timer","Timer2_UserUseAlarm",bool(UserUseAlarm[2]),"Option");
		break;
		case "checkAlarmT3":
		if ( checkAlarmT3.IsChecked() )
		{
			UserUseAlarm[3] = 1;
		} else {
			UserUseAlarm[3] = 0;
		}
		SetINIBool("Timer","Timer3_UserUseAlarm",bool(UserUseAlarm[3]),"Option");
		break;
		case "checkAlarmT4":
		if ( checkAlarmT4.IsChecked() )
		{
			UserUseAlarm[4] = 1;
		} else {
			UserUseAlarm[4] = 0;
		}
		SetINIBool("Timer","Timer4_UserUseAlarm",bool(UserUseAlarm[4]),"Option");
		break;
		default:
	}
}

function OnClickTimerStart (int Type)
{
	Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[Type]);
	CurUserTime_Timer[Type] = GetUserTime();
	StartTimers(Type);
	Class'UIAPI_TEXTBOX'.SetTextColor(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(Type)),Green);
}

function StartTimers (int Type)
{
	local string SecondsText;
	local int DiffSeconds;

	DiffSeconds = UnknownFunction146(UnknownFunction147(CurUserTime_Timer[Type],GetUserTime()),Timer_UserSerconds[Type]);
	if ( UnknownFunction154(DiffSeconds,0) )
	{
		if ( UnknownFunction154(UserUseAlarm[Type],1) )
		{
			script.BeginShowTimerAlarmName(string(0),Timer_Name[Type],Timer_NotificationText_0,Timer_NotificationText_OverFinal);
		}
		SecondsText = "00:00";
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[Type]);
	} else {
		if ( UnknownFunction154(DiffSeconds,60) )
		{
			Class'UIAPI_TEXTBOX'.SetTextColor(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(Type)),Gold);
			if ( UnknownFunction154(UserUseAlarm[Type],1) )
			{
				script.BeginShowTimerAlarmName(string(60),Timer_Name[Type],Timer_NotificationText_60,Timer_NotificationText_Over);
			}
		}
		if ( UnknownFunction154(DiffSeconds,30) )
		{
			Class'UIAPI_TEXTBOX'.SetTextColor(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(Type)),Orange);
			if ( UnknownFunction154(UserUseAlarm[Type],1) )
			{
				script.BeginShowTimerAlarmName(string(30),Timer_Name[Type],Timer_NotificationText_30,Timer_NotificationText_Over);
			}
		}
		if ( UnknownFunction154(DiffSeconds,15) )
		{
			Class'UIAPI_TEXTBOX'.SetTextColor(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(Type)),Red);
		}
		SecondsText = ConvertSecondToStr(DiffSeconds);
		Class'UIAPI_WINDOW'.SetUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[Type],1000);
	}
	if ( UnknownFunction152(DiffSeconds,0) )
	{
		SecondsText = "00:00";
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[Type]);
	}
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112("InterfaceAI_TimerWnd.valTimer",string(Type)),SecondsText);
}

function OnTimer (int TimerID)
{
	if ( UnknownFunction154(TimerID,9900) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",9900);
		StartSeconds();
	}
	if ( UnknownFunction154(TimerID,TIMER_A_ID[1]) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[1]);
		StartTimers(1);
	}
	if ( UnknownFunction154(TimerID,TIMER_A_ID[2]) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[2]);
		StartTimers(2);
	}
	if ( UnknownFunction154(TimerID,TIMER_A_ID[3]) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[3]);
		StartTimers(3);
	}
	if ( UnknownFunction154(TimerID,TIMER_A_ID[4]) )
	{
		Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",TIMER_A_ID[4]);
		StartTimers(4);
	}
}

function OnClickStopSeconds ()
{
	Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",9900);
}

function OnClickStartSeconds ()
{
	Class'UIAPI_WINDOW'.KillUITimer("InterfaceAI_TimerWnd",9900);
	CurUserTime = GetUserTime();
	StartSeconds();
}

function StartSeconds ()
{
	local string SecondsText;

	SecondsText = ConvertSecondToStr(UnknownFunction147(GetUserTime(),CurUserTime));
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_TimerWnd.valSeconds",SecondsText);
	Class'UIAPI_WINDOW'.SetUITimer("InterfaceAI_TimerWnd",9900,1000);
}

function string ConvertSecondToStr (int FullSecond)
{
	local string resultString;
	local int Sec;
	local int Min;
	local string SecText;
	local string MinText;

	Sec = int(UnknownFunction173(FullSecond,60));
	SecText = string(Sec);
	Min = UnknownFunction145(FullSecond,60);
	MinText = string(Min);
	if ( UnknownFunction150(Sec,10) )
	{
		SecText = UnknownFunction112("0",string(Sec));
	}
	if ( UnknownFunction150(Min,10) )
	{
		MinText = UnknownFunction112("0",string(Min));
	}
	resultString = UnknownFunction112(UnknownFunction112(MinText,":"),SecText);
	return resultString;
}

function int GetUserTime ()
{
	local array<string> ArrayString;
	local int TempCount;
	local string UserFullTime;
	local int FullTime;

	UserFullTime = GetTimeString();
	TempCount = Split(UserFullTime,":",ArrayString);
	FullTime = UnknownFunction146(UnknownFunction146(int(ArrayString[2]),UnknownFunction144(int(ArrayString[1]),60)),UnknownFunction144(UnknownFunction144(int(ArrayString[0]),60),60));
	return FullTime;
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}


//================================================================================
// ClanWnd.
//================================================================================

class ClanWnd extends UICommonAPI;

var int m_clanID;
var string m_clanName;
var int m_clanRank;
var int m_clanLevel;
var int m_clanNameValue;
var int m_bMoreInfo;
var int m_currentShowIndex;
var int G_CurrentRecord;
var string G_CurrentSzData;
var bool G_CurrentAlias;
var bool G_IamNobless;
var bool G_IamHero;
var int G_ClanMember;
var string m_WindowName;
var int m_myClanType;
var string m_myName;
var string m_myClanName;
var int m_indexNum;
var bool m_currentactivestatus1;
var bool m_currentactivestatus2;
var bool m_currentactivestatus3;
var bool m_currentactivestatus4;
var bool m_currentactivestatus5;
var bool m_currentactivestatus6;
var bool m_currentactivestatus7;
var bool m_currentactivestatus8;
var int m_bClanMaster;
var int m_bJoin;
var int m_bNickName;
var int m_bCrest;
var int m_bWar;
var int m_bGrade;
var int m_bManageMaster;
var int m_bOustMember;
var string m_CurrentclanMasterName;
var string m_CurrentclanMasterReal;
var int m_CurrentNHType;
var array<ClanInfo> m_memberList;

function getmyClanInfo ()
{
	local UserInfo UserInfo;

	if ( GetPlayerInfo(UserInfo) )
	{
		m_myName = UserInfo.Name;
		m_myClanType = findmyClanData(m_myName);
		G_IamNobless = UserInfo.bNobless;
		G_IamHero = UserInfo.bHero;
		G_ClanMember = UserInfo.nClanID;
	}
}

function int findmyClanData (string C_Name)
{
	local int i;
	local int j;
	local int clannum;

	i = 0;
	if ( UnknownFunction150(i,m_memberList.Length) )
	{
		j = 0;
		if ( UnknownFunction150(j,m_memberList[i].m_array.Length) )
		{
			if ( UnknownFunction122(m_memberList[i].m_array[j].sName,C_Name) )
			{
				clannum = m_memberList[i].m_array[j].clanType;
			}
			UnknownFunction163(j);
			goto JL001E;
		}
		UnknownFunction163(i);
		goto JL0007;
	}
	return clannum;
}

function OnLoad ()
{
	RegisterEvents();
	m_memberList.Length = 8;
	m_currentShowIndex = 0;
	m_bMoreInfo = 0;
	G_CurrentAlias = False;
	Clear();
	m_currentactivestatus1 = False;
	m_currentactivestatus2 = False;
	m_currentactivestatus3 = False;
	m_currentactivestatus4 = False;
	m_currentactivestatus5 = False;
	m_currentactivestatus6 = False;
	m_currentactivestatus7 = False;
}

function RegisterEvents ()
{
	RegisterEvent(320);
	RegisterEvent(330);
	RegisterEvent(420);
	RegisterEvent(400);
	RegisterEvent(440);
	RegisterEvent(410);
	RegisterEvent(450);
	RegisterEvent(150);
	RegisterEvent(160);
	RegisterEvent(340);
	RegisterEvent(480);
}

function int GetClanTypeFromIndex (int Index)
{
	local int Type;

	if ( UnknownFunction154(Index,0) )
	{
		Type = 0;
	}
	if ( UnknownFunction154(Index,1) )
	{
		Type = 100;
	}
	if ( UnknownFunction154(Index,2) )
	{
		Type = 200;
	}
	if ( UnknownFunction154(Index,3) )
	{
		Type = 1001;
	}
	if ( UnknownFunction154(Index,4) )
	{
		Type = 1002;
	}
	if ( UnknownFunction154(Index,5) )
	{
		Type = 2001;
	}
	if ( UnknownFunction154(Index,6) )
	{
		Type = 2002;
	}
	if ( UnknownFunction154(Index,7) )
	{
		Type = -1;
	}
	return Type;
}

function string GetClanTypeNameFromIndex (int Index)
{
	local string Type;

	if ( UnknownFunction154(Index,0) )
	{
		Type = GetSystemString(1399);
	}
	if ( UnknownFunction154(Index,100) )
	{
		Type = GetSystemString(1400);
	}
	if ( UnknownFunction154(Index,200) )
	{
		Type = GetSystemString(1401);
	}
	if ( UnknownFunction154(Index,1001) )
	{
		Type = GetSystemString(1402);
	}
	if ( UnknownFunction154(Index,1002) )
	{
		Type = GetSystemString(1403);
	}
	if ( UnknownFunction154(Index,2001) )
	{
		Type = GetSystemString(1404);
	}
	if ( UnknownFunction154(Index,2002) )
	{
		Type = GetSystemString(1405);
	}
	if ( UnknownFunction154(Index,-1) )
	{
		Type = GetSystemString(1452);
	}
	return Type;
}

function OnShow ()
{
	local int i;

	getmyClanInfo();
	RefreshCombobox();
	resetBtnShowHide();
	NoblessMenuValidate();
JL0026:
	SetFocus();
	i = 10;
	if ( UnknownFunction153(i,0) )
	{
		if ( UnknownFunction154(Class'UIAPI_COMBOBOX'.GetReserved(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i),m_myClanType) )
		{
			Class'UIAPI_COMBOBOX'.SetSelectedNum(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i);
		}
		UnknownFunction164(i);
		goto JL0026;
	}
	ShowList(m_myClanType);
	Class'UIAPI_LISTCTRL'.SetSelectedIndex(UnknownFunction112(m_WindowName,".ClanMemberList"),m_indexNum,True);
	if ( UnknownFunction154(m_myClanType,-1) )
	{
		Class'UIAPI_LISTCTRL'.SetSelectedIndex(UnknownFunction112(m_WindowName,".ClanMemberList"),UnknownFunction147(m_indexNum,1),True);
	}
}

function NoblessMenuValidate ()
{
	if ( UnknownFunction154(G_ClanMember,0) )
	{
		if ( UnknownFunction132(UnknownFunction242(G_IamHero,True),UnknownFunction242(G_IamNobless,True)) )
		{
			Class'UIAPI_WINDOW'.ShowWindow(UnknownFunction112(m_WindowName,".HeroBtn"));
			Class'UIAPI_WINDOW'.HideWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
		} else {
			Class'UIAPI_WINDOW'.HideWindow(UnknownFunction112(m_WindowName,".HeroBtn"));
			Class'UIAPI_WINDOW'.ShowWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
		}
	} else {
		Class'UIAPI_WINDOW'.HideWindow(UnknownFunction112(m_WindowName,".HeroBtn"));
		Class'UIAPI_WINDOW'.ShowWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
	}
}

function OnHide ()
{
}

function OnEnterState (name a_PreStateName)
{
	getmyClanInfo();
	NoblessMenuValidate();
	if ( UnknownFunction254(a_PreStateName,'LoadingState') )
	{
		Clear();
	}
}

function OnClickButton (string strID)
{
	local ClanDrawerWnd script;
	local LVDataRecord Record;
	local string strParam;

	Record.LVDataList.Length = 10;
	script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
	if ( UnknownFunction122(strID,"ClanMemInfoBtn") )
	{
		if ( UnknownFunction242(m_currentactivestatus1,False) )
		{
			ResetOpeningVariables();
			m_currentactivestatus1 = True;
			if ( GetSelectedListCtrlItem(Record) )
			{
				RequestClanMemberInfo(Record.nReserved1,Record.LVDataList[0].szData);
				G_CurrentRecord = Record.nReserved1;
				G_CurrentSzData = Record.LVDataList[0].szData;
				if ( UnknownFunction122(Record.LVDataList[3].szData,"0") )
				{
					G_CurrentAlias = True;
				} else {
					G_CurrentAlias = False;
				}
				script.SetStateAndShow("ClanMemberInfoState");
			}
		} else {
			m_currentactivestatus1 = False;
			script.HideWindow();
		}
	} else {
		if ( UnknownFunction122(strID,"ClanMemAuthBtn") )
		{
			if ( UnknownFunction242(m_currentactivestatus2,False) )
			{
				ResetOpeningVariables();
				m_currentactivestatus2 = True;
				if ( GetSelectedListCtrlItem(Record) )
				{
					RequestClanMemberAuth(Record.nReserved1,Record.LVDataList[0].szData);
					script.SetStateAndShow("ClanMemberAuthState");
				}
			} else {
				m_currentactivestatus2 = False;
				script.HideWindow();
			}
		} else {
			if ( UnknownFunction122(strID,"ClanBoardBtn") )
			{
				ParamAdd(strParam,"Index","3");
				ExecuteEvent(1190,strParam);
			} else {
				if ( UnknownFunction122(strID,"ClanInfoBtn") )
				{
					if ( UnknownFunction242(m_currentactivestatus3,False) )
					{
						ResetOpeningVariables();
						m_currentactivestatus3 = True;
						script.SetStateAndShow("ClanInfoState");
					} else {
						m_currentactivestatus3 = False;
						script.HideWindow();
					}
				} else {
					if ( UnknownFunction122(strID,"ClanPenaltyBtn") )
					{
						ExecuteCommandFromAction("pledgepenalty");
					} else {
						if ( UnknownFunction122(strID,"ClanQuitBtn") )
						{
							RequestClanLeave(m_clanName,m_myClanType);
						} else {
							if ( UnknownFunction122(strID,"ClanWarInfoBtn") )
							{
								if ( UnknownFunction242(m_currentactivestatus5,False) )
								{
									ResetOpeningVariables();
									m_currentactivestatus5 = True;
									script.m_clanWarListPage = -1;
									RequestClanWarList(0,0);
									script.SetStateAndShow("ClanWarManagementWndState");
								} else {
									m_currentactivestatus5 = False;
									script.HideWindow();
								}
							} else {
								if ( UnknownFunction122(strID,"ClanWarDeclareBtn") )
								{
									RequestClanDeclareWar();
								} else {
									if ( UnknownFunction122(strID,"ClanWarCancleBtn") )
									{
										RequestClanWithdrawWar();
									} else {
										if ( UnknownFunction122(strID,"ClanAskJoinBtn") )
										{
											AskJoin();
										} else {
											if ( UnknownFunction122(strID,"ClanAuthEditBtn") )
											{
												if ( UnknownFunction242(m_currentactivestatus6,False) )
												{
													ResetOpeningVariables();
													m_currentactivestatus6 = True;
													RequestClanGradeList();
													script.SetStateAndShow("ClanAuthManageWndState");
												} else {
													m_currentactivestatus6 = False;
													script.HideWindow();
												}
											} else {
												if ( UnknownFunction122(strID,"ClanTitleManageBtn") )
												{
													if ( UnknownFunction242(m_currentactivestatus7,False) )
													{
														ResetOpeningVariables();
														m_currentactivestatus7 = True;
														script.SetStateAndShow("ClanEmblemManageWndState");
													} else {
														m_currentactivestatus7 = False;
														script.HideWindow();
													}
												} else {
													if ( UnknownFunction122(strID,"HeroBtn") )
													{
														if ( UnknownFunction242(m_currentactivestatus8,False) )
														{
															m_currentactivestatus8 = True;
															script.SetStateAndShow("ClanHeroWndState");
														} else {
															m_currentactivestatus8 = False;
															script.HideWindow();
														}
													} else {
														if ( UnknownFunction122(strID,"BtnClose") )
														{
															HideWindow("ClanWnd");
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 420:
		Clear();
		break;
		case 320:
		HandleClanInfo(a_Param);
		break;
		case 410:
		HandleAddClanMemberMultiple(a_Param);
		break;
		case 440:
		HandleMemberInfoUpdate(a_Param);
		break;
		case 400:
		HandleAddClanMember(a_Param);
		break;
		case 450:
		HandleDeleteMember(a_Param);
		break;
		case 330:
		HandleClanInfoUpdate(a_Param);
		break;
		case 480:
		HandleSubClanUpdated(a_Param);
		break;
		case 340:
		HandleClanMyAuth(a_Param);
		break;
		default:
		break;
	}
}

function OnComboBoxItemSelected (string sName, int Index)
{
	ClearList();
	ShowList(Class'UIAPI_COMBOBOX'.GetReserved(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),Class'UIAPI_COMBOBOX'.GetSelectedNum(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"))));
}

function OnClickListCtrlRecord (string ListCtrlID)
{
	local ClanDrawerWnd script;
	local LVDataRecord Record;

	Record.LVDataList.Length = 10;
	script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
	if ( UnknownFunction122(ListCtrlID,"ClanMemberList") )
	{
		if ( UnknownFunction242(m_currentactivestatus1,True) )
		{
			ResetOpeningVariables();
			m_currentactivestatus1 = True;
			if ( GetSelectedListCtrlItem(Record) )
			{
				RequestClanMemberInfo(Record.nReserved1,Record.LVDataList[0].szData);
				G_CurrentRecord = Record.nReserved1;
				G_CurrentSzData = Record.LVDataList[0].szData;
				if ( UnknownFunction122(Record.LVDataList[3].szData,"0") )
				{
					G_CurrentAlias = True;
				} else {
					G_CurrentAlias = False;
				}
				script.SetStateAndShow("ClanMemberInfoState");
			}
		}
		if ( UnknownFunction242(m_currentactivestatus2,True) )
		{
			ResetOpeningVariables();
			m_currentactivestatus2 = True;
			if ( GetSelectedListCtrlItem(Record) )
			{
				RequestClanMemberAuth(Record.nReserved1,Record.LVDataList[0].szData);
				script.SetStateAndShow("ClanMemberAuthState");
			}
		}
	}
}

function OnDBClickListCtrlRecord (string ListCtrlID)
{
	local ClanDrawerWnd script;
	local LVDataRecord Record;

	Record.LVDataList.Length = 10;
	script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
	if ( UnknownFunction122(ListCtrlID,"ClanMemberList") )
	{
		if ( UnknownFunction242(m_currentactivestatus1,False) )
		{
			ResetOpeningVariables();
			m_currentactivestatus1 = True;
			if ( GetSelectedListCtrlItem(Record) )
			{
				RequestClanMemberInfo(Record.nReserved1,Record.LVDataList[0].szData);
				G_CurrentRecord = Record.nReserved1;
				G_CurrentSzData = Record.LVDataList[0].szData;
				if ( UnknownFunction122(Record.LVDataList[3].szData,"0") )
				{
					G_CurrentAlias = True;
				} else {
					G_CurrentAlias = False;
				}
				script.SetStateAndShow("ClanMemberInfoState");
			}
		} else {
			ResetOpeningVariables();
			m_currentactivestatus1 = True;
			if ( GetSelectedListCtrlItem(Record) )
			{
				RequestClanMemberInfo(Record.nReserved1,Record.LVDataList[0].szData);
				G_CurrentRecord = Record.nReserved1;
				G_CurrentSzData = Record.LVDataList[0].szData;
				script.SetStateAndShow("ClanMemberInfoState");
			}
		}
	}
}

function resetBtnShowHide ()
{
	local ClanDrawerWnd script;

	script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
	NoblessMenuValidate();
	if ( UnknownFunction154(m_clanID,0) )
	{
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
		Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
	} else {
		if ( UnknownFunction151(m_clanLevel,5) )
		{
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
			Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
			Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
			Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
			Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
			Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
			Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
		} else {
			switch (m_clanLevel)
			{
				case 0:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				case 1:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				case 2:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				case 3:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				case 4:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				case 5:
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanMemAuthBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanBoardBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanPenaltyBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarInfoBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
				Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
				Class'UIAPI_WINDOW'.EnableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
				break;
				default:
			}
		}
		if ( UnknownFunction151(m_bClanMaster,0) )
		{
			Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanQuitBtn"));
			if ( UnknownFunction151(m_clanLevel,2) )
			{
				Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
			}
			Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanAuthEditBtn"));
		} else {
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberNameBtn");
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeBanishBtn");
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_ChangeMemberGradeBtn");
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_AssignApprenticeBtn");
			Class'UIAPI_WINDOW'.DisableWindow("ClanDrawerWnd.Clan1_DeleteApprenticeBtn");
			if ( UnknownFunction154(m_bJoin,0) )
			{
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanAskJoinBtn"));
			}
			if ( UnknownFunction154(m_bCrest,0) )
			{
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
			} else {
				if ( UnknownFunction151(m_clanLevel,2) )
				{
					Class'UIAPI_WINDOW'.EnableWindow(UnknownFunction112(m_WindowName,".ClanTitleManageBtn"));
				}
			}
			if ( UnknownFunction154(m_bWar,0) )
			{
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarDeclareBtn"));
				Class'UIAPI_WINDOW'.DisableWindow(UnknownFunction112(m_WindowName,".ClanWarCancleBtn"));
			}
		}
		script.CheckandCompareMyNameandDisableThings();
	}
	NoblessMenuValidate();
}

function Clear ()
{
	local ClanDrawerWnd script;
	local int i;

	ClearList();
	script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
	script.Clear();
	Class'UIAPI_WINDOW'.HideWindow("ClanDrawerWnd");
	Class'UIAPI_WINDOW'.HideWindow("InviteClanPopWnd");
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanNameText"),"");
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanMasterNameText"),"");
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetSystemString(27));
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),"");
	Class'UIAPI_TEXTBOX'.SetInt(UnknownFunction112(m_WindowName,".ClanLevelText"),0);
	Class'UIAPI_COMBOBOX'.Clear(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"));
	m_clanID = 0;
	m_clanName = "";
	m_clanRank = 0;
	m_clanLevel = 0;
	m_clanNameValue = 0;
	m_bMoreInfo = 0;
	m_currentShowIndex = 0;
	m_bClanMaster = 0;
	m_bJoin = 0;
	m_bNickName = 0;
	m_bCrest = 0;
	m_bWar = 0;
	m_bGrade = 0;
	m_bManageMaster = 0;
	m_bOustMember = 0;
	i = 0;
	if ( UnknownFunction150(i,8) )
	{
		m_memberList[i].m_array.Remove (0,m_memberList[i].m_array.Length);
		m_memberList[i].m_sName = "";
		m_memberList[i].m_sMasterName = "";
		UnknownFunction163(i);
		goto JL01E2;
	}
}

function HandleClanInfo (string a_Param)
{
	local string clanMasterName;
	local string ClanName;
	local int crestID;
	local int SkillLevel;
	local int castleID;
	local int agitID;
	local int Status;
	local int bGuilty;
	local int allianceID;
	local string allianceName;
	local int AllianceCrestID;
	local int bInWar;
	local int clanType;
	local int clanRank;
	local int clanNameValue;
	local int clanID;

	ParseInt(a_Param,"ClanID",clanID);
	ParseInt(a_Param,"ClanType",clanType);
	m_CurrentNHType = clanType;
	ParseString(a_Param,"ClanName",ClanName);
	ParseString(a_Param,"ClanMasterName",clanMasterName);
	m_CurrentclanMasterName = clanMasterName;
	if ( UnknownFunction154(clanType,0) )
	{
		m_CurrentclanMasterReal = clanMasterName;
	}
	ParseInt(a_Param,"CrestID",crestID);
	ParseInt(a_Param,"SkillLevel",SkillLevel);
	ParseInt(a_Param,"CastleID",castleID);
	ParseInt(a_Param,"AgitID",agitID);
	ParseInt(a_Param,"ClanRank",clanRank);
	ParseInt(a_Param,"ClanNameValue",clanNameValue);
	ParseInt(a_Param,"Status",Status);
	ParseInt(a_Param,"Guilty",bGuilty);
	ParseInt(a_Param,"AllianceID",allianceID);
	ParseString(a_Param,"AllianceName",allianceName);
	ParseInt(a_Param,"AllianceCrestID",AllianceCrestID);
	ParseInt(a_Param,"InWar",bInWar);
	if ( UnknownFunction154(clanType,0) )
	{
		m_clanName = ClanName;
		m_clanRank = clanRank;
		m_clanNameValue = clanNameValue;
		m_clanLevel = SkillLevel;
		m_clanID = clanID;
	}
	m_memberList[GetIndexFromType(clanType)].m_sName = ClanName;
	m_memberList[GetIndexFromType(clanType)].m_sMasterName = clanMasterName;
	if ( UnknownFunction154(clanType,0) )
	{
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanNameText"),ClanName);
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanMasterNameText"),m_CurrentclanMasterReal);
		if ( UnknownFunction151(agitID,0) )
		{
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetCastleName(agitID));
		} else {
			if ( UnknownFunction151(castleID,0) )
			{
				Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetCastleName(castleID));
			} else {
				Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetSystemString(27));
			}
		}
		if ( UnknownFunction154(Status,3) )
		{
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(341));
		} else {
			if ( UnknownFunction154(bInWar,0) )
			{
				Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(894));
			} else {
				Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(340));
			}
		}
		Class'UIAPI_TEXTBOX'.SetInt(UnknownFunction112(m_WindowName,".ClanLevelText"),SkillLevel);
	}
	RefreshCombobox();
	getmyClanInfo();
}

function HandleClanInfoUpdate (string a_Param)
{
	local int PledgeCrestID;
	local int castleID;
	local int agitID;
	local int Status;
	local int bGuilty;
	local int allianceID;
	local string sAllianceName;
	local int AllianceCrestID;
	local int InWar;
	local int LargePledgeCrestID;
	local ClanDrawerWnd script;

	ParseInt(a_Param,"ClanID",m_clanID);
	ParseInt(a_Param,"CrestID",PledgeCrestID);
	ParseInt(a_Param,"SkillLevel",m_clanLevel);
	ParseInt(a_Param,"CastleID",castleID);
	ParseInt(a_Param,"AgitID",agitID);
	ParseInt(a_Param,"ClanRank",m_clanRank);
	ParseInt(a_Param,"ClanNameValue",m_clanNameValue);
	ParseInt(a_Param,"Status",Status);
	ParseInt(a_Param,"Guilty",bGuilty);
	ParseInt(a_Param,"AllianceID",allianceID);
	ParseString(a_Param,"AllianceName",sAllianceName);
	ParseInt(a_Param,"AllianceCrestID",AllianceCrestID);
	ParseInt(a_Param,"InWar",InWar);
	ParseInt(a_Param,"LargeCrestID",LargePledgeCrestID);
	if ( Class'UIAPI_WINDOW'.IsShowWindow("ClanDrawerWnd.ClanInfoWnd") )
	{
		script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
		script.InitializeClanInfoWnd();
	}
	if ( UnknownFunction151(agitID,0) )
	{
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetCastleName(agitID));
	} else {
		if ( UnknownFunction151(castleID,0) )
		{
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetCastleName(castleID));
		} else {
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanAgitText"),GetSystemString(27));
		}
	}
	if ( UnknownFunction154(Status,3) )
	{
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(341));
	} else {
		if ( UnknownFunction154(InWar,0) )
		{
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(894));
		} else {
			Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanStatusText"),GetSystemString(340));
		}
	}
	Class'UIAPI_TEXTBOX'.SetInt(UnknownFunction112(m_WindowName,".ClanLevelText"),m_clanLevel);
	resetBtnShowHide();
	getmyClanInfo();
}

function HandleAddClanMemberMultiple (string a_Param)
{
	local ClanMemberInfo Info;
	local int Count;
	local int Index;

	ParseInt(a_Param,"ClanType",Info.clanType);
	Index = GetIndexFromType(Info.clanType);
	ParseString(a_Param,"Name",Info.sName);
	ParseInt(a_Param,"Level",Info.Level);
	ParseInt(a_Param,"Class",Info.ClassID);
	ParseInt(a_Param,"Gender",Info.gender);
	ParseInt(a_Param,"Race",Info.race);
	ParseInt(a_Param,"ID",Info.Id);
	ParseInt(a_Param,"HaveMaster",Info.bHaveMaster);
	Count = m_memberList[Index].m_array.Length;
	m_memberList[Index].m_array.Length = UnknownFunction146(Count,1);
	m_memberList[Index].m_array[Count] = Info;
	if ( UnknownFunction154(Index,m_currentShowIndex) )
	{
		ShowList(Info.clanType);
	}
}

function ClearList ()
{
	Class'UIAPI_LISTCTRL'.DeleteAllItem(UnknownFunction112(m_WindowName,".ClanMemberList"));
}

function ShowList (int clanType)
{
	local int Index;

	Index = GetIndexFromType(clanType);
	m_currentShowIndex = Index;
	ClearList();
	AddToList(Index);
}

function int getClanKnighthoodMasterInfo (string NameVal)
{
	local int i;
	local int ReturnVal;

	i = 0;
	if ( UnknownFunction150(i,m_memberList[0].m_array.Length) )
	{
		if ( UnknownFunction122(m_memberList[0].m_array[i].sName,NameVal) )
		{
			ReturnVal = i;
		}
		UnknownFunction163(i);
		goto JL0007;
	}
	return ReturnVal;
}

function AddToList (int idx)
{
	local Color White;
	local Color Yellow;
	local Color Blue;
	local Color BrightWhite;
	local Color Gold;
	local int i;
	local int OnLineNum;
	local LVDataRecord Record;

	BrightWhite.R = 255;
	BrightWhite.G = 255;
	BrightWhite.B = 255;
	White.R = 170;
	White.G = 170;
	White.B = 170;
	Yellow.R = 235;
	Yellow.G = 205;
	Yellow.B = 0;
	Blue.R = 102;
	Blue.G = 150;
	Blue.B = 253;
	Gold.R = 176;
	Gold.G = 153;
	Gold.B = 121;
	OnLineNum = 0;
	Record.LVDataList.Length = 4;
	if ( UnknownFunction152(GetClanTypeFromIndex(m_currentShowIndex),0) )
	{
		goto JL0441;
	}
	if ( UnknownFunction122(m_memberList[m_currentShowIndex].m_sMasterName,"") )
	{
		i = getClanKnighthoodMasterInfo(m_memberList[m_currentShowIndex].m_sMasterName);
		Record.LVDataList[0].bUseTextColor = True;
		Record.LVDataList[0].szData = GetSystemString(1445);
		Record.LVDataList[0].TextColor = Gold;
		Record.LVDataList[1].szData = "";
		Record.LVDataList[2].szData = "";
		Class'UIAPI_LISTCTRL'.InsertRecord(UnknownFunction112(m_WindowName,".ClanMemberList"),Record);
	} else {
		i = getClanKnighthoodMasterInfo(m_memberList[m_currentShowIndex].m_sMasterName);
		Record.LVDataList[0].bUseTextColor = True;
		Record.LVDataList[0].szData = m_memberList[m_currentShowIndex].m_sMasterName;
		Record.LVDataList[0].TextColor = Gold;
		Record.LVDataList[1].bUseTextColor = True;
		Record.LVDataList[1].TextColor = White;
		Record.LVDataList[1].szData = string(m_memberList[0].m_array[i].Level);
		Record.LVDataList[2].szData = string(m_memberList[0].m_array[i].ClassID);
		Record.LVDataList[2].szTexture = GetClassIconName(m_memberList[0].m_array[i].ClassID);
		Record.LVDataList[2].nTextureWidth = 11;
		Record.LVDataList[2].nTextureHeight = 11;
		Record.LVDataList[3].nTextureWidth = 31;
		Record.LVDataList[3].nTextureHeight = 11;
		Record.nReserved1 = 0;
		if ( UnknownFunction151(m_memberList[0].m_array[i].Id,0) )
		{
			Record.LVDataList[3].szData = "0";
			Record.LVDataList[3].szTexture = "L2UI_CH3.BloodHoodWnd.BloodHood_Logon";
			OnLineNum = UnknownFunction165(OnLineNum);
		} else {
			Record.LVDataList[3].szData = "0";
			Record.LVDataList[3].szTexture = "L2UI_CH3.BloodHoodWnd.BloodHood_Logoff";
		}
		Class'UIAPI_LISTCTRL'.InsertRecord(UnknownFunction112(m_WindowName,".ClanMemberList"),Record);
	}
	i = 0;
	i = 0;
	if ( UnknownFunction150(i,m_memberList[idx].m_array.Length) )
	{
		Record.LVDataList[0].bUseTextColor = True;
		Record.LVDataList[0].szData = m_memberList[idx].m_array[i].sName;
		if ( UnknownFunction154(m_memberList[idx].m_array[i].bHaveMaster,0) )
		{
			Record.LVDataList[0].TextColor = White;
		} else {
			Record.LVDataList[0].TextColor = Yellow;
		}
		if ( UnknownFunction122(m_memberList[idx].m_array[i].sName,m_myName) )
		{
			Record.LVDataList[0].TextColor = BrightWhite;
			Record.LVDataList[1].TextColor = BrightWhite;
			if ( UnknownFunction154(GetClanTypeFromIndex(m_currentShowIndex),0) )
			{
				m_indexNum = i;
			} else {
				m_indexNum = UnknownFunction146(i,1);
			}
		}
		Record.LVDataList[1].bUseTextColor = True;
		if ( UnknownFunction122(m_memberList[idx].m_array[i].sName,m_myName) )
		{
			Record.LVDataList[1].TextColor = BrightWhite;
		} else {
			Record.LVDataList[1].TextColor = White;
		}
		Record.LVDataList[1].szData = string(m_memberList[idx].m_array[i].Level);
		Record.LVDataList[2].szData = string(m_memberList[idx].m_array[i].ClassID);
		Record.LVDataList[2].szTexture = GetClassIconName(m_memberList[idx].m_array[i].ClassID);
		Record.LVDataList[2].nTextureWidth = 11;
		Record.LVDataList[2].nTextureHeight = 11;
		Record.LVDataList[3].nTextureWidth = 31;
		Record.LVDataList[3].nTextureHeight = 11;
		Record.nReserved1 = m_memberList[idx].m_array[i].clanType;
		if ( UnknownFunction151(m_memberList[idx].m_array[i].Id,0) )
		{
			Record.LVDataList[3].szData = "1";
			Record.LVDataList[3].szTexture = "L2UI_CH3.BloodHoodWnd.BloodHood_Logon";
			OnLineNum = UnknownFunction165(OnLineNum);
		} else {
			Record.LVDataList[3].szData = "2";
			Record.LVDataList[3].szTexture = "L2UI_CH3.BloodHoodWnd.BloodHood_Logoff";
		}
		Class'UIAPI_LISTCTRL'.InsertRecord(UnknownFunction112(m_WindowName,".ClanMemberList"),Record);
		UnknownFunction163(i);
		goto JL0448;
	}
	if ( UnknownFunction152(GetClanTypeFromIndex(m_currentShowIndex),0) )
	{
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanCurrentNum"),UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("(",string(OnLineNum)),"/"),string(m_memberList[idx].m_array.Length)),")"));
	} else {
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(m_WindowName,".ClanCurrentNum"),UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("(",string(OnLineNum)),"/"),string(UnknownFunction146(m_memberList[idx].m_array.Length,1))),")"));
	}
}

function bool GetSelectedListCtrlItem (out LVDataRecord Record)
{
	local int Index;

	Index = Class'UIAPI_LISTCTRL'.GetSelectedIndex(UnknownFunction112(m_WindowName,".ClanMemberList"));
	if ( UnknownFunction153(Index,0) )
	{
		Record = Class'UIAPI_LISTCTRL'.GetRecord(UnknownFunction112(m_WindowName,".ClanMemberList"),Index);
		return True;
	}
	return False;
}

function HandleMemberInfoUpdate (string a_Param)
{
	local ClanMemberInfo Info;
	local int i;
	local int j;
	local int Count;
	local ClanDrawerWnd script;
	local bool bHaveMasterChanged;
	local bool bMemberChanged;
	local int process_length;
	local int process_clanindex;

	bHaveMasterChanged = False;
	bMemberChanged = False;
	ParseString(a_Param,"Name",Info.sName);
	ParseInt(a_Param,"Level",Info.Level);
	ParseInt(a_Param,"Class",Info.ClassID);
	ParseInt(a_Param,"Gender",Info.gender);
	ParseInt(a_Param,"Race",Info.race);
	ParseInt(a_Param,"ID",Info.Id);
	ParseInt(a_Param,"PledgeType",Info.clanType);
	ParseInt(a_Param,"HaveMaster",Info.bHaveMaster);
	i = 0;
	if ( UnknownFunction150(i,8) )
	{
		Count = m_memberList[i].m_array.Length;
		j = 0;
		if ( UnknownFunction150(j,Count) )
		{
			if ( UnknownFunction122(m_memberList[i].m_array[j].sName,Info.sName) )
			{
				if ( UnknownFunction155(m_memberList[i].m_array[j].bHaveMaster,Info.bHaveMaster) )
				{
					bHaveMasterChanged = True;
					m_memberList[i].m_array[j] = Info;
					Debug("???? ?? ??? ????222");
				}
				if ( UnknownFunction155(m_memberList[i].m_array[j].clanType,Info.clanType) )
				{
					bMemberChanged = True;
					Debug("???? ??");
					m_memberList[i].m_array.Remove (j,1);
					process_clanindex = GetIndexFromType(Info.clanType);
					process_length = m_memberList[process_clanindex].m_array.Length;
					byte(m_memberList[process_clanindex].m_array)
					process_length
					1
					m_memberList[process_clanindex].m_array[process_length].sName = Info.sName;
					m_memberList[process_clanindex].m_array[process_length].clanType = Info.clanType;
					m_memberList[process_clanindex].m_array[process_length].Level = Info.Level;
					m_memberList[process_clanindex].m_array[process_length].ClassID = Info.ClassID;
					m_memberList[process_clanindex].m_array[process_length].gender = Info.gender;
					m_memberList[process_clanindex].m_array[process_length].race = Info.race;
					m_memberList[process_clanindex].m_array[process_length].Id = Info.Id;
					m_memberList[process_clanindex].m_array[process_length].bHaveMaster = Info.bHaveMaster;
					Class'UIAPI_TEXTBOX'.SetText("ClanDrawerWnd.Clan1_CurrentSelectedMemberGrade","");
					ShowList(Info.clanType);
				} else {
					m_memberList[i].m_array[j] = Info;
					ShowList(Info.clanType);
				}
			} else {
				UnknownFunction163(j);
				goto JL0127;
			}
		}
		if ( UnknownFunction150(j,Count) )
		{
			goto JL043E;
		}
		UnknownFunction163(i);
		goto JL00FD;
	}
	if ( UnknownFunction130(bHaveMasterChanged,Class'UIAPI_WINDOW'.IsShowWindow("ClanDrawerWnd.ClanMemberInfoWnd")) )
	{
		script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
		if ( UnknownFunction122(script.m_currentName,Info.sName) )
		{
			RequestClanMemberInfo(Info.clanType,Info.sName);
		}
		if ( UnknownFunction154(GetIndexFromType(Info.clanType),m_currentShowIndex) )
		{
			ShowList(Info.clanType);
		}
		ShowList(m_currentShowIndex);
	}
	if ( UnknownFunction130(bMemberChanged,Class'UIAPI_WINDOW'.IsShowWindow("ClanDrawerWnd.ClanMemberInfoWnd")) )
	{
		ClearList();
		ShowList(Info.clanType);
		RefreshCombobox1(Info.clanType);
	}
}

function RefreshCombobox1 (int ClanT)
{
	local int i;

	i = 0;
	if ( UnknownFunction150(i,10) )
	{
		if ( UnknownFunction154(Class'UIAPI_COMBOBOX'.GetReserved(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i),ClanT) )
		{
			Class'UIAPI_COMBOBOX'.SetSelectedNum(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i);
			Debug(UnknownFunction168("CurrentSelected:",string(i)));
		}
		UnknownFunction163(i);
		goto JL0007;
	}
}

function HandleAddClanMember (string a_Param)
{
	local int Count;
	local ClanMemberInfo Info;

	ParseString(a_Param,"Name",Info.sName);
	ParseInt(a_Param,"Level",Info.Level);
	ParseInt(a_Param,"Class",Info.ClassID);
	ParseInt(a_Param,"Gender",Info.gender);
	ParseInt(a_Param,"Race",Info.race);
	ParseInt(a_Param,"ID",Info.Id);
	ParseInt(a_Param,"ClanType",Info.clanType);
	Info.bHaveMaster = 0;
	Count = m_memberList[GetIndexFromType(Info.clanType)].m_array.Length;
	m_memberList[GetIndexFromType(Info.clanType)].m_array.Length = UnknownFunction146(Count,1);
	m_memberList[GetIndexFromType(Info.clanType)].m_array[Count] = Info;
	if ( UnknownFunction154(GetIndexFromType(Info.clanType),m_currentShowIndex) )
	{
		ShowList(Info.clanType);
	}
}

function int GetIndexFromType (int Type)
{
	local int i;

	i = -1;
	if ( UnknownFunction154(Type,0) )
	{
		i = 0;
	} else {
		if ( UnknownFunction154(Type,100) )
		{
			i = 1;
		} else {
			if ( UnknownFunction154(Type,200) )
			{
				i = 2;
			} else {
				if ( UnknownFunction154(Type,1001) )
				{
					i = 3;
				} else {
					if ( UnknownFunction154(Type,1002) )
					{
						i = 4;
					} else {
						if ( UnknownFunction154(Type,2001) )
						{
							i = 5;
						} else {
							if ( UnknownFunction154(Type,2002) )
							{
								i = 6;
							} else {
								if ( UnknownFunction154(Type,-1) )
								{
									i = 7;
								}
							}
						}
					}
				}
			}
		}
	}
	return i;
}

function HandleDeleteMember (string a_Param)
{
	local int i;
	local int j;
	local int k;
	local int Count;
	local string sName;

	ParseString(a_Param,"Name",sName);
	i = 0;
	if ( UnknownFunction150(i,8) )
	{
		Count = m_memberList[i].m_array.Length;
		j = 0;
JL0047:
		if ( UnknownFunction150(j,Count) )
		{
			if ( UnknownFunction122(m_memberList[i].m_array[j].sName,sName) )
			{
				k = j;
				if ( UnknownFunction150(k,UnknownFunction147(Count,1)) )
				{
					m_memberList[i].m_array[k] = m_memberList[i].m_array[UnknownFunction146(k,1)];
					UnknownFunction163(k);
					goto JL0086;
				}
				m_memberList[i].m_array.Length = UnknownFunction147(Count,1);
			} else {
				UnknownFunction163(j);
				goto JL0047;
			}
		}
		if ( UnknownFunction150(j,Count) )
		{
			goto JL0115;
		}
		UnknownFunction163(i);
		goto JL001D;
	}
	if ( UnknownFunction154(i,m_currentShowIndex) )
	{
		ShowList(i);
	}
}

function RefreshCombobox ()
{
	local int i;
	local int Index;
	local int newIndex;
	local int addedCount;

	Index = Class'UIAPI_COMBOBOX'.GetSelectedNum(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"));
	Class'UIAPI_COMBOBOX'.Clear(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"));
	addedCount = -1;
	i = 0;
	if ( UnknownFunction150(i,8) )
	{
		if ( UnknownFunction123(m_memberList[i].m_sName,"") )
		{
			Class'UIAPI_COMBOBOX'.AddStringWithReserved(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),UnknownFunction168(UnknownFunction168(GetClanTypeNameFromIndex(GetClanTypeFromIndex(i)),"-"),m_memberList[i].m_sName),GetClanTypeFromIndex(i));
			UnknownFunction163(addedCount);
			if ( UnknownFunction154(i,m_currentShowIndex) )
			{
				newIndex = addedCount;
			}
		}
		UnknownFunction163(i);
		goto JL0070;
	}
	i = 0;
	if ( UnknownFunction150(i,10) )
	{
		if ( UnknownFunction154(Class'UIAPI_COMBOBOX'.GetReserved(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i),m_myClanType) )
		{
			Class'UIAPI_COMBOBOX'.SetSelectedNum(UnknownFunction112(m_WindowName,".ComboboxMainClanWnd"),i);
		}
		UnknownFunction163(i);
		goto JL0124;
	}
}

function HandleSubClanUpdated (string a_Param)
{
	local int Id;
	local int Type;
	local string sName;
	local string sMasterName;
	local ClanDrawerWnd script;

	ParseInt(a_Param,"ClanID",Id);
	ParseInt(a_Param,"ClanType",Type);
	ParseString(a_Param,"ClanName",sName);
	ParseString(a_Param,"MasterName",sMasterName);
	m_memberList[GetIndexFromType(Type)].m_sName = sName;
	m_memberList[GetIndexFromType(Type)].m_sMasterName = sMasterName;
	RefreshCombobox();
	if ( Class'UIAPI_WINDOW'.IsShowWindow("ClanDrawerWnd.ClanInfoWnd") )
	{
		script = ClanDrawerWnd(GetScript("ClanDrawerWnd"));
		script.InitializeClanInfoWnd();
	}
}

function AskJoin ()
{
	local UserInfo User;

	if ( GetTargetInfo(User) )
	{
		if ( UnknownFunction151(User.nID,0) )
		{
			Class'UIAPI_WINDOW'.ShowWindow("InviteClanPopWnd");
		}
	}
}

function HandleClanMyAuth (string a_Param)
{
	ParseInt(a_Param,"ClanMaster",m_bClanMaster);
	ParseInt(a_Param,"Join",m_bJoin);
	ParseInt(a_Param,"NickName",m_bNickName);
	ParseInt(a_Param,"ClanCrest",m_bCrest);
	ParseInt(a_Param,"War",m_bWar);
	ParseInt(a_Param,"Grade",m_bGrade);
	ParseInt(a_Param,"ManageMaster",m_bManageMaster);
	ParseInt(a_Param,"OustMember",m_bOustMember);
	resetBtnShowHide();
}

function ResetOpeningVariables ()
{
	m_currentactivestatus1 = False;
	m_currentactivestatus2 = False;
	m_currentactivestatus3 = False;
	m_currentactivestatus4 = False;
	m_currentactivestatus5 = False;
	m_currentactivestatus6 = False;
	m_currentactivestatus7 = False;
	m_currentactivestatus8 = False;
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.title0");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.title1");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.title2");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.title3");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanNameText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanMasterNameText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanMasterNameText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanAgitText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanStatusText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanLevelText");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanCurrentNum");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ComboboxMainClanWnd");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanMemberList");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanMemInfoBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.HeroBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanMemAuthBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanBoardBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanInfoBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanPenaltyBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanQuitBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanWarInfoBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanWarDeclareBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanWarCancleBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanAskJoinBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanAuthEditBtn");
	Class'UIAPI_WINDOW'.SetFocus("ClanWnd.ClanTitleManageBtn");
}

defaultproperties
{
    m_WindowName="ClanWnd"

}

//================================================================================
// NPHRN_MiniMapHandler_NEW.
//================================================================================

class NPHRN_MiniMapHandler_NEW extends UICommonAPI;

function OnClickButton (string param)
{
	switch (param)
	{
		case "BtnOpt":
		ToggleOpenCurtain();
		break;
		default:
	}
}

function ToggleOpenCurtain ()
{
	if ( IsShowWindow("NPHRN_MinimapWnd_NEW.Curtain") )
	{
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MinimapWnd_NEW.Curtain");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MinimapWnd_NEW.Curtain");
		Class'UIAPI_WINDOW'.SetFocus("NPHRN_MinimapWnd_NEW.Curtain");
	}
}


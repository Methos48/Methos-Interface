//================================================================================
// ItemEnchantWnd.
//================================================================================

class ItemEnchantWnd extends UICommonAPI;

var WindowHandle Me;
var ItemWindowHandle ItemWnd;

function OnLoad ()
{
	RegisterEvent(2860);
	RegisterEvent(2870);
	RegisterEvent(2880);
	RegisterEvent(2890);
	Me = GetHandle("ItemEnchantWnd");
	ItemWnd = ItemWindowHandle(GetHandle("ItemEnchantWnd.ItemWnd"));
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,2860) )
	{
		HandleEnchantShow(param);
	} else {
		if ( UnknownFunction154(Event_ID,2870) )
		{
			HandleEnchantHide();
		} else {
			if ( UnknownFunction154(Event_ID,2880) )
			{
				HandleEnchantItemList(param);
			} else {
				if ( UnknownFunction154(Event_ID,2890) )
				{
					HandleEnchantResult(param);
				}
			}
		}
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnOK":
		OnOKClick();
		break;
		case "btnCancel":
		OnCancelClick();
		break;
		default:
	}
}

function OnOKClick ()
{
	local ItemInfo infItem;

	ItemWnd.GetSelectedItem(infItem);
	if ( UnknownFunction151(infItem.ServerID,0) )
	{
		Class'EnchantAPI'.RequestEnchantItem(infItem.ServerID);
	}
}

function OnCancelClick ()
{
	Class'EnchantAPI'.RequestEnchantItem(-1);
	Me.HideWindow();
	Clear();
}

function Clear ()
{
	ItemWnd.Clear();
}

function HandleEnchantShow (string param)
{
	local int ClassID;

	if ( UnknownFunction132(Class'UIAPI_WINDOW'.IsShowWindow("EnchantAIWnd"),Class'UIAPI_WINDOW'.IsMinimizedWindow("EnchantAIWnd")) )
	{
		goto JL00BC;
	}
	Clear();
	ParseInt(param,"ClassID",ClassID);
	Me.SetWindowTitle(UnknownFunction112(UnknownFunction112(UnknownFunction112(GetSystemString(1220),"("),Class'UIDATA_ITEM'.GetItemName(ClassID)),")"));
	Me.ShowWindow();
	Me.SetFocus();
}

function HandleEnchantHide ()
{
	Me.HideWindow();
	Clear();
}

function HandleEnchantItemList (string param)
{
	local ItemInfo infItem;

	ParamToItemInfo(param,infItem);
	ItemWnd.AddItem(infItem);
}

function HandleEnchantResult (string param)
{
	Me.HideWindow();
	Clear();
}


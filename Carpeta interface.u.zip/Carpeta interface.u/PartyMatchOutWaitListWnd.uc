//================================================================================
// PartyMatchOutWaitListWnd.
//================================================================================

class PartyMatchOutWaitListWnd extends PartyMatchWndCommon;

var int entire_page;
var int current_page;
var int MinLevel;
var int MaxLevel;

function OnLoad ()
{
	RegisterEvent(1610);
	RegisterEvent(1620);
	entire_page = 1;
	current_page = 1;
	Class'UIAPI_EDITBOX'.SetString("PartyMatchOutWaitListWnd.MinLevel","1");
	Class'UIAPI_EDITBOX'.SetString("PartyMatchOutWaitListWnd.MaxLevel","80");
}

function OnShow ()
{
	current_page = 1;
}

function OnEvent (int a_EventID, string param)
{
	switch (a_EventID)
	{
		case 1610:
		HandlePartyMatchWaitListStart(param);
		break;
		case 1620:
		HandlePartyMatchWaitList(param);
		break;
		default:
	}
}

function HandlePartyMatchWaitListStart (string param)
{
	local int AllCount;
	local int Count;
	local string totalPages;
	local string currentPage;
	local string page_info;

	ParseInt(param,"AllCount",AllCount);
	ParseInt(param,"Count",Count);
	totalPages = string(UnknownFunction146(UnknownFunction145(AllCount,64),1));
	entire_page = UnknownFunction146(UnknownFunction145(AllCount,64),1);
	currentPage = string(current_page);
	page_info = UnknownFunction112(UnknownFunction112(currentPage,"/"),totalPages);
	Class'UIAPI_TEXTBOX'.SetText("PartyMatchOutWaitListWnd.MemberCount",page_info);
	Class'UIAPI_LISTCTRL'.DeleteAllItem("PartyMatchOutWaitListWnd.WaitListCtrl");
	CheckButtonAlive();
}

function HandlePartyMatchWaitList (string param)
{
	local string Name;
	local int ClassID;
	local int Level;
	local LVDataRecord Record;

	ParseString(param,"Name",Name);
	ParseInt(param,"ClassID",ClassID);
	ParseInt(param,"Level",Level);
	Record.LVDataList.Length = 3;
	Record.LVDataList[0].szData = Name;
	Record.LVDataList[1].szTexture = GetClassIconName(ClassID);
	Record.LVDataList[1].nTextureWidth = 11;
	Record.LVDataList[1].nTextureHeight = 11;
	Record.LVDataList[1].szData = string(ClassID);
	Record.LVDataList[2].szData = GetAmbiguousLevelString(Level,False);
	Record.nReserved1 = Level;
	Class'UIAPI_LISTCTRL'.InsertRecord("PartyMatchOutWaitListWnd.WaitListCtrl",Record);
}

function OnClickButton (string a_strButtonName)
{
	switch (a_strButtonName)
	{
		case "RefreshButton":
		OnRefreshButtonClick();
		break;
		case "WhisperButton":
		OnWhisperButtonClick();
		break;
		case "PartyInviteButton":
		OnInviteButtonClick();
		break;
		case "CloseButton":
		OnCloseButtonClick();
		break;
		case "btn_Search":
		OnSearchBtnClick();
		break;
		case "prev_btn":
		OnPrevbuttonClick();
		break;
		case "next_btn":
		OnNextbuttonClick();
		break;
		default:
	}
}

function OnRefreshButtonClick ()
{
	MinLevel = int(Class'UIAPI_EDITBOX'.GetString("PartyMatchOutWaitListWnd.MinLevel"));
	MaxLevel = int(Class'UIAPI_EDITBOX'.GetString("PartyMatchOutWaitListWnd.MaxLevel"));
	Class'PartyMatchAPI'.RequestPartyMatchWaitList(current_page,MinLevel,MaxLevel,1);
}

function OnNextbuttonClick ()
{
	current_page = UnknownFunction146(current_page,1);
	Class'PartyMatchAPI'.RequestPartyMatchWaitList(current_page,MinLevel,MaxLevel,1);
}

function OnPrevbuttonClick ()
{
	current_page = UnknownFunction147(current_page,1);
	Class'PartyMatchAPI'.RequestPartyMatchWaitList(current_page,MinLevel,MaxLevel,1);
}

function OnSearchBtnClick ()
{
	MinLevel = int(Class'UIAPI_EDITBOX'.GetString("PartyMatchOutWaitListWnd.MinLevel"));
	MaxLevel = int(Class'UIAPI_EDITBOX'.GetString("PartyMatchOutWaitListWnd.MaxLevel"));
	Class'PartyMatchAPI'.RequestPartyMatchWaitList(1,MinLevel,MaxLevel,1);
}

function OnWhisperButtonClick ()
{
	local LVDataRecord Record;
	local string szData1;

	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("PartyMatchOutWaitListWnd.WaitListCtrl");
	szData1 = Record.LVDataList[0].szData;
	if ( UnknownFunction123(szData1,"") )
	{
		SetChatMessage(UnknownFunction112(UnknownFunction112(""",szData1)," "));
	}
}

function OnInviteButtonClick ()
{
	local LVDataRecord Record;

	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("PartyMatchOutWaitListWnd.WaitListCtrl");
	MakeRoomFirst(Record.nReserved1,Record.LVDataList[0].szData);
}

function OnCloseButtonClick ()
{
	local PartyMatchWnd script;

	script = PartyMatchWnd(GetScript("PartyMatchWnd"));
	if ( UnknownFunction119(script,None) )
	{
		script.SetWaitListWnd(False);
		script.ShowHideWaitListWnd();
	}
}

function OnDBClickListCtrlRecord (string a_ListCtrlName)
{
	local LVDataRecord Record;

	if ( UnknownFunction123(a_ListCtrlName,"WaitListCtrl") )
	{
		return;
	}
	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("PartyMatchOutWaitListWnd.WaitListCtrl");
	SetChatMessage(UnknownFunction112(UnknownFunction112(""",Record.LVDataList[0].szData)," "));
}

function MakeRoomFirst (int TargetLevel, string InviteTargetName)
{
	local PartyMatchMakeRoomWnd script;
	local UserInfo PlayerInfo;
	local int LevelMin;
	local int LevelMax;

	script = PartyMatchMakeRoomWnd(GetScript("PartyMatchMakeRoomWnd"));
	if ( UnknownFunction119(script,None) )
	{
		script.InviteState = 1;
		script.InvitedName = InviteTargetName;
		script.SetRoomNumber(0);
		script.SetTitle(GetSystemMessage(1398));
		script.SetMaxPartyMemberCount(12);
		if ( GetPlayerInfo(PlayerInfo) )
		{
			if ( UnknownFunction150(TargetLevel,PlayerInfo.nLevel) )
			{
				LevelMin = TargetLevel;
				LevelMax = PlayerInfo.nLevel;
			} else {
				LevelMin = PlayerInfo.nLevel;
				LevelMax = TargetLevel;
			}
			if ( UnknownFunction151(UnknownFunction147(LevelMin,5),0) )
			{
				script.SetMinLevel(UnknownFunction147(LevelMin,5));
			} else {
				script.SetMinLevel(1);
			}
			if ( UnknownFunction152(UnknownFunction146(LevelMax,5),80) )
			{
				script.SetMaxLevel(UnknownFunction146(LevelMax,5));
			} else {
				script.SetMaxLevel(80);
			}
		}
	}
	Class'UIAPI_WINDOW'.ShowWindow("PartyMatchMakeRoomWnd");
	Class'UIAPI_WINDOW'.SetFocus("PartyMatchMakeRoomWnd");
}

function CheckButtonAlive ()
{
	Class'UIAPI_WINDOW'.EnableWindow("PartyMatchOutWaitListWnd.prev_btn");
	Class'UIAPI_WINDOW'.EnableWindow("PartyMatchOutWaitListWnd.next_btn");
	if ( UnknownFunction154(current_page,1) )
	{
		Class'UIAPI_WINDOW'.DisableWindow("PartyMatchOutWaitListWnd.prev_btn");
	}
	if ( UnknownFunction154(current_page,entire_page) )
	{
		Class'UIAPI_WINDOW'.DisableWindow("PartyMatchOutWaitListWnd.next_btn");
	}
}


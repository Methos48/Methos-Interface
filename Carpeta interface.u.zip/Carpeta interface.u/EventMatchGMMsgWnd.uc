//================================================================================
// EventMatchGMMsgWnd.
//================================================================================

class EventMatchGMMsgWnd extends UICommonAPI;

var TextBoxHandle MessageTextBox;
const TIMERID_Hide= 1;

function OnLoad ()
{
	MessageTextBox = TextBoxHandle(GetHandle("MsgTextBox"));
	RegisterEvent(2270);
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 2270:
		HandleEventMatchGMMessage(a_Param);
		break;
		default:
		break;
	}
}

function OnTimer (int a_TimerID)
{
	switch (a_TimerID)
	{
		case 1:
		m_hOwnerWnd.HideWindow();
		MessageTextBox.SetText("");
		m_hOwnerWnd.KillTimer(1);
		break;
		default:
		break;
	}
}

function HandleEventMatchGMMessage (string a_Param)
{
	local int Type;
	local string Message;

	ParseInt(a_Param,"Type",Type);
	ParseString(a_Param,"Message",Message);
	switch (Type)
	{
		case 0:
		m_hOwnerWnd.ShowWindow();
		MessageTextBox.SetText(Message);
		m_hOwnerWnd.KillTimer(1);
		m_hOwnerWnd.SetTimer(1,5000);
		break;
		default:
		break;
	}
}


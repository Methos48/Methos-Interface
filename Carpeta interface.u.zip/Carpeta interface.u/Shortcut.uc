//================================================================================
// Shortcut.
//================================================================================

class Shortcut extends UICommonAPI;

var NPHRN_KeyWnd NPHRN_KeyWnd;
var bool m_chatstateok;
var bool UseBind1;
var bool UseBind2;
var bool UseBind3;
var int Panel1;
var int Panel2;
var int Panel3;
var MacroListWnd MacroHandler;
const CHAT_WINDOW_SYSTEM= 5;
const CHAT_WINDOW_COUNT= 5;
const CHAT_WINDOW_ALLY= 4;
const CHAT_WINDOW_CLAN= 3;
const CHAT_WINDOW_PARTY= 2;
const CHAT_WINDOW_TRADE= 1;
const CHAT_WINDOW_NORMAL= 0;

function OnLoad ()
{
	RegisterEvent(90);
	LoadData();
	NPHRN_KeyWnd = NPHRN_KeyWnd(GetScript("NPHRN_KeyWnd"));
	if ( LogicalAND(LogicalAND(NotBool(UseBind1),NotBool(UseBind2)),NotBool(UseBind3)) )
	{
		SetOptionBool("Key","UseFPad",True);
		SetOptionBool("Key","UseNumpad",True);
		SetOptionBool("Key","UseQwerty",True);
		SetOptionInt("Key","Panel1",1);
		SetOptionInt("Key","Panel2",2);
		SetOptionInt("Key","Panel3",3);
		NPHRN_KeyWnd.ComboPanel1.SetSelectedNum(IntSub(Panel1,3));
		NPHRN_KeyWnd.ComboPanel2.SetSelectedNum(IntSub(Panel2,2));
		NPHRN_KeyWnd.ComboPanel3.SetSelectedNum(IntSub(Panel3,1));
		LoadData();
	}
	MacroHandler = MacroListWnd(GetScript("MacroListWnd"));
}

function LoadData ()
{
	UseBind1 = GetOptionBool("Key","UseNumpad");
	UseBind2 = GetOptionBool("Key","UseFPad");
	UseBind3 = GetOptionBool("Key","UseQwerty");
	Panel1 = GetOptionInt("Key","Panel1");
	Panel2 = GetOptionInt("Key","Panel2");
	Panel3 = GetOptionInt("Key","Panel3");
	GetOptionBool("Game","EnterChatting");
	if ( UnknownFunction152(Panel1,0) )
	{
		Panel1 = 1;
	}
	if ( UnknownFunction152(Panel2,0) )
	{
		Panel2 = 2;
	}
	if ( UnknownFunction152(Panel3,0) )
	{
		Panel3 = 3;
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 90:
		HandleShortcutCommand(a_Param);
		break;
		default:
	}
}

function OnExitState (name a_NextStateName)
{
	if ( UnknownFunction254(a_NextStateName,'GamingState') )
	{
		m_chatstateok = True;
	} else {
		m_chatstateok = False;
	}
}

function HandleShortcutCommand (string a_Param)
{
	local string Command;

	if ( ParseString(a_Param,"Command",Command) )
	{
		switch (Command)
		{
			case "CloseAllWindow":
			HandleCloseAllWindow();
			break;
			case "ShowChatWindow":
			HandleShowChatWindow();
			break;
			case "SetPrevChatType":
			HandleSetPrevChatType();
			break;
			case "SetNextChatType":
			HandleSetNextChatType();
			break;
			case "ShowStatusWnd":
			OpenHideWindow("DetailStatusWnd");
			break;
			case "ShowSkillWnd":
			OpenHideWindow("MagicSkillWnd");
			break;
			case "ShowActionWnd":
			OpenHideWindow("ActionWnd");
			break;
			case "ShowQuestWnd":
			OpenHideWindow("QuestTreeWnd");
			break;
			case "ShowClanWnd":
			OpenHideWindow("ClanWnd");
			break;
			case "ResetDefaultPosition":
			SetDefaultPosition();
			break;
			case "ForceExit":
			RequestExit();
			break;
			case "TargetSelf":
			RequestSelfTarget();
			break;
			case "HandleToggleSkillSpam":
			HandleToggleSkillSpam();
			break;
			case "HandleToggleBuffSpam":
			HandleToggleBuffSpam();
			break;
			case "HandleToggleAutoPotions":
			HandleToggleAutoPotions();
			break;
			default:
		}
		if ( UnknownFunction122(UnknownFunction128(Command,12),"UserShortcut") )
		{
			ShortcutKey(Command);
		}
	}
}

function OpenHideWindow (string param)
{
	if ( IsShowWindow(param) )
	{
		HideWindow(param);
	} else {
		ShowWindow(param);
	}
}

function UseShortcut (string Command, string Shortcut)
{
	if ( MacroHandler.HandleInventoryMacro(Shortcut) )
	{
		return;
	}
	ExecuteCommand(UnknownFunction112(Command,Shortcut));
}

function ShortcutKey (string Parametr)
{
	switch (Parametr)
	{
		case "UserShortcutKey_1":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 1"));
		}
		break;
		case "UserShortcutKey_2":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 2"));
		}
		break;
		case "UserShortcutKey_3":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 3"));
		}
		break;
		case "UserShortcutKey_4":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 4"));
		}
		break;
		case "UserShortcutKey_5":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 5"));
		}
		break;
		case "UserShortcutKey_6":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 6"));
		}
		break;
		case "UserShortcutKey_7":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 7"));
		}
		break;
		case "UserShortcutKey_8":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 8"));
		}
		break;
		case "UserShortcutKey_9":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 9"));
		}
		break;
		case "UserShortcutKey_10":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 10"));
		}
		break;
		case "UserShortcutKey_11":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 11"));
		}
		break;
		case "UserShortcutKey_12":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel1)," 12"));
		}
		break;
		case "UserShortcutKey_Q":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 1"));
		}
		break;
		case "UserShortcutKey_W":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 2"));
		}
		break;
		case "UserShortcutKey_E":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 3"));
		}
		break;
		case "UserShortcutKey_R":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 4"));
		}
		break;
		case "UserShortcutKey_T":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 5"));
		}
		break;
		case "UserShortcutKey_Y":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 6"));
		}
		break;
		case "UserShortcutKey_U":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 7"));
		}
		break;
		case "UserShortcutKey_I":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 8"));
		}
		break;
		case "UserShortcutKey_O":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 9"));
		}
		break;
		case "UserShortcutKey_P":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 10"));
		}
		break;
		case "UserShortcutKey_[":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 11"));
		}
		break;
		case "UserShortcutKey_]":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel2)," 12"));
		}
		break;
		case "UserShortcutKey_F1":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 1"));
		}
		break;
		case "UserShortcutKey_F2":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 2"));
		}
		break;
		case "UserShortcutKey_F3":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 3"));
		}
		break;
		case "UserShortcutKey_F4":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 4"));
		}
		break;
		case "UserShortcutKey_F5":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 5"));
		}
		break;
		case "UserShortcutKey_F6":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 6"));
		}
		break;
		case "UserShortcutKey_F7":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 7"));
		}
		break;
		case "UserShortcutKey_F8":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 8"));
		}
		break;
		case "UserShortcutKey_F9":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 9"));
		}
		break;
		case "UserShortcutKey_F10":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 10"));
		}
		break;
		case "UserShortcutKey_F11":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 11"));
		}
		break;
		case "UserShortcutKey_F12":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcut ",UnknownFunction112(string(Panel3)," 12"));
		}
		break;
		case "UserShortcutKeyForce_1":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 1"));
		}
		break;
		case "UserShortcutKeyForce_2":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 2"));
		}
		break;
		case "UserShortcutKeyForce_3":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 3"));
		}
		break;
		case "UserShortcutKeyForce_4":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 4"));
		}
		break;
		case "UserShortcutKeyForce_5":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 5"));
		}
		break;
		case "UserShortcutKeyForce_6":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 6"));
		}
		break;
		case "UserShortcutKeyForce_7":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 7"));
		}
		break;
		case "UserShortcutKeyForce_8":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 8"));
		}
		break;
		case "UserShortcutKeyForce_9":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 9"));
		}
		break;
		case "UserShortcutKeyForce_10":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 10"));
		}
		break;
		case "UserShortcutKeyForce_11":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 11"));
		}
		break;
		case "UserShortcutKeyForce_12":
		if ( UseBind1 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel1)," 12"));
		}
		break;
		case "UserShortcutKeyForce_Q":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 1"));
		}
		break;
		case "UserShortcutKeyForce_W":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 2"));
		}
		break;
		case "UserShortcutKeyForce_E":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 3"));
		}
		break;
		case "UserShortcutKeyForce_R":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 4"));
		}
		break;
		case "UserShortcutKeyForce_T":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 5"));
		}
		break;
		case "UserShortcutKeyForce_Y":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 6"));
		}
		break;
		case "UserShortcutKeyForce_U":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 7"));
		}
		break;
		case "UserShortcutKeyForce_I":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 8"));
		}
		break;
		case "UserShortcutKeyForce_O":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 9"));
		}
		break;
		case "UserShortcutKeyForce_P":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 10"));
		}
		break;
		case "UserShortcutKeyForce_[":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 11"));
		}
		break;
		case "UserShortcutKeyForce_]":
		if ( UseBind2 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel2)," 12"));
		}
		break;
		case "UserShortcutKeyForce_F1":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 1"));
		}
		break;
		case "UserShortcutKeyForce_F2":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 2"));
		}
		break;
		case "UserShortcutKeyForce_F3":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 3"));
		}
		break;
		case "UserShortcutKeyForce_F4":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 4"));
		}
		break;
		case "UserShortcutKeyForce_F5":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 5"));
		}
		break;
		case "UserShortcutKeyForce_F6":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 6"));
		}
		break;
		case "UserShortcutKeyForce_F7":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 7"));
		}
		break;
		case "UserShortcutKeyForce_F8":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 8"));
		}
		break;
		case "UserShortcutKeyForce_F9":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 9"));
		}
		break;
		case "UserShortcutKeyForce_F10":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 10"));
		}
		break;
		case "UserShortcutKeyForce_F11":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 11"));
		}
		break;
		case "UserShortcutKeyForce_F12":
		if ( UseBind3 )
		{
			UseShortcut("/useshortcutforce ",UnknownFunction112(string(Panel3)," 12"));
		}
		break;
		default:
	}
}

function HandleShowChatWindow ()
{
	local WindowHandle Handle;

	Handle = GetHandle("ChatWnd");
	if ( Handle.IsShowWindow() )
	{
		Handle.HideWindow();
		if ( GetOptionBool("Game","SystemMsgWnd") )
		{
			Class'UIAPI_WINDOW'.HideWindow("SystemMsgWnd");
		}
	} else {
		Handle.ShowWindow();
		if ( GetOptionBool("Game","SystemMsgWnd") )
		{
			Class'UIAPI_WINDOW'.ShowWindow("SystemMsgWnd");
		}
	}
}

function HandleSetPrevChatType ()
{
	local ChatWnd chatWndScript;

	chatWndScript = ChatWnd(GetScript("ChatWnd"));
	switch (chatWndScript.m_chatType)
	{
		case 0:
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(4,True);
		chatWndScript.HandleTabClick("ChatTabCtrl4");
		break;
		case 1:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(0,True);
		chatWndScript.HandleTabClick("ChatTabCtrl0");
		break;
		case 2:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(1,True);
		chatWndScript.HandleTabClick("ChatTabCtrl1");
		break;
		case 3:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.SetTopOrder(2,True);
		chatWndScript.HandleTabClick("ChatTabCtrl2");
		break;
		case 4:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.SetTopOrder(3,True);
		chatWndScript.HandleTabClick("ChatTabCtrl3");
		break;
		default:
	}
}

function HandleSetNextChatType ()
{
	local ChatWnd chatWndScript;

	chatWndScript = ChatWnd(GetScript("ChatWnd"));
	switch (chatWndScript.m_chatType)
	{
		case 0:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(1,True);
		chatWndScript.HandleTabClick("ChatTabCtrl1");
		break;
		case 1:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(2,True);
		chatWndScript.HandleTabClick("ChatTabCtrl2");
		break;
		case 2:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(3,True);
		chatWndScript.HandleTabClick("ChatTabCtrl3");
		break;
		case 3:
		chatWndScript.ChatTabCtrl.MergeTab(0);
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.SetTopOrder(4,True);
		chatWndScript.HandleTabClick("ChatTabCtrl4");
		break;
		case 4:
		chatWndScript.ChatTabCtrl.MergeTab(1);
		chatWndScript.ChatTabCtrl.MergeTab(2);
		chatWndScript.ChatTabCtrl.MergeTab(3);
		chatWndScript.ChatTabCtrl.MergeTab(4);
		chatWndScript.ChatTabCtrl.SetTopOrder(0,True);
		chatWndScript.HandleTabClick("ChatTabCtrl0");
		break;
		default:
	}
}

function HandleToggleSkillSpam ()
{
	local AutoSkillSpamWnd autoSkillSpamScript;

	autoSkillSpamScript = AutoSkillSpamWnd(GetScript("AutoSkillSpamWnd"));
	autoSkillSpamScript.HandleToggleSkillSpam();
}

function HandleToggleBuffSpam ()
{
	local AutoSkillWnd autoSkillWndScript;

	autoSkillWndScript = AutoSkillWnd(GetScript("AutoSkillWnd"));
	autoSkillWndScript.HandleToggleBuffSpam();
}

function HandleToggleAutoPotions ()
{
	local AutoPotionsWnd autoPotionsWndScript;

	autoPotionsWndScript = AutoPotionsWnd(GetScript("AutoPotionsWnd"));
	autoPotionsWndScript.HandleToggleAutoPotions();
}

function HandleCloseAllWindow ()
{
	Class'UIAPI_WINDOW'.HideWindow("SystemMenuWnd");
}


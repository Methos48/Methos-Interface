//================================================================================
// TargetStatusWnd.
//================================================================================

class TargetStatusWnd extends UICommonAPI;

var bool m_bExpand;
var WindowHandle m_wndTop;
var EditBoxHandle ChatEditBox;
var int m_TargetLevel;
var int m_targetID;
var string dlgText;
var int PlayerID;
var PartyWnd PartyWnd;
var int idx_HoldTarget_1;
var int idx_HoldTarget_2;
var bool m_bShow;
var ButtonHandle b_Invite;
var ButtonHandle b_Dismiss;
var ButtonHandle b_Trade;
var ButtonHandle b_ChangeLeader;

function OnLoad ()
{
	RegisterEvent(980);
	RegisterEvent(990);
	RegisterEvent(50);
	RegisterEvent(110);
	RegisterEvent(2960);
	RegisterEvent(290);
	RegisterEvent(190);
	RegisterEvent(210);
	RegisterEvent(200);
	RegisterEvent(220);
	RegisterEvent(300);
	SetExpandMode(False);
	m_wndTop = GetHandle("TargetStatusWnd");
	PartyWnd = PartyWnd(GetScript("PartyWnd"));
	ChatEditBox = EditBoxHandle(GetHandle("ChatWnd.ChatEditBox"));
	m_bShow = False;
	m_targetID = -1;
}

function OnShow ()
{
	m_bShow = True;
}

function OnHide ()
{
	m_bShow = False;
}

function OnEnterState (name a_PreStateName)
{
	SetExpandMode(m_bExpand);
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,980) )
	{
		HandleTargetUpdate();
		if ( UnknownFunction129(m_wndTop.IsShowWindow()) )
		{
			ExecuteEvent(2960);
		}
	} else {
		if ( UnknownFunction154(Event_ID,990) )
		{
			Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd");
		} else {
			if ( UnknownFunction154(Event_ID,300) )
			{
				HandleReceiveTargetLevelDiff(param);
			} else {
				if ( UnknownFunction154(Event_ID,190) )
				{
					HandleUpdateHPMP(param);
				} else {
					if ( UnknownFunction154(Event_ID,210) )
					{
						HandleUpdateHPMP(param);
					} else {
						if ( UnknownFunction154(Event_ID,200) )
						{
							HandleUpdateHPMP(param);
						} else {
							if ( UnknownFunction154(Event_ID,220) )
							{
								HandleUpdateHPMP(param);
							} else {
								if ( UnknownFunction154(Event_ID,290) )
								{
									if ( GetOptionBool("Custom","IgnoreAggr") )
									{
										IgnoreAggrFunc(param);
									}
								} else {
									if ( UnknownFunction132(UnknownFunction154(Event_ID,50),UnknownFunction154(Event_ID,110)) )
									{
										idx_HoldTarget_1 = -1;
									} else {
										if ( UnknownFunction154(Event_ID,2960) )
										{
											holdTargetFunc();
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

function holdTargetFunc ()
{
	if ( BoolEquals(GetOptionBool("Custom","HoldTarget"),True) )
	{
		if ( UnknownFunction155(idx_HoldTarget_1,idx_HoldTarget_2) )
		{
			RequestTargetUser(idx_HoldTarget_1);
		}
	}
}

function IgnoreAggrFunc (string param)
{
	local int idx;
	local int AttackerID;

	ParseInt(param,"SkillID",idx);
	if ( isAggroCast(idx) )
	{
		ParseInt(param,"AttackerID",AttackerID);
		if ( NotBool(isPartyMember(AttackerID)) )
		{
			idx_HoldTarget_2 = AttackerID;
		}
	}
}

function bool isPartyMember (int m_targetID)
{
	local int j;
	local bool ResultBool;

	j = 0;
	if ( UnknownFunction150(j,8) )
	{
		if ( UnknownFunction154(m_targetID,PartyWnd.m_arrID[j]) )
		{
			ResultBool = True;
		}
		UnknownFunction165(j);
		goto JL0007;
	}
	return ResultBool;
}

function bool isAggroCast (int idx)
{
	local bool ResultBool;

	switch (idx)
	{
		case 18:
		case 28:
		case 286:
		ResultBool = True;
		break;
		default:
	}
	return ResultBool;
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnClose":
		OnCloseButton();
		break;
		case "FastInviteBtn":
		OnFastInviteButton();
		break;
		case "FastDismissBtn":
		OnFastDismissBtn();
		break;
		case "FastChangeLeaderBtn":
		OnFastChangeLeaderBtn();
		break;
		case "FastTradeBtn":
		OnFastTradeBtn();
		break;
		default:
	}
}

function OnFastInviteButton ()
{
	local UserInfo UserInfo;

	GetTargetInfo(UserInfo);
	RequestInviteParty(UserInfo.Name);
}

function OnFastDismissBtn ()
{
	local UserInfo UserInfo;

	GetTargetInfo(UserInfo);
	ExecuteCommand(UnknownFunction168("/dismiss ",UserInfo.Name));
}

function OnFastChangeLeaderBtn ()
{
	local UserInfo UserInfo;

	GetTargetInfo(UserInfo);
	ExecuteCommand(UnknownFunction168("/changepartyleader ",UserInfo.Name));
}

function OnFastTradeBtn ()
{
	local UserInfo UserInfo;

	GetTargetInfo(UserInfo);
	ExecuteCommand(UnknownFunction168("/trade ",UserInfo.Name));
}

function OnCloseButton ()
{
	RequestTargetCancel();
	PlayConsoleSound(6);
}

function HandleUpdateHPMP (string param)
{
	local int ServerID;

	if ( m_bShow )
	{
		ParseInt(param,"ServerID",ServerID);
		if ( UnknownFunction154(m_targetID,ServerID) )
		{
			HandleTargetUpdate();
		}
	}
}

function HandleReceiveTargetLevelDiff (string param)
{
	ParseInt(param,"LevelDiff",m_TargetLevel);
}

function HandleTargetUpdate ()
{
	local Rect rectWnd;
	local string strTmp;
	local int targetID;
	local int PetID;
	local int clanType;
	local int clanNameValue;
	local bool bIsServerObject;
	local bool bIsHPShowableNPC;
	local string Name;
	local string RankName;
	local string ClassName;
	local Color TargetNameColor;
	local int ServerObjectNameID;
	local EServerObjectType ServerObjectType;
	local bool bShowHPBar;
	local bool bShowMPBar;
	local bool bShowPledgeInfo;
	local bool bShowPledgeTex;
	local bool bShowPledgeAllianceTex;
	local string PledgeName;
	local string PledgeAllianceName;
	local Texture PledgeCrestTexture;
	local Texture PledgeAllianceCrestTexture;
	local Color PledgeNameColor;
	local Color PledgeAllianceNameColor;
	local bool bShowNpcInfo;
	local array<int> arrNpcInfo;
	local bool IsTargetChanged;
	local UserInfo Info;
	local Color WhiteColor;

	WhiteColor.R = 0;
	WhiteColor.G = 0;
	WhiteColor.B = 0;
	targetID = Class'UIDATA_TARGET'.GetTargetID();
	if ( BoolEquals(GetOptionBool("Custom","IgnoreAggr"),True) )
	{
		if ( Equals(targetID,idx_HoldTarget_2) )
		{
			RequestTargetUser(idx_HoldTarget_1);
			idx_HoldTarget_2 = -1;
			targetID = -1;
		}
	}
	if ( UnknownFunction150(targetID,1) )
	{
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd");
		return;
	}
	if ( UnknownFunction155(m_targetID,targetID) )
	{
		IsTargetChanged = True;
		idx_HoldTarget_1 = targetID;
		Class'UIAPI_WINDOW'.KillUITimer("NPHRN_EventWnd",11);
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.ReceiveMagicSkillUse");
	}
	m_targetID = targetID;
	GetTargetInfo(Info);
	rectWnd = Class'UIAPI_WINDOW'.GetRect("TargetStatusWnd");
	PledgeName = GetSystemString(431);
	PledgeAllianceName = GetSystemString(591);
	PledgeNameColor.R = 128;
	PledgeNameColor.G = 128;
	PledgeNameColor.B = 128;
	PledgeAllianceNameColor.R = 128;
	PledgeAllianceNameColor.G = 128;
	PledgeAllianceNameColor.B = 128;
	TargetNameColor = Class'UIDATA_TARGET'.GetTargetNameColor(m_TargetLevel);
	bIsServerObject = Class'UIDATA_TARGET'.IsServerObject();
	if ( bIsServerObject )
	{
		ServerObjectNameID = Class'UIDATA_STATICOBJECT'.GetServerObjectNameID(m_targetID);
		if ( UnknownFunction151(ServerObjectNameID,0) )
		{
			Name = Class'UIDATA_STATICOBJECT'.GetStaticObjectName(ServerObjectNameID);
			RankName = "";
		}
		Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.UserName",Name,0,2);
		Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.RankName",RankName,0,2);
		ServerObjectType = Class'UIDATA_STATICOBJECT'.GetServerObjectType(m_targetID);
		if ( UnknownFunction154(ServerObjectType,2) )
		{
			if ( Class'UIDATA_STATICOBJECT'.GetStaticObjectShowHP(m_targetID) )
			{
				bShowHPBar = True;
				UpdateHPBar(Class'UIDATA_STATICOBJECT'.GetServerObjectHP(m_targetID),Class'UIDATA_STATICOBJECT'.GetServerObjectMaxHP(m_targetID));
			}
		}
	} else {
		if ( UnknownFunction150(UnknownFunction125(Info.Name),1) )
		{
			Name = Class'UIDATA_PARTY'.GetMemberName(m_targetID);
			RankName = "";
			Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.UserName",Name,0,2);
			Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.RankName",RankName,0,2);
		} else {
			PlayerID = Class'UIDATA_PLAYER'.GetPlayerID();
			PetID = Class'UIDATA_PET'.GetPetID();
			bIsHPShowableNPC = Class'UIDATA_TARGET'.IsHPShowableNPC();
			if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction130(UnknownFunction130(Info.bNpc,UnknownFunction129(Info.bPet)),Info.bCanBeAttacked),UnknownFunction130(UnknownFunction151(PlayerID,0),UnknownFunction154(m_targetID,PlayerID))),UnknownFunction130(UnknownFunction130(Info.bNpc,Info.bPet),UnknownFunction154(m_targetID,PetID))),UnknownFunction130(Info.bNpc,bIsHPShowableNPC)) )
			{
				if ( IsAllWhiteID(Info.nSubClass) )
				{
					Name = Info.Name;
					RankName = "";
					Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.UserName",Name,0,2);
					Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.RankName",RankName,0,2);
					if ( UnknownFunction129(IsNoBarID(Info.nClassID)) )
					{
						bShowHPBar = True;
						UpdateHPBar(Info.nCurHP,Info.nMaxHP);
					}
				} else {
					Name = Info.Name;
					RankName = "";
					Class'UIAPI_NAMECTRL'.SetNameWithColor("TargetStatusWnd.UserName",Name,0,2,TargetNameColor);
					Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.RankName",RankName,0,2);
					bShowHPBar = True;
					UpdateHPBar(Info.nCurHP,Info.nMaxHP);
					if ( UnknownFunction129(UnknownFunction130(UnknownFunction130(Info.bNpc,UnknownFunction129(Info.bPet)),Info.bCanBeAttacked)) )
					{
						bShowMPBar = True;
						UpdateMPBar(Info.nCurMP,Info.nMaxMP);
					}
				}
			} else {
				Name = Info.Name;
				if ( Info.bNpc )
				{
					RankName = "";
				} else {
					RankName = GetUserRankString(Info.nUserRank);
				}
				Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.UserName",Name,0,2);
				Class'UIAPI_NAMECTRL'.SetName("TargetStatusWnd.RankName",RankName,0,2);
			}
			if ( m_bExpand )
			{
				if ( Info.bNpc )
				{
					if ( Class'UIDATA_NPC'.GetNpcProperty(Info.nClassID,arrNpcInfo) )
					{
						bShowNpcInfo = True;
						if ( IsTargetChanged )
						{
							UpdateNpcInfoTree(arrNpcInfo);
						}
					}
				} else {
					bShowPledgeInfo = True;
					if ( UnknownFunction151(Info.nClanID,0) )
					{
						PledgeName = Class'UIDATA_CLAN'.GetName(Info.nClanID);
						PledgeNameColor.R = 176;
						PledgeNameColor.G = 152;
						PledgeNameColor.B = 121;
						if ( UnknownFunction130(UnknownFunction130(UnknownFunction123(PledgeName,""),Class'UIDATA_USER'.GetClanType(m_targetID,clanType)),Class'UIDATA_CLAN'.GetNameValue(Info.nClanID,clanNameValue)) )
						{
							if ( UnknownFunction154(clanType,-1) )
							{
								PledgeNameColor.R = 209;
								PledgeNameColor.G = 167;
								PledgeNameColor.B = 2;
							} else {
								if ( UnknownFunction151(clanNameValue,0) )
								{
									PledgeNameColor.R = 0;
									PledgeNameColor.G = 130;
									PledgeNameColor.B = 255;
								} else {
									if ( UnknownFunction150(clanNameValue,0) )
									{
										PledgeNameColor.R = 255;
										PledgeNameColor.G = 0;
										PledgeNameColor.B = 0;
									}
								}
							}
						}
						if ( Class'UIDATA_CLAN'.GetCrestTexture(Info.nClanID,PledgeCrestTexture) )
						{
							bShowPledgeTex = True;
							Class'UIAPI_TEXTURECTRL'.SetTextureWithObject("TargetStatusWnd.texPledgeCrest",PledgeCrestTexture);
						} else {
							bShowPledgeTex = False;
						}
						strTmp = Class'UIDATA_CLAN'.GetAllianceName(Info.nClanID);
						if ( UnknownFunction151(UnknownFunction125(strTmp),0) )
						{
							PledgeAllianceName = strTmp;
							PledgeAllianceNameColor.R = 176;
							PledgeAllianceNameColor.G = 155;
							PledgeAllianceNameColor.B = 121;
							if ( Class'UIDATA_CLAN'.GetAllianceCrestTexture(Info.nClanID,PledgeAllianceCrestTexture) )
							{
								bShowPledgeAllianceTex = True;
								Class'UIAPI_TEXTURECTRL'.SetTextureWithObject("TargetStatusWnd.texPledgeAllianceCrest",PledgeAllianceCrestTexture);
							} else {
								bShowPledgeAllianceTex = False;
							}
						}
					}
				}
			}
		}
	}
	if ( UnknownFunction129(Class'UIAPI_WINDOW'.IsShowWindow("TargetStatusWnd")) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd");
		SetExpandMode(m_bExpand);
	}
	if ( UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction130(UnknownFunction129(Info.bNpc),UnknownFunction129(Info.bPet)),UnknownFunction129(bShowMPBar)),UnknownFunction129(bShowHPBar)),UnknownFunction129(bIsServerObject)) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.FastInviteBtn");
		b_Invite = ButtonHandle(GetHandle("TargetStatusWnd.FastInviteBtn"));
		b_Invite.SetTooltipCustomType(SetTooltip("Invite"));
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.FastDismissBtn");
		b_Dismiss = ButtonHandle(GetHandle("TargetStatusWnd.FastDismissBtn"));
		b_Dismiss.SetTooltipCustomType(SetTooltip("Dismiss"));
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.FastChangeLeaderBtn");
		b_ChangeLeader = ButtonHandle(GetHandle("TargetStatusWnd.FastChangeLeaderBtn"));
		b_ChangeLeader.SetTooltipCustomType(SetTooltip("Change Leader"));
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.FastTradeBtn");
		b_Trade = ButtonHandle(GetHandle("TargetStatusWnd.FastTradeBtn"));
		b_Trade.SetTooltipCustomType(SetTooltip("Trade"));
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.FastInviteBtn");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.FastDismissBtn");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.FastChangeLeaderBtn");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.FastTradeBtn");
	}
	if ( bShowPledgeInfo )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtPledge");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtAlliance");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtPledgeName");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtPledgeAllianceName");
		Class'UIAPI_TEXTBOX'.SetText("TargetStatusWnd.txtPledgeName",PledgeName);
		Class'UIAPI_TEXTBOX'.SetText("TargetStatusWnd.txtPledgeAllianceName",PledgeAllianceName);
		Class'UIAPI_TEXTBOX'.SetTextColor("TargetStatusWnd.txtPledgeName",PledgeNameColor);
		Class'UIAPI_TEXTBOX'.SetTextColor("TargetStatusWnd.txtPledgeAllianceName",PledgeAllianceNameColor);
		if ( bShowPledgeTex )
		{
			Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.texPledgeCrest");
			Class'UIAPI_WINDOW'.MoveTo("TargetStatusWnd.txtPledgeName",UnknownFunction146(rectWnd.nX,63),UnknownFunction146(rectWnd.nY,48));
		} else {
			Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.texPledgeCrest");
			Class'UIAPI_WINDOW'.MoveTo("TargetStatusWnd.txtPledgeName",UnknownFunction146(rectWnd.nX,45),UnknownFunction146(rectWnd.nY,48));
		}
		if ( bShowPledgeAllianceTex )
		{
			Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.texPledgeAllianceCrest");
			Class'UIAPI_WINDOW'.MoveTo("TargetStatusWnd.txtPledgeAllianceName",UnknownFunction146(rectWnd.nX,63),UnknownFunction146(rectWnd.nY,63));
		} else {
			Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.texPledgeAllianceCrest");
			Class'UIAPI_WINDOW'.MoveTo("TargetStatusWnd.txtPledgeAllianceName",UnknownFunction146(rectWnd.nX,45),UnknownFunction146(rectWnd.nY,63));
		}
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtPledge");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.texPledgeCrest");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtPledgeName");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtAlliance");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.texPledgeAllianceCrest");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtPledgeAllianceName");
	}
	if ( bShowNpcInfo )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.NpcInfo");
		Class'UIAPI_TREECTRL'.ShowScrollBar("TargetStatusWnd.NpcInfo",False);
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.NpcInfo");
	}
	HandleCPHPMPBar(Info);
}

function HandleCPHPMPBar (UserInfo Info)
{
	local int CurY;

	if ( UnknownFunction154(PlayerID,m_targetID) )
	{
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barCP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barHP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barMP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtCP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtHP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtMP");
		return;
	}
	if ( UnknownFunction130(UnknownFunction151(Info.nMaxCP,0),UnknownFunction151(Info.nMaxHP,0)) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.barCP");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtCP");
		UpdateCPBar(Info.nCurCP,Info.nMaxCP);
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barCP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtCP");
	}
	if ( UnknownFunction151(Info.nMaxHP,0) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.barHP");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtHP");
		UpdateHPBar(Info.nCurHP,Info.nMaxHP);
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barHP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtHP");
	}
	if ( UnknownFunction151(Info.nMaxMP,0) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.barMP");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.txtMP");
		UpdateMPBar(Info.nCurMP,Info.nMaxMP);
	} else {
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.barMP");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.txtMP");
	}
	if ( m_bExpand )
	{
		CurY = 53;
	} else {
		CurY = 33;
	}
	if ( IsShowWindow("TargetStatusWnd.barCP") )
	{
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.barCP","TargetStatusWnd","CenterCenter","CenterCenter",0,CurY);
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.txtCP","TargetStatusWnd","CenterCenter","CenterCenter",0,UnknownFunction147(CurY,1));
		UnknownFunction161(CurY,15);
	}
	if ( IsShowWindow("TargetStatusWnd.barHP") )
	{
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.barHP","TargetStatusWnd","CenterCenter","CenterCenter",0,CurY);
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.txtHP","TargetStatusWnd","CenterCenter","CenterCenter",0,UnknownFunction147(CurY,1));
		UnknownFunction161(CurY,15);
	}
	if ( IsShowWindow("TargetStatusWnd.barMP") )
	{
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.barMP","TargetStatusWnd","CenterCenter","CenterCenter",0,CurY);
		Class'UIAPI_WINDOW'.SetAnchor("TargetStatusWnd.txtMP","TargetStatusWnd","CenterCenter","CenterCenter",0,UnknownFunction147(CurY,1));
	}
}

function OnFrameExpandClick (bool bIsExpand)
{
	SetExpandMode(bIsExpand);
}

function SetExpandMode (bool bExpand)
{
	m_bExpand = bExpand;
	m_targetID = -1;
	HandleTargetUpdate();
	Class'UIAPI_TEXTBOX'.SetAlign("TargetStatusWnd.txtHP",2);
	Class'UIAPI_TEXTBOX'.SetAlign("TargetStatusWnd.txtMP",2);
	if ( bExpand )
	{
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.BackTex");
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.BackExpTex");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("TargetStatusWnd.BackTex");
		Class'UIAPI_WINDOW'.HideWindow("TargetStatusWnd.BackExpTex");
	}
}

function UpdateCPBar (int CP, int maxCP)
{
	Class'UIAPI_BARCTRL'.SetValue("TargetStatusWnd.barCP",maxCP,CP);
	Class'UIAPI_TEXTBOX'.SetText("TargetStatusWnd.txtCP",UnknownFunction112(UnknownFunction112(string(CP)," / "),string(maxCP)));
}

function UpdateHPBar (int HP, int maxHP)
{
	Class'UIAPI_BARCTRL'.SetValue("TargetStatusWnd.barHP",maxHP,HP);
	Class'UIAPI_TEXTBOX'.SetText("TargetStatusWnd.txtHP",UnknownFunction112(UnknownFunction112(string(HP)," / "),string(maxHP)));
}

function UpdateMPBar (int MP, int maxMP)
{
	Class'UIAPI_BARCTRL'.SetValue("TargetStatusWnd.barMP",maxMP,MP);
	Class'UIAPI_TEXTBOX'.SetText("TargetStatusWnd.txtMP",UnknownFunction112(UnknownFunction112(string(MP)," / "),string(maxMP)));
}

function UpdateNpcInfoTree (array<int> arrNpcInfo)
{
	local int i;
	local int SkillID;
	local int SkillLevel;
	local string strNodeName;
	local XMLTreeNodeInfo infNode;
	local XMLTreeNodeItemInfo infNodeItem;
	local XMLTreeNodeInfo infNodeClear;
	local XMLTreeNodeItemInfo infNodeItemClear;

	Class'UIAPI_TREECTRL'.Clear("TargetStatusWnd.NpcInfo");
	infNode.strName = "root";
	strNodeName = Class'UIAPI_TREECTRL'.InsertNode("TargetStatusWnd.NpcInfo","",infNode);
	if ( UnknownFunction150(UnknownFunction125(strNodeName),1) )
	{
		Debug(UnknownFunction112("ERROR: Can't insert root node. Name: ",infNode.strName));
		return;
	}
	i = 0;
	if ( UnknownFunction150(i,arrNpcInfo.Length) )
	{
		SkillID = arrNpcInfo[i];
		SkillLevel = arrNpcInfo[UnknownFunction146(i,1)];
		infNode = infNodeClear;
		infNode.nOffSetX = UnknownFunction144(int(UnknownFunction173(UnknownFunction145(i,2),8)),18);
		if ( UnknownFunction180(UnknownFunction173(UnknownFunction145(i,2),8),0) )
		{
			if ( UnknownFunction151(i,0) )
			{
				infNode.nOffSetY = 3;
			} else {
				infNode.nOffSetY = 0;
			}
		} else {
			infNode.nOffSetY = -15;
		}
		infNode.strName = UnknownFunction112("",string(UnknownFunction145(i,2)));
		infNode.bShowButton = 0;
		infNode.ToolTip = SetNpcInfoTooltip(SkillID,SkillLevel);
		strNodeName = Class'UIAPI_TREECTRL'.InsertNode("TargetStatusWnd.NpcInfo","root",infNode);
		if ( UnknownFunction150(UnknownFunction125(strNodeName),1) )
		{
			UnknownFunction231(UnknownFunction112("ERROR: Can't insert node. Name: ",infNode.strName));
			return;
		}
		infNode.ToolTip.DrawList.Remove (0,infNode.ToolTip.DrawList.Length);
		infNodeItem = infNodeItemClear;
		infNodeItem.eType = 2;
		infNodeItem.u_nTextureWidth = 15;
		infNodeItem.u_nTextureHeight = 15;
		infNodeItem.u_nTextureUWidth = 32;
		infNodeItem.u_nTextureUHeight = 32;
		infNodeItem.u_strTexture = Class'UIDATA_SKILL'.GetIconName(SkillID,SkillLevel);
		Class'UIAPI_TREECTRL'.InsertNodeItem("TargetStatusWnd.NpcInfo",strNodeName,infNodeItem);
		UnknownFunction161(i,2);
		goto JL00BD;
	}
}

function CustomTooltip SetNpcInfoTooltip (int Id, int Level)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;
	local DrawItemInfo infoClear;
	local ItemInfo item;

	item.Name = Class'UIDATA_SKILL'.GetName(Id,Level);
	item.Description = Class'UIDATA_SKILL'.GetDescription(Id,Level);
	ToolTip.DrawList.Length = 1;
	Info = infoClear;
	Info.eType = 1;
	Info.t_bDrawOneLine = True;
	Info.t_strText = item.Name;
	ToolTip.DrawList[0] = Info;
	if ( UnknownFunction151(UnknownFunction125(item.Description),0) )
	{
		ToolTip.MinimumWidth = 144;
		ToolTip.DrawList.Length = 2;
		Info = infoClear;
		Info.eType = 1;
		Info.nOffSetY = 6;
		Info.bLineBreak = True;
		Info.t_color.R = 178;
		Info.t_color.G = 190;
		Info.t_color.B = 207;
		Info.t_color.A = 255;
		Info.t_strText = item.Description;
		ToolTip.DrawList[1] = Info;
	}
	return ToolTip;
}

function bool IsAllWhiteID (int m_targetID)
{
	local bool bIsAllWhiteName;

	bIsAllWhiteName = False;
	switch (m_targetID)
	{
		case 12778:
		case 13031:
		case 13032:
		case 13033:
		case 13034:
		case 13035:
		case 13036:
		bIsAllWhiteName = True;
		break;
		default:
	}
	return bIsAllWhiteName;
}

function bool IsNoBarID (int m_targetID)
{
	local bool bIsNoBarName;

	bIsNoBarName = False;
	switch (m_targetID)
	{
		case 13036:
		bIsNoBarName = True;
		break;
		default:
	}
	return bIsNoBarName;
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}

function OnRButtonUp (int X, int Y)
{
	local Rect rectWnd;
	local UserInfo UserInfo;

	dlgText = DialogGetString();
	rectWnd = m_wndTop.GetRect();
	if ( UnknownFunction151(X,rectWnd.nX) )
	{
		GetTargetInfo(UserInfo);
		SetChatMessage(UnknownFunction112(UnknownFunction112(""",UserInfo.Name)," "));
		ChatEditBox.ReleaseFocus();
	}
}


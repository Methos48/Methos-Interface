//================================================================================
// InterfaceAI_EditAugmentListWnd.
//================================================================================

class InterfaceAI_EditAugmentListWnd extends UICommonAPI;

var WindowHandle m_hEditAugmentListWnd;
var bool bLock;
var ListCtrlHandle m_hAllSelectListCtrl;
var ListCtrlHandle m_hCurSelectListCtrl;
var ListCtrlHandle m_hAllCustomListCtrl;
var ListCtrlHandle m_hCurCustomListCtrl;
var int m_targetID;
var TabHandle m_hTabCtrl;
var EnchantAIWnd script;
const MAX_LIST=100;
const MAX_SELECT=20;
const MAX_LS=1650;

function OnLoad ()
{
	RegisterXmls();
	script = EnchantAIWnd(GetScript("EnchantAIWnd"));
	LoadAllSelectList();
	LoadCurSelectList();
	LoadAllCustomList();
	LoadCurCustomList();
}

function RegisterXmls ()
{
	m_hEditAugmentListWnd = GetHandle("InterfaceAI_EditAugmentListWnd");
	m_hAllSelectListCtrl = ListCtrlHandle(GetHandle("InterfaceAI_EditAugmentListWnd.listEditSelect"));
	m_hCurSelectListCtrl = ListCtrlHandle(GetHandle("InterfaceAI_EditAugmentListWnd.listCurSelect"));
	m_hAllCustomListCtrl = ListCtrlHandle(GetHandle("InterfaceAI_EditAugmentListWnd.listEditCustom"));
	m_hCurCustomListCtrl = ListCtrlHandle(GetHandle("InterfaceAI_EditAugmentListWnd.listCurCustom"));
	m_hTabCtrl = TabHandle(GetHandle("InterfaceAI_EditAugmentListWnd.TabListCtrl"));
}

function OnShow ()
{
	m_hTabCtrl.InitTabCtrl();
	InitLocalization();
}

function OnHide ()
{
}

function InitLocalization ()
{
	local string AllSelectList;
	local string CurSelectList;
	local string AllCustomList;
	local string CurCustomList;

	AllSelectList = "Skills base for select list:";
	CurSelectList = "Current skills of select list:";
	AllCustomList = "Skills base for custom list:";
	CurCustomList = "Current skills of custom list:";
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_EditAugmentListWnd.EditSelectListWnd.txtAllSelectList",AllSelectList);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_EditAugmentListWnd.EditSelectListWnd.txtCurSelectList",CurSelectList);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_EditAugmentListWnd.EditCustomListWnd.txtAllCustomList",AllCustomList);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_EditAugmentListWnd.EditCustomListWnd.txtCurCustomList",CurCustomList);
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnCloseLSEdit":
		m_hEditAugmentListWnd.HideWindow();
		break;
		default:
	}
}

function GetRefineryParam (int Id, out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	RefineryParam(Id,Value);
	SplitCount = Split(Value,",",arrSplit);
}

function string GetRefinerySkillName (int Id)
{
	local array<string> arrSplit;

	GetRefineryParam(Id,arrSplit);
	return arrSplit[3];
}

function string GetRefineryQualityName (int Id)
{
	local array<string> arrSplit;
	local int TypeID;
	local string Names;

	GetRefineryParam(Id,arrSplit);
	TypeID = int(arrSplit[1]);
	switch (TypeID)
	{
		case 3:
		Names = "Hight";
		break;
		case 4:
		Names = "Top";
		break;
		default:
	}
	return Names;
}

function string GetRefineryTypeName (int Id)
{
	local array<string> arrSplit;
	local int TypeID;
	local string Names;

	GetRefineryParam(Id,arrSplit);
	TypeID = int(arrSplit[2]);
	switch (TypeID)
	{
		case 1:
		Names = "Active";
		break;
		case 2:
		Names = "Passive";
		break;
		case 3:
		Names = "Chance";
		break;
		case 4:
		Names = "Stat";
		break;
		default:
	}
	return Names;
}

function int GetRefinerySkillLvl (int Id)
{
	local array<string> arrSplit;

	GetRefineryParam(Id,arrSplit);
	return int(arrSplit[4]);
}

function GetRefinerySelectList (out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	GetINIString("AutoRefinery","SelectList",Value,"Option");
	SplitCount = Split(Value,",",arrSplit);
}

function GetRefineryCustomList (out array<string> arrSplit)
{
	local string Value;
	local int SplitCount;

	GetINIString("AutoRefinery","CustomList",Value,"Option");
	SplitCount = Split(Value,",",arrSplit);
}

function LoadAllSelectList ()
{
	local int SkillID;
	local string SkillName;
	local int SkillLevel;
	local string SkillType;
	local string SkillQuality;
	local array<string> arrCurrentSelect;
	local int i;
	local int j;
	local int B;
	local bool IgnoreRecord;
	local LVDataRecord Record;
	local LVData data1;
	local LVData data2;
	local LVData data3;
	local LVData data4;
	local LVData data5;

	j = 0;
	IgnoreRecord = False;
	arrCurrentSelect.Length = 0;
	m_hAllSelectListCtrl.DeleteAllItem();
	GetRefinerySelectList(arrCurrentSelect);
	i = 14578;
	if ( UnknownFunction152(i,16380) )
	{
		B = 0;
		if ( UnknownFunction152(B,arrCurrentSelect.Length) )
		{
			IgnoreRecord = False;
			if ( UnknownFunction154(int(arrCurrentSelect[B]),i) )
			{
				IgnoreRecord = True;
			} else {
				UnknownFunction165(B);
				goto JL0052;
			}
		}
		if ( UnknownFunction129(IgnoreRecord) )
		{
			SkillLevel = GetRefinerySkillLvl(i);
			if ( UnknownFunction155(SkillLevel,0) )
			{
				SkillID = i;
				SkillName = GetRefinerySkillName(i);
				SkillType = GetRefineryTypeName(i);
				SkillQuality = GetRefineryQualityName(i);
				data1.nReserved1 = j;
				data1.szData = SkillName;
				Record.LVDataList[0] = data1;
				data2.szData = SkillType;
				Record.LVDataList[1] = data2;
				data3.szData = string(SkillLevel);
				Record.LVDataList[2] = data3;
				data4.szData = SkillQuality;
				Record.LVDataList[3] = data4;
				data5.szData = string(SkillID);
				Record.LVDataList[4] = data5;
				UnknownFunction163(j);
				m_hAllSelectListCtrl.InsertRecord(Record);
			}
		}
		UnknownFunction165(i);
		goto JL003C;
	}
	Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectAll",UnknownFunction112(UnknownFunction112(string(m_hAllSelectListCtrl.GetRecordCount()),"/"),string(1650)));
}

function LoadCurSelectList ()
{
	local int SkillID;
	local string SkillName;
	local int SkillLevel;
	local string SkillType;
	local string SkillQuality;
	local int i;
	local int j;
	local int B;
	local array<string> arrCurrentSelect;
	local LVDataRecord Record;
	local LVData data1;
	local LVData data2;
	local LVData data3;
	local LVData data4;
	local LVData data5;

	j = 0;
	arrCurrentSelect.Length = 0;
	GetRefinerySelectList(arrCurrentSelect);
	m_hCurSelectListCtrl.DeleteAllItem();
JL0034:
	i = 14578;
	if ( UnknownFunction152(i,16380) )
	{
JL004A:
		B = 0;
		if ( UnknownFunction152(B,arrCurrentSelect.Length) )
		{
			if ( UnknownFunction154(int(arrCurrentSelect[B]),i) )
			{
				SkillID = i;
				SkillName = GetRefinerySkillName(i);
				SkillLevel = GetRefinerySkillLvl(i);
				SkillType = GetRefineryTypeName(i);
				SkillQuality = GetRefineryQualityName(i);
				data1.nReserved1 = j;
				data1.szData = SkillName;
				Record.LVDataList[0] = data1;
				data2.szData = SkillType;
				Record.LVDataList[1] = data2;
				data3.szData = string(SkillLevel);
				Record.LVDataList[2] = data3;
				data4.szData = SkillQuality;
				Record.LVDataList[3] = data4;
				data5.szData = string(SkillID);
				Record.LVDataList[4] = data5;
				if ( UnknownFunction155(SkillLevel,0) )
				{
					UnknownFunction163(j);
					m_hCurSelectListCtrl.InsertRecord(Record);
				}
			} else {
				UnknownFunction165(B);
				goto JL004A;
			}
		}
		UnknownFunction165(i);
		goto JL0034;
	}
	Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectCur",UnknownFunction112(UnknownFunction112(string(m_hCurSelectListCtrl.GetRecordCount()),"/"),string(20)));
	script.ComboBoxParam();
}

function LoadAllCustomList ()
{
	local int SkillID;
	local string SkillName;
	local int SkillLevel;
	local string SkillType;
	local string SkillQuality;
	local array<string> arrCurrentSelect;
	local int i;
	local int j;
	local int B;
	local bool IgnoreRecord;
	local LVDataRecord Record;
	local LVData data1;
	local LVData data2;
	local LVData data3;
	local LVData data4;
	local LVData data5;

	j = 0;
	IgnoreRecord = False;
	arrCurrentSelect.Length = 0;
	m_hAllCustomListCtrl.DeleteAllItem();
	GetRefineryCustomList(arrCurrentSelect);
	i = 14578;
	if ( UnknownFunction152(i,16380) )
	{
		B = 0;
		if ( UnknownFunction152(B,arrCurrentSelect.Length) )
		{
			IgnoreRecord = False;
			if ( UnknownFunction154(int(arrCurrentSelect[B]),i) )
			{
				IgnoreRecord = True;
			} else {
				UnknownFunction165(B);
				goto JL0052;
			}
		}
		if ( UnknownFunction129(IgnoreRecord) )
		{
			SkillLevel = GetRefinerySkillLvl(i);
			if ( UnknownFunction155(SkillLevel,0) )
			{
				SkillID = i;
				SkillName = GetRefinerySkillName(i);
				SkillType = GetRefineryTypeName(i);
				SkillQuality = GetRefineryQualityName(i);
				data1.nReserved1 = j;
				data1.szData = SkillName;
				Record.LVDataList[0] = data1;
				data2.szData = SkillType;
				Record.LVDataList[1] = data2;
				data3.szData = string(SkillLevel);
				Record.LVDataList[2] = data3;
				data4.szData = SkillQuality;
				Record.LVDataList[3] = data4;
				data5.szData = string(SkillID);
				Record.LVDataList[4] = data5;
				UnknownFunction163(j);
				m_hAllCustomListCtrl.InsertRecord(Record);
			}
		}
		UnknownFunction165(i);
		goto JL003C;
	}
	Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomAll",UnknownFunction112(UnknownFunction112(string(m_hAllCustomListCtrl.GetRecordCount()),"/"),string(1650)));
}

function LoadCurCustomList ()
{
	local int SkillID;
	local string SkillName;
	local int SkillLevel;
	local string SkillType;
	local string SkillQuality;
	local int i;
	local int j;
	local int B;
	local array<string> arrCurrentSelect;
	local LVDataRecord Record;
	local LVData data1;
	local LVData data2;
	local LVData data3;
	local LVData data4;
	local LVData data5;

	j = 0;
	arrCurrentSelect.Length = 0;
	GetRefineryCustomList(arrCurrentSelect);
	m_hCurCustomListCtrl.DeleteAllItem();
JL0034:
	i = 14578;
	if ( UnknownFunction152(i,16380) )
	{
JL004A:
		B = 0;
		if ( UnknownFunction152(B,arrCurrentSelect.Length) )
		{
			if ( UnknownFunction154(int(arrCurrentSelect[B]),i) )
			{
				SkillID = i;
				SkillName = GetRefinerySkillName(i);
				SkillLevel = GetRefinerySkillLvl(i);
				SkillType = GetRefineryTypeName(i);
				SkillQuality = GetRefineryQualityName(i);
				data1.nReserved1 = j;
				data1.szData = SkillName;
				Record.LVDataList[0] = data1;
				data2.szData = SkillType;
				Record.LVDataList[1] = data2;
				data3.szData = string(SkillLevel);
				Record.LVDataList[2] = data3;
				data4.szData = SkillQuality;
				Record.LVDataList[3] = data4;
				data5.szData = string(SkillID);
				Record.LVDataList[4] = data5;
				if ( UnknownFunction155(SkillLevel,0) )
				{
					UnknownFunction163(j);
					m_hCurCustomListCtrl.InsertRecord(Record);
				}
			} else {
				UnknownFunction165(B);
				goto JL004A;
			}
		}
		UnknownFunction165(i);
		goto JL0034;
	}
	Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomCur",UnknownFunction112(UnknownFunction112(string(m_hCurCustomListCtrl.GetRecordCount()),"/"),string(100)));
}

function OnDBClickListCtrlRecord (string ListCtrlID)
{
	local LVDataRecord Record;
	local int RecordIndex;

	if ( UnknownFunction122(ListCtrlID,"listEditSelect") )
	{
		if ( UnknownFunction150(m_hCurSelectListCtrl.GetRecordCount(),20) )
		{
			Record = m_hAllSelectListCtrl.GetSelectedRecord();
			AddSelectListOption(int(Record.LVDataList[4].szData));
			m_hCurSelectListCtrl.InsertRecord(Record);
			RecordIndex = m_hAllSelectListCtrl.GetSelectedIndex();
			m_hAllSelectListCtrl.DeleteRecord(RecordIndex);
			script.ComboBoxParam();
			Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectAll",UnknownFunction112(UnknownFunction112(string(m_hAllSelectListCtrl.GetRecordCount()),"/"),string(1650)));
			Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectCur",UnknownFunction112(UnknownFunction112(string(m_hCurSelectListCtrl.GetRecordCount()),"/"),string(20)));
		}
	} else {
		if ( UnknownFunction122(ListCtrlID,"listCurSelect") )
		{
			Record = m_hCurSelectListCtrl.GetSelectedRecord();
			DelSelectListOption(int(Record.LVDataList[4].szData));
			m_hAllSelectListCtrl.InsertRecord(Record);
			RecordIndex = m_hCurSelectListCtrl.GetSelectedIndex();
			if ( UnknownFunction154(m_hCurSelectListCtrl.GetRecordCount(),1) )
			{
				m_hCurSelectListCtrl.DeleteAllItem();
			} else {
				m_hCurSelectListCtrl.DeleteRecord(RecordIndex);
			}
			script.ComboBoxParam();
			Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectAll",UnknownFunction112(UnknownFunction112(string(m_hAllSelectListCtrl.GetRecordCount()),"/"),string(1650)));
			Class'UIAPI_TEXTBOX'.SetText("EditSelectListWnd.valListSelectCur",UnknownFunction112(UnknownFunction112(string(m_hCurSelectListCtrl.GetRecordCount()),"/"),string(20)));
		} else {
			if ( UnknownFunction122(ListCtrlID,"listEditCustom") )
			{
				if ( UnknownFunction150(m_hCurCustomListCtrl.GetRecordCount(),100) )
				{
					Record = m_hAllCustomListCtrl.GetSelectedRecord();
					AddCustomListOption(int(Record.LVDataList[4].szData));
					m_hCurCustomListCtrl.InsertRecord(Record);
					RecordIndex = m_hAllCustomListCtrl.GetSelectedIndex();
					m_hAllCustomListCtrl.DeleteRecord(RecordIndex);
					Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomAll",UnknownFunction112(UnknownFunction112(string(m_hAllCustomListCtrl.GetRecordCount()),"/"),string(1650)));
					Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomCur",UnknownFunction112(UnknownFunction112(string(m_hCurCustomListCtrl.GetRecordCount()),"/"),string(100)));
				}
			} else {
				if ( UnknownFunction122(ListCtrlID,"listCurCustom") )
				{
					Record = m_hCurCustomListCtrl.GetSelectedRecord();
					DelCustomListOption(int(Record.LVDataList[4].szData));
					m_hAllCustomListCtrl.InsertRecord(Record);
					RecordIndex = m_hCurCustomListCtrl.GetSelectedIndex();
					if ( UnknownFunction154(m_hCurCustomListCtrl.GetRecordCount(),1) )
					{
						m_hCurCustomListCtrl.DeleteAllItem();
					} else {
						m_hCurCustomListCtrl.DeleteRecord(RecordIndex);
					}
					Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomAll",UnknownFunction112(UnknownFunction112(string(m_hAllCustomListCtrl.GetRecordCount()),"/"),string(1650)));
					Class'UIAPI_TEXTBOX'.SetText("EditCustomListWnd.valListCustomCur",UnknownFunction112(UnknownFunction112(string(m_hCurCustomListCtrl.GetRecordCount()),"/"),string(100)));
				}
			}
		}
	}
}

function DelSelectListOption (int Id)
{
	local array<string> arrCurrentSelect;
	local int i;
	local string ResultSelectList;

	arrCurrentSelect.Length = 0;
	ResultSelectList = "";
	GetRefinerySelectList(arrCurrentSelect);
	i = 0;
	if ( UnknownFunction152(i,arrCurrentSelect.Length) )
	{
		if ( UnknownFunction154(int(arrCurrentSelect[i]),Id) )
		{
			arrCurrentSelect[i] = "";
		}
		UnknownFunction165(i);
		goto JL0022;
	}
	JoinArray(arrCurrentSelect,ResultSelectList,",",True);
	SetINIString("AutoRefinery","SelectList",ResultSelectList,"Option");
}

function AddSelectListOption (int Id)
{
	local array<string> arrCurrentSelect;
	local string ResultSelectList;

	arrCurrentSelect.Length = 0;
	ResultSelectList = "";
	GetRefinerySelectList(arrCurrentSelect);
	byte(arrCurrentSelect)
	arrCurrentSelect.Length
	1
	arrCurrentSelect[arrCurrentSelect.Length] = string(Id);
	JoinArray(arrCurrentSelect,ResultSelectList,",",True);
	SetINIString("AutoRefinery","SelectList",ResultSelectList,"Option");
}

function AddCustomListOption (int Id)
{
	local array<string> arrCurrentCustom;
	local string ResultCustomList;

	arrCurrentCustom.Length = 0;
	ResultCustomList = "";
	GetRefineryCustomList(arrCurrentCustom);
	byte(arrCurrentCustom)
	arrCurrentCustom.Length
	1
	arrCurrentCustom[arrCurrentCustom.Length] = string(Id);
	JoinArray(arrCurrentCustom,ResultCustomList,",",True);
	SetINIString("AutoRefinery","CustomList",ResultCustomList,"Option");
}

function DelCustomListOption (int Id)
{
	local array<string> arrCurrentCustom;
	local int i;
	local string ResultCustomList;

	arrCurrentCustom.Length = 0;
	ResultCustomList = "";
	GetRefineryCustomList(arrCurrentCustom);
	i = 0;
	if ( UnknownFunction152(i,arrCurrentCustom.Length) )
	{
		if ( UnknownFunction154(int(arrCurrentCustom[i]),Id) )
		{
			arrCurrentCustom[i] = "";
		}
		UnknownFunction165(i);
		goto JL0022;
	}
	JoinArray(arrCurrentCustom,ResultCustomList,",",True);
	SetINIString("AutoRefinery","CustomList",ResultCustomList,"Option");
}


//================================================================================
// InterfaceAI_BypassEdit.
//================================================================================

class InterfaceAI_BypassEdit extends UICommonAPI;

var WindowHandle Me;
var WindowHandle RefOption;
var WindowHandle UnRefOption;
var CheckBoxHandle checkIsCrypt;
var CheckBoxHandle checkUseRefBypass;
var CheckBoxHandle checkUseUnRefBypass;
var CheckBoxHandle checkUseRefBypass_1;
var CheckBoxHandle checkUseRefBypass_2;
var CheckBoxHandle checkUseRefBypass_3;
var CheckBoxHandle checkUseUnRefBypass_1;
var CheckBoxHandle checkUseUnRefBypass_2;
var CheckBoxHandle checkUseUnRefBypass_3;
var EditBoxHandle editBypassRef_1;
var EditBoxHandle editBypassRef_2;
var EditBoxHandle editBypassRef_3;
var EditBoxHandle editBypassUnRef_1;
var EditBoxHandle editBypassUnRef_2;
var EditBoxHandle editBypassUnRef_3;
var string RefBypass_1;
var string RefBypass_2;
var string RefBypass_3;
var string UnRefBypass_1;
var string UnRefBypass_2;
var string UnRefBypass_3;
var bool UseRefinedBypass_1;
var bool UseRefinedBypass_2;
var bool UseRefinedBypass_3;
var bool UseUnRefinedBypass_1;
var bool UseUnRefinedBypass_2;
var bool UseUnRefinedBypass_3;
var bool UseRefinedBypass;
var bool UseUnRefinedBypass;
var bool UseCryptBypass;
var EnchantAIWnd script;

function OnLoad ()
{
	InitHandle();
	LoadData();
}

function LoadData ()
{
	local int IntUseCryptBypass;
	local int IntUseRefinedBypass;
	local int IntUseRefinedBypass_1;
	local int IntUseRefinedBypass_2;
	local int IntUseRefinedBypass_3;
	local int IntUseUnRefinedBypass;
	local int IntUseUnRefinedBypass_1;
	local int IntUseUnRefinedBypass_2;
	local int IntUseUnRefinedBypass_3;

	GetINIString("AutoRefinery","RefinedBypass_1",RefBypass_1,"Option");
	GetINIString("AutoRefinery","RefinedBypass_2",RefBypass_2,"Option");
	GetINIString("AutoRefinery","RefinedBypass_3",RefBypass_3,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_1",UnRefBypass_1,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_2",UnRefBypass_2,"Option");
	GetINIString("AutoRefinery","UnRefinedBypass_3",UnRefBypass_3,"Option");
	GetINIBool("AutoRefinery","UseCryptBypass",IntUseCryptBypass,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass",IntUseRefinedBypass,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass",IntUseUnRefinedBypass,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_1",IntUseRefinedBypass_1,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_2",IntUseRefinedBypass_2,"Option");
	GetINIBool("AutoRefinery","UseRefinedBypass_3",IntUseRefinedBypass_3,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_1",IntUseUnRefinedBypass_1,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_2",IntUseUnRefinedBypass_2,"Option");
	GetINIBool("AutoRefinery","UseUnRefinedBypass_3",IntUseUnRefinedBypass_3,"Option");
	UseCryptBypass = bool(IntUseCryptBypass);
	UseRefinedBypass = bool(IntUseRefinedBypass);
	UseUnRefinedBypass = bool(IntUseUnRefinedBypass);
	UseRefinedBypass_1 = bool(IntUseRefinedBypass_1);
	UseRefinedBypass_2 = bool(IntUseRefinedBypass_2);
	UseRefinedBypass_3 = bool(IntUseRefinedBypass_3);
	UseUnRefinedBypass_1 = bool(IntUseUnRefinedBypass_1);
	UseUnRefinedBypass_2 = bool(IntUseUnRefinedBypass_2);
	UseUnRefinedBypass_3 = bool(IntUseUnRefinedBypass_3);
}

function InitHandle ()
{
	Me = GetHandle("InterfaceAI_BypassEdit");
	RefOption = GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd");
	UnRefOption = GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd");
	checkIsCrypt = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.checkIsCryptBypass"));
	checkUseRefBypass = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.checkUseRefBypass"));
	checkUseUnRefBypass = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.checkUseUnRefBypass"));
	checkUseRefBypass_1 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_1"));
	checkUseRefBypass_2 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_2"));
	checkUseRefBypass_3 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_3"));
	checkUseUnRefBypass_1 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_1"));
	checkUseUnRefBypass_2 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_2"));
	checkUseUnRefBypass_3 = CheckBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_3"));
	editBypassRef_1 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.EditRefBypass_1"));
	editBypassRef_2 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.EditRefBypass_2"));
	editBypassRef_3 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditRefWnd.EditRefBypass_3"));
	editBypassUnRef_1 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.EditUnRefBypass_1"));
	editBypassUnRef_2 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.EditUnRefBypass_2"));
	editBypassUnRef_3 = EditBoxHandle(GetHandle("InterfaceAI_BypassEdit.BypassEditUnRefWnd.EditUnRefBypass_3"));
	script = EnchantAIWnd(GetScript("EnchantAIWnd"));
}

function OnShow ()
{
	checkIsCrypt.SetCheck(UseCryptBypass);
	checkUseRefBypass.SetCheck(UseRefinedBypass);
	checkUseUnRefBypass.SetCheck(UseUnRefinedBypass);
	checkUseRefBypass_1.SetCheck(UseRefinedBypass_1);
	checkUseRefBypass_2.SetCheck(UseRefinedBypass_2);
	checkUseRefBypass_3.SetCheck(UseRefinedBypass_3);
	checkUseUnRefBypass_1.SetCheck(UseUnRefinedBypass_1);
	checkUseUnRefBypass_2.SetCheck(UseUnRefinedBypass_2);
	checkUseUnRefBypass_2.SetCheck(UseUnRefinedBypass_3);
	editBypassRef_1.SetString(RefBypass_1);
	editBypassRef_2.SetString(RefBypass_2);
	editBypassRef_3.SetString(RefBypass_3);
	editBypassUnRef_1.SetString(UnRefBypass_1);
	editBypassUnRef_2.SetString(UnRefBypass_2);
	editBypassUnRef_2.SetString(UnRefBypass_3);
	if ( UseRefinedBypass )
	{
		RefOption.EnableWindow();
	} else {
		RefOption.DisableWindow();
	}
	if ( UseUnRefinedBypass )
	{
		UnRefOption.EnableWindow();
	} else {
		UnRefOption.DisableWindow();
	}
	InitLocalization();
}

function OnHide ()
{
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnBypassEditClose":
		Me.HideWindow();
		break;
		case "btnBypassOK":
		BypassApplyParam();
		Me.HideWindow();
		break;
		default:
	}
}

function BypassApplyParam ()
{
	script.NPC_Simul_SetParam(True,UseCryptBypass,UseRefinedBypass,UseRefinedBypass_1,UseRefinedBypass_2,UseRefinedBypass_3,UseUnRefinedBypass,UseUnRefinedBypass_1,UseUnRefinedBypass_2,UseUnRefinedBypass_3,RefBypass_1,RefBypass_2,RefBypass_3,UnRefBypass_1,UnRefBypass_2,UnRefBypass_3);
}

function OnClickCheckBox (string strID)
{
	switch (strID)
	{
		case "checkIsCryptBypass":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.checkIsCryptBypass") )
		{
			UseCryptBypass = True;
		} else {
			UseCryptBypass = False;
		}
		break;
		case "checkUseRefBypass":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.checkUseRefBypass") )
		{
			UseRefinedBypass = True;
			RefOption.EnableWindow();
		} else {
			UseRefinedBypass = False;
			RefOption.DisableWindow();
		}
		break;
		case "checkUseUnRefBypass":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.checkUseUnRefBypass") )
		{
			UseUnRefinedBypass = True;
			UnRefOption.EnableWindow();
		} else {
			UseUnRefinedBypass = False;
			UnRefOption.DisableWindow();
		}
		break;
		case "checkUseBypassRef_1":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_1") )
		{
			UseRefinedBypass_1 = True;
		} else {
			UseRefinedBypass_1 = False;
		}
		break;
		case "checkUseBypassRef_2":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_2") )
		{
			UseRefinedBypass_2 = True;
		} else {
			UseRefinedBypass_2 = False;
		}
		break;
		case "checkUseBypassRef_3":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditRefWnd.checkUseBypassRef_3") )
		{
			UseRefinedBypass_3 = True;
		} else {
			UseRefinedBypass_3 = False;
		}
		break;
		case "checkUseBypassUnRef_1":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_1") )
		{
			UseUnRefinedBypass_1 = True;
		} else {
			UseUnRefinedBypass_1 = False;
		}
		break;
		case "checkUseBypassUnRef_2":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_2") )
		{
			UseUnRefinedBypass_2 = True;
		} else {
			UseUnRefinedBypass_2 = False;
		}
		break;
		case "checkUseBypassUnRef_3":
		if ( Class'UIAPI_CHECKBOX'.IsChecked("InterfaceAI_BypassEdit.BypassEditUnRefWnd.checkUseBypassUnRef_3") )
		{
			UseUnRefinedBypass_3 = True;
		} else {
			UseUnRefinedBypass_3 = False;
		}
		break;
		default:
	}
}

function OnChangeEditBox (string strID)
{
	switch (strID)
	{
		case "EditRefBypass_1":
		RefBypass_1 = editBypassRef_1.GetString();
		break;
		case "EditRefBypass_2":
		RefBypass_2 = editBypassRef_2.GetString();
		break;
		case "EditRefBypass_3":
		RefBypass_3 = editBypassRef_3.GetString();
		break;
		case "EditUnRefBypass_1":
		UnRefBypass_1 = editBypassUnRef_1.GetString();
		break;
		case "EditUnRefBypass_2":
		UnRefBypass_2 = editBypassUnRef_2.GetString();
		break;
		case "EditUnRefBypass_3":
		UnRefBypass_3 = editBypassUnRef_3.GetString();
		break;
		default:
	}
}

function InitLocalization ()
{
	local string TextUseRefBypass;
	local string TextUseUnRefBypass;

	TextUseRefBypass = "Use Refinery bypass?";
	TextUseUnRefBypass = "Use UnRefinery bypass?";
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_BypassEdit.txtUseRefBypass",TextUseRefBypass);
	Class'UIAPI_TEXTBOX'.SetText("InterfaceAI_BypassEdit.txtUseUnRefBypass",TextUseUnRefBypass);
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}


//================================================================================
// SummonedWnd.
//================================================================================

class SummonedWnd extends UICommonAPI;

var WindowHandle Me;
var int m_PetID;
var bool GIFT_OF_SERAPHIM;
var bool BLESSING_OF_QUEEN;
var bool GIFT_OF_SERAPHIM_ENABLED;
var bool BLESSING_OF_QUEEN_ENABLED;
var string BuffsParams;
const NPET_SMALLBARSIZE= 256;
const NPET_BARHEIGHT= 12;
const BLESSING_OF_QUEEN_TIMER= 100099;
const GIFT_OF_SERAPHIM_TIMER= 100098;

function OnLoad ()
{
	Me = GetHandle("SummonedWnd");
	RegisterEvent(250);
	RegisterEvent(1090);
	RegisterEvent(1130);
	RegisterEvent(1340);
	RegisterEvent(1350);
	RegisterEvent(1900);
	RegisterEvent(950);
	GIFT_OF_SERAPHIM = False;
	BLESSING_OF_QUEEN = False;
	GIFT_OF_SERAPHIM_ENABLED = False;
	BLESSING_OF_QUEEN_ENABLED = False;
	Me.KillTimer(100098);
	Me.KillTimer(100099);
	HideScrollBar();
}

function OnShow ()
{
	Class'ActionAPI'.RequestSummonedActionList();
	SetFocus();
}

function HandleLanguageChanged ()
{
	Class'ActionAPI'.RequestSummonedActionList();
}

function OnEnterState (name a_PreStateName)
{
	GIFT_OF_SERAPHIM = False;
	BLESSING_OF_QUEEN = False;
	GIFT_OF_SERAPHIM_ENABLED = False;
	BLESSING_OF_QUEEN_ENABLED = False;
	Me.KillTimer(100098);
	Me.KillTimer(100099);
}

function OnEvent (int Event_ID, string param)
{
	if ( Equals(Event_ID,250) )
	{
		HandlePetInfoUpdate();
	} else {
		if ( Equals(Event_ID,1130) )
		{
			HandlePetSummonedStatusClose();
		} else {
			if ( Equals(Event_ID,1090) )
			{
				HandlePetShow();
			} else {
				if ( Equals(Event_ID,1340) )
				{
					HandleActionSummonedListStart();
				} else {
					if ( Equals(Event_ID,1350) )
					{
						HandleActionSummonedList(param);
					} else {
						if ( Equals(Event_ID,1900) )
						{
							HandleLanguageChanged();
						} else {
							if ( UnknownFunction154(Event_ID,950) )
							{
								BuffsParams = param;
							}
						}
					}
				}
			}
		}
	}
}

function HandleBoolean ()
{
	local int i;
	local int Max;
	local StatusIconInfo Info;

	GIFT_OF_SERAPHIM = False;
	BLESSING_OF_QUEEN = False;
	ParseInt(BuffsParams,"Max",Max);
	i = 0;
	if ( UnknownFunction150(i,Max) )
	{
		ParseInt(BuffsParams,UnknownFunction112("SkillID_",string(i)),Info.ClassID);
		if ( UnknownFunction151(Info.ClassID,0) )
		{
			if ( UnknownFunction154(Info.ClassID,4703) )
			{
				GIFT_OF_SERAPHIM = True;
			}
			if ( UnknownFunction154(Info.ClassID,4699) )
			{
				BLESSING_OF_QUEEN = True;
			}
		}
		UnknownFunction165(i);
		goto JL002C;
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnClose":
		Me.HideWindow();
		break;
		default:
	}
}

function OnClickItem (string strID, int Index)
{
	local ItemInfo infItem;

	if ( LogicalAND(StrEquals(strID,"SummonedActionWnd"),GreaterThan(Index,-1)) )
	{
		if ( Class'UIAPI_ITEMWINDOW'.GetItem("SummonedWnd.SummonedWnd_Action.SummonedActionWnd",Index,infItem) )
		{
			DoAction(infItem.ClassID);
		}
	}
}

function OnRClickItem (string strID, int Index)
{
	EnableDisable(strID,Index);
}

function EnableDisable (string strID, int Index)
{
	local ItemInfo Info;

	if ( UnknownFunction130(UnknownFunction122(strID,"SummonedActionWnd"),UnknownFunction151(Index,-1)) )
	{
		if ( Class'UIAPI_ITEMWINDOW'.GetItem("SummonedWnd.SummonedWnd_Action.SummonedActionWnd",Index,Info) )
		{
			if ( UnknownFunction154(Info.ClassID,1011) )
			{
				if ( UnknownFunction129(GIFT_OF_SERAPHIM_ENABLED) )
				{
					Me.SetTimer(100098,2000);
					Info.ForeTexture = "InterfaceTextures.Auto";
					GIFT_OF_SERAPHIM_ENABLED = True;
				} else {
					Me.KillTimer(100098);
					Info.ForeTexture = "";
					GIFT_OF_SERAPHIM_ENABLED = False;
				}
			}
			if ( UnknownFunction154(Info.ClassID,1007) )
			{
				if ( UnknownFunction129(BLESSING_OF_QUEEN_ENABLED) )
				{
					Me.SetTimer(100099,2000);
					Info.ForeTexture = "InterfaceTextures.Auto";
					BLESSING_OF_QUEEN_ENABLED = True;
				} else {
					Me.KillTimer(100099);
					Info.ForeTexture = "";
					BLESSING_OF_QUEEN_ENABLED = False;
				}
			}
		}
	}
}

function OnTimer (int Index)
{
	if ( UnknownFunction154(Index,100098) )
	{
		HandleBoolean();
		if ( UnknownFunction129(GIFT_OF_SERAPHIM) )
		{
			DoAction(1011);
		}
	}
	if ( UnknownFunction154(Index,100099) )
	{
		HandleBoolean();
		if ( UnknownFunction129(BLESSING_OF_QUEEN) )
		{
			DoAction(1007);
		}
	}
}

function HideScrollBar ()
{
	Class'UIAPI_ITEMWINDOW'.ShowScrollBar("SummonedWnd.SummonedWnd_Action.SummonedActionWnd",False);
}

function HandleActionSummonedListStart ()
{
	ClearActionWnd();
}

function Clear ()
{
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtLvName","");
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtHP","0/0");
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMP","0/0");
	UpdateHPBar(0,0);
	UpdateMPBar(0,0);
}

function ClearActionWnd ()
{
	Class'UIAPI_ITEMWINDOW'.Clear("SummonedWnd.SummonedWnd_Action.SummonedActionWnd");
}

function HandlePetSummonedStatusClose ()
{
	Class'UIAPI_WINDOW'.HideWindow("SummonedWnd");
	PlayConsoleSound(6);
	GIFT_OF_SERAPHIM = False;
	BLESSING_OF_QUEEN = False;
	GIFT_OF_SERAPHIM_ENABLED = False;
	BLESSING_OF_QUEEN_ENABLED = False;
	Me.KillTimer(100098);
	Me.KillTimer(100099);
}

function HandlePetInfoUpdate ()
{
	local string Name;
	local int HP;
	local int maxHP;
	local int MP;
	local int maxMP;
	local int Level;
	local int PhysicalAttack;
	local int PhysicalDefense;
	local int HitRate;
	local int CriticalRate;
	local int PhysicalAttackSpeed;
	local int MagicalAttack;
	local int MagicDefense;
	local int PhysicalAvoid;
	local int MovingSpeed;
	local int MagicCastingSpeed;
	local int SoulShotCosume;
	local int SpiritShotConsume;
	local PetInfo Info;

	if ( GetPetInfo(Info) )
	{
		m_PetID = Info.nID;
		Name = Info.Name;
		Level = Info.nLevel;
		HP = Info.nCurHP;
		maxHP = Info.nMaxHP;
		MP = Info.nCurMP;
		maxMP = Info.nMaxMP;
		PhysicalAttack = Info.nPhysicalAttack;
		PhysicalDefense = Info.nPhysicalDefense;
		HitRate = Info.nHitRate;
		CriticalRate = Info.nCriticalRate;
		PhysicalAttackSpeed = Info.nPhysicalAttackSpeed;
		MagicalAttack = Info.nMagicalAttack;
		MagicDefense = Info.nMagicDefense;
		PhysicalAvoid = Info.nPhysicalAvoid;
		MovingSpeed = Info.nMovingSpeed;
		MagicCastingSpeed = Info.nMagicCastingSpeed;
		SoulShotCosume = Info.nSoulShotCosume;
		SpiritShotConsume = Info.nSpiritShotConsume;
	}
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtLvName",StrCat(StrCat(string(Level)," "),Name));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtHP",StrCat(StrCat(string(HP),"/"),string(maxHP)));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMP",StrCat(StrCat(string(MP),"/"),string(maxMP)));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtPhysicalAttack",string(PhysicalAttack));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtPhysicalDefense",string(PhysicalDefense));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtHitRate",string(HitRate));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtCriticalRate",string(CriticalRate));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtPhysicalAttackSpeed",string(PhysicalAttackSpeed));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMagicalAttack",string(MagicalAttack));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMagicDefense",string(MagicDefense));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtPhysicalAvoid",string(PhysicalAvoid));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMovingSpeed",string(MovingSpeed));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtMagicCastingSpeed",string(MagicCastingSpeed));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtSoulShotCosume",string(SoulShotCosume));
	Class'UIAPI_TEXTBOX'.SetText("SummonedWnd.txtSpiritShotConsume",string(SpiritShotConsume));
	Class'UIAPI_TEXTURECTRL'.SetTexture("SummonedWnd.PetIcon",GetPetIcon(Name));
	UpdateHPBar(HP,maxHP);
	UpdateMPBar(MP,maxMP);
}

function HandlePetShow ()
{
	Clear();
	HandlePetInfoUpdate();
	PlayConsoleSound(5);
	Class'UIAPI_WINDOW'.ShowWindow("SummonedWnd");
	Class'UIAPI_WINDOW'.SetFocus("SummonedWnd");
}

function UpdateHPBar (int Value, int MaxValue)
{
	local int Size;

	Size = 0;
	if ( GreaterThan(MaxValue,0) )
	{
		Size = 256;
		if ( LessThan(Value,MaxValue) )
		{
			Size = IntDiv(IntMul(256,Value),MaxValue);
		}
	}
	Class'UIAPI_WINDOW'.SetWindowSize("SummonedWnd.texHP",Size,12);
}

function UpdateMPBar (int Value, int MaxValue)
{
	local int Size;

	Size = 0;
	if ( GreaterThan(MaxValue,0) )
	{
		Size = 256;
		if ( LessThan(Value,MaxValue) )
		{
			Size = IntDiv(IntMul(256,Value),MaxValue);
		}
	}
	Class'UIAPI_WINDOW'.SetWindowSize("SummonedWnd.texMP",Size,12);
}

function HandleActionSummonedList (string param)
{
	local int tmp;
	local EActionCategory Type;
	local int ActionID;
	local string strActionName;
	local string strIconName;
	local string strDescription;
	local string strCommand;
	local ItemInfo infItem;

	ParseInt(param,"Type",tmp);
	ParseInt(param,"ActionID",ActionID);
	ParseString(param,"Name",strActionName);
	ParseString(param,"IconName",strIconName);
	ParseString(param,"Description",strDescription);
	ParseString(param,"Command",strCommand);
	infItem.ClassID = ActionID;
	infItem.Name = strActionName;
	infItem.IconName = RedirectIconName(strIconName);
	infItem.Description = strDescription;
	infItem.ItemSubType = 3;
	infItem.MacroCommand = strCommand;
	Type = tmp;
	if ( UnknownFunction154(Type,5) )
	{
		Class'UIAPI_ITEMWINDOW'.AddItem("SummonedWnd.SummonedWnd_Action.SummonedActionWnd",infItem);
	}
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("SummonedWnd.SummonedWnd_Action.SummonedActionWnd");
	Class'UIAPI_WINDOW'.SetFocus("SummonedWnd.SummonedWnd_Status");
}

function string GetPetIcon (string Name)
{
	local string resultString;

	switch (Name)
	{
		case "Feline Queen":
		resultString = "Icon.Skill1331";
		break;
		case "Mew the Cat":
		resultString = "Icon.Skill1225";
		break;
		case "Kat the Cat":
		resultString = "Icon.Skill1111";
		break;
		case "Kai the Cat":
		resultString = "Icon.Skill1276";
		break;
		case "Feline King":
		resultString = "Icon.Skill1406";
		break;
		case "Unicorn Seraphim":
		resultString = "Icon.Skill1332";
		break;
		case "Boxer the Unicorn":
		resultString = "Icon.Skill1226";
		break;
		case "Mirage the Unicorn":
		resultString = "Icon.Skill1227";
		break;
		case "Merrow the Unicorn":
		resultString = "Icon.Skill1277";
		break;
		case "Magnus the Unicorn":
		resultString = "Icon.Skill1407";
		break;
		case "Spectral Lord":
		resultString = "Icon.Skill1408";
		break;
		case "Nightshade":
		resultString = "Icon.Skill1333";
		break;
		case "Silhouette":
		resultString = "Icon.Skill1228";
		break;
		case "Shadow":
		resultString = "Icon.Skill1128";
		break;
		case "Soulless":
		resultString = "Icon.Skill1278";
		break;
		case "Corrupted Man":
		resultString = "Icon.Skill1154";
		break;
		case "Cursed man":
		resultString = "Icon.Skill1334";
		break;
		case "Reanimated Man":
		resultString = "Icon.Skill1129";
		break;
		case "Mechanic Golem":
		resultString = "Icon.Skill0025";
		break;
		case "Siege Golem":
		resultString = "Icon.Skill0013";
		break;
		case "Wild Hog Cannon":
		resultString = "Icon.Skill0299";
		break;
		case "Big Boom":
		resultString = "Icon.Skill0299";
		break;
		case "Swoop Cannon":
		resultString = "Icon.Skill0448";
		break;
		default:
		resultString = "L2UI_CH3.PetIcon";
	}
	return resultString;
}

function string RedirectIconName (string Name)
{
	local string resultString;

	switch (Name)
	{
		case "Icon.Action101":
		resultString = "NphrnTextures.Action201";
		break;
		case "Icon.Action102":
		resultString = "NphrnTextures.Action202";
		break;
		case "Icon.Action103":
		resultString = "NphrnTextures.Action203";
		break;
		case "Icon.Action104":
		resultString = "NphrnTextures.Action204";
		break;
		case "Icon.Action105":
		resultString = "NphrnTextures.Action205";
		break;
		case "Icon.Action106":
		resultString = "NphrnTextures.Action206";
		break;
		case "Icon.Action107":
		resultString = "NphrnTextures.Action207";
		break;
		case "Icon.Action108":
		resultString = "NphrnTextures.Action208";
		break;
		case "Icon.Action109":
		resultString = "NphrnTextures.Action209";
		break;
		case "Icon.Action111":
		resultString = "NphrnTextures.Action211";
		break;
		case "Icon.Action112":
		resultString = "NphrnTextures.Action212";
		break;
		default:
	}
	return resultString;
}


//================================================================================
// NPHRN_MinimapWnd_NEW.
//================================================================================

class NPHRN_MinimapWnd_NEW extends UICommonAPI;

var WindowHandle Me;
var WindowHandle NPHRN_MiniMapHandler_NEW;
var int PartyMemberCount;
var int i_UnkInt_1;
var ButtonHandle BtnFixLoc;
var ButtonHandle BtnResize;
var bool FixedLocation;
var bool Large;
var TextureHandle Circle;
var TextureHandle TexZone;
var string Radar_Btn_;
var string ZoneName;
var int ZoneCode;

function OnLoad ()
{
	RegisterEvent(2900);
	RegisterEvent(110);
	RegisterEvent(2420);
	RegisterEvent(520);
	RegisterEvent(1790);
	RegisterEvent(1800);
	RegisterEvent(1810);
	RegisterEvent(1820);
	RegisterEvent(1830);
	RegisterEvent(11223344);
	Me = GetHandle("NPHRN_MinimapWnd_NEW");
	NPHRN_MiniMapHandler_NEW = GetHandle("NPHRN_MiniMapHandler_NEW");
	BtnFixLoc = ButtonHandle(GetHandle("NPHRN_MinimapWnd_NEW.BtnFixLoc"));
	BtnResize = ButtonHandle(GetHandle("NPHRN_MinimapWnd_NEW.BtnResize"));
	BtnResize.SetTooltipCustomType(MakeTooltipSimpleText("Resize"));
	FixedLocation = True;
	TexZone = TextureHandle(GetHandle("NPHRN_MinimapWnd_NEW.TexZone"));
	Circle = TextureHandle(GetHandle("NPHRN_MinimapWnd_NEW.Circle"));
	Radar_Btn_ = "InterfaceTextures.Radar_Btn_";
	HandleRadarTransparency();
}

function OnShow ()
{
	HandleMinimap();
	AdjustMapToPlayerPosition(True);
	HandleRadarTransparency();
}

function OnTick ()
{
	if ( FixedLocation )
	{
		AdjustMapToPlayerPosition(True);
	}
}

function OnEvent (int Event_ID, string param)
{
	switch (Event_ID)
	{
		case 2900:
		NPHRN_MiniMapHandler_NEW.SetAnchor("","TopRight","TopRight",-1,1);
		NPHRN_MiniMapHandler_NEW.ClearAnchor();
		break;
		case 110:
		ParseInt(param,"ZoneCode",ZoneCode);
		HandleZoneShow(ZoneCode);
		break;
		case 2420:
		ParseString(param,"ZoneName",ZoneName);
		HandleZoneShow(ZoneCode);
		break;
		case 520:
		ParsePartyMemberCount(param);
		break;
		case 1790:
		HandleMinimapAddTarget(param);
		break;
		case 1800:
		HandleMinimapDeleteTarget(param);
		break;
		case 1810:
		Class'UIAPI_MINIMAPCTRL'.DeleteAllTarget("NPHRN_MinimapWnd_NEW.Minimap");
		break;
		case 1820:
		Class'UIAPI_MINIMAPCTRL'.SetShowQuest("NPHRN_MinimapWnd_NEW.Minimap",True);
		break;
		case 1830:
		Class'UIAPI_MINIMAPCTRL'.SetShowQuest("NPHRN_MinimapWnd_NEW.Minimap",False);
		break;
		case 11223344:
		HandleRadarShowHide();
		break;
		default:
	}
}

function HandleRadarShowHide ()
{
	local int idx;

	idx = GetOptionInt("Custom","Minimap");
	switch (idx)
	{
		case 0:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_NEW");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_NEW");
		break;
		case 1:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_NEW");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_NEW");
		break;
		case 2:
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_NEW");
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapHandler_NEW");
		break;
		case 3:
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MiniMapWnd_NEW");
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MiniMapHandler_NEW");
		break;
		default:
	}
}

function OnClickButton (string param)
{
	switch (param)
	{
		case "BtnFixLoc":
		HandleFixLoc();
		break;
		case "BtnTrans":
		HandleRadarButtonClick();
		break;
		case "BtnTargetLoc":
		ShowTargetLocation();
		break;
		case "BtnPartyLoc":
		ShowPartyMemberLocation();
		break;
		case "BtnResize":
		if ( Large )
		{
			Large = False;
		} else {
			Large = True;
		}
		ResizeWnd();
		break;
		default:
	}
}

function HandleZoneShow (int idx)
{
	local CustomTooltip param;
	local DrawItemInfo zoneDraw;
	local DrawItemInfo ZoneState;
	local string Str;

	param.MinimumWidth = 144;
	param.DrawList[0] = zoneDraw;
	param.DrawList[1] = ZoneState;
	param.DrawList.Length = 2;
	zoneDraw.eType = 1;
	zoneDraw.nOffSetY = 6;
	zoneDraw.bLineBreak = True;
	zoneDraw.t_color.R = 255;
	zoneDraw.t_color.G = 255;
	zoneDraw.t_color.B = 255;
	zoneDraw.t_color.A = 255;
	zoneDraw.t_strText = ZoneName;
	param.DrawList[1] = zoneDraw;
	ZoneState.eType = 1;
	ZoneState.nOffSetY = 6;
	ZoneState.bLineBreak = True;
	switch (idx)
	{
		case 15:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Gray"));
		Str = "Ordinary Field";
		ZoneState.t_color.R = 255;
		ZoneState.t_color.G = 255;
		ZoneState.t_color.B = 255;
		ZoneState.t_color.A = 255;
		break;
		case 12:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Blue"));
		Str = "Peace Zone";
		ZoneState.t_color.R = 64;
		ZoneState.t_color.G = 140;
		ZoneState.t_color.B = 255;
		ZoneState.t_color.A = 255;
		break;
		case 11:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Orange"));
		Str = "Siege Warfare Zone";
		ZoneState.t_color.R = 255;
		ZoneState.t_color.G = 114;
		ZoneState.t_color.B = 0;
		ZoneState.t_color.A = 255;
		break;
		case 9:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Green"));
		Str = "Buff Zone";
		ZoneState.t_color.R = 119;
		ZoneState.t_color.G = 255;
		ZoneState.t_color.B = 153;
		ZoneState.t_color.A = 255;
		break;
		case 8:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Red"));
		Str = "Danger Area";
		ZoneState.t_color.R = 178;
		ZoneState.t_color.G = 34;
		ZoneState.t_color.B = 34;
		ZoneState.t_color.A = 255;
		break;
		case 13:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Gray"));
		Str = "SSQ Zone";
		ZoneState.t_color.R = 255;
		ZoneState.t_color.G = 255;
		ZoneState.t_color.B = 255;
		ZoneState.t_color.A = 255;
		break;
		case 14:
		TexZone.SetTexture(StrCat(StrCat("",Radar_Btn_),"Green"));
		Str = "Combat Zone";
		ZoneState.t_color.R = 119;
		ZoneState.t_color.G = 255;
		ZoneState.t_color.B = 153;
		ZoneState.t_color.A = 255;
		break;
		default:
	}
	ZoneState.t_strText = Str;
	param.DrawList[2] = ZoneState;
	TexZone.SetTooltipCustomType(param);
	if ( IntNotEquals(idx,12) )
	{
		Circle.SetWindowSize(32,32);
		Circle.SetTexture("InterfaceTextures.Radar_Circle_Small");
	} else {
		Circle.SetWindowSize(256,256);
		Circle.SetTexture("InterfaceTextures.Radar_Circle_Large");
	}
}

function AdjustMapToPlayerPosition (bool a_ZoomToTownMap)
{
	local Vector param;

	param = GetPlayerPosition();
	Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MinimapWnd_NEW.Minimap",param,a_ZoomToTownMap);
}

function ParsePartyMemberCount (string param)
{
	ParseInt(param,"PartyMemberCount",PartyMemberCount);
}

function HandleMinimapAddTarget (string param)
{
	local Vector paramV;

	if ( LogicalAND(LogicalAND(ParseFloat(param,"X",paramV.X),ParseFloat(param,"Y",paramV.Y)),ParseFloat(param,"Z",paramV.Z)) )
	{
		Class'UIAPI_MINIMAPCTRL'.AddTarget("NPHRN_MinimapWnd_NEW.Minimap",paramV);
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MinimapWnd_NEW.Minimap",paramV,False,False);
	}
}

function HandleMinimapDeleteTarget (string param)
{
	local Vector paramV;
	local int LocX;
	local int LocY;
	local int LocZ;

	if ( LogicalAND(LogicalAND(ParseInt(param,"X",LocX),ParseInt(param,"Y",LocY)),ParseInt(param,"Z",LocZ)) )
	{
		paramV.X = LocX;
		paramV.Y = LocY;
		paramV.Z = LocZ;
		Class'UIAPI_MINIMAPCTRL'.DeleteTarget("NPHRN_MinimapWnd_NEW.Minimap",paramV);
	}
}

function ShowTargetLocation ()
{
	local Vector QuestLocation;

	if ( GetQuestLocation(QuestLocation) )
	{
		FixLocDisable();
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MinimapWnd_NEW.Minimap",QuestLocation);
	}
}

function ShowPartyMemberLocation ()
{
	local Vector PartyMemberLocation;

	PartyMemberCount = GetPartyMemberCount();
	if ( Equals(0,PartyMemberCount) )
	{
		return;
	}
	FixLocDisable();
	i_UnkInt_1 = IntMod(DoAdd(i_UnkInt_1,1),PartyMemberCount);
	if ( GetPartyMemberLocation(i_UnkInt_1,PartyMemberLocation) )
	{
		Class'UIAPI_MINIMAPCTRL'.AdjustMapView("NPHRN_MinimapWnd_NEW.Minimap",PartyMemberLocation,False);
	}
}

function HandleRadarButtonClick ()
{
	SetOptionBool("Custom","RadarTransparency",UnknownFunction129(GetOptionBool("Custom","RadarTransparency")));
	HandleRadarTransparency();
}

function HandleRadarTransparency ()
{
	local ButtonHandle TransparentBtn;

	TransparentBtn = ButtonHandle(GetHandle("NPHRN_MinimapWnd_NEW.BtnTrans"));
	if ( UnknownFunction129(GetOptionBool("Custom","RadarTransparency")) )
	{
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MinimapWnd_NEW.Minimap",255,0.5);
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MinimapWnd_NEW.Circle",255,0.5);
		TransparentBtn.SetTexture("InterfaceTextures.Radar_Btn_Trans","InterfaceTextures.Radar_Btn_Trans_Down","InterfaceTextures.Radar_Btn_Trans_Over");
	} else {
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MinimapWnd_NEW.Minimap",130,0.5);
		Class'UIAPI_WINDOW'.SetAlpha("NPHRN_MinimapWnd_NEW.Circle",130,0.5);
		TransparentBtn.SetTexture("InterfaceTextures.Radar_Btn_Solid","InterfaceTextures.Radar_Btn_Solid_Down","InterfaceTextures.Radar_Btn_Solid_Over");
	}
}

function HandleFixLoc ()
{
	if ( FixedLocation )
	{
		FixLocDisable();
	} else {
		FixLocEnable();
	}
}

function FixLocEnable ()
{
	Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MinimapWnd_NEW.Circle");
	BtnFixLoc.SetTexture("InterfaceTextures.Radar_Btn_FixLoc_Enable","InterfaceTextures.Radar_Btn_FixLoc_Down","InterfaceTextures.Radar_Btn_FixLoc_Enable_Over");
	FixedLocation = True;
}

function FixLocDisable ()
{
	Class'UIAPI_WINDOW'.HideWindow("NPHRN_MinimapWnd_NEW.Circle");
	BtnFixLoc.SetTexture("InterfaceTextures.Radar_Btn_FixLoc","InterfaceTextures.Radar_Btn_FixLoc_Down","InterfaceTextures.Radar_Btn_FixLoc_Over");
	FixedLocation = False;
}

function ResizeWnd ()
{
	local TextureHandle Tex;
	local WindowHandle Minimap;

	Tex = TextureHandle(GetHandle("NPHRN_MinimapWnd_NEW.Tex"));
	Minimap = GetHandle("NPHRN_MinimapWnd_NEW.Minimap");
	if ( NotBool(Large) )
	{
		Me.SetWindowSize(256,256);
		Tex.SetWindowSize(256,256);
		Tex.SetTexture("InterfaceTextures.Radar_Frame_Small");
		NPHRN_MiniMapHandler_NEW.SetWindowSize(224,32);
		Minimap.SetWindowSize(252,252);
		NPHRN_MiniMapHandler_NEW.Move(256,0);
	} else {
		Me.SetWindowSize(512,512);
		Tex.SetWindowSize(512,512);
		Tex.SetTexture("InterfaceTextures.Radar_Frame_Large");
		NPHRN_MiniMapHandler_NEW.SetWindowSize(480,32);
		Minimap.SetWindowSize(508,508);
		NPHRN_MiniMapHandler_NEW.Move(-256,0);
	}
}

function OnLButtonDown (WindowHandle Handle, int X, int Y)
{
	switch (Handle)
	{
		case TexZone:
		if ( BoolEquals(NotBool(Class'UIAPI_WINDOW'.IsShowWindow("NPHRN_MinimapWnd_NEW.Option")),True) )
		{
			Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MinimapWnd_NEW.Option");
		} else {
			Class'UIAPI_WINDOW'.HideWindow("NPHRN_MinimapWnd_NEW.Option");
		}
		default:
	}
}

function HandleMinimap ()
{
	HandleZoneShow(ZoneCode);
}


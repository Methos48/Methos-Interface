//================================================================================
// NPHRN_MiniMapHandler_OLD.
//================================================================================

class NPHRN_MiniMapHandler_OLD extends UICommonAPI;

function OnClickButton (string param)
{
	switch (param)
	{
		case "BtnOpt":
		ToggleOpenCurtain();
		break;
		default:
	}
}

function ToggleOpenCurtain ()
{
	if ( IsShowWindow("NPHRN_MiniMapWnd_OLD.Curtain") )
	{
		Class'UIAPI_WINDOW'.HideWindow("NPHRN_MiniMapWnd_OLD.Curtain");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("NPHRN_MiniMapWnd_OLD.Curtain");
		Class'UIAPI_WINDOW'.SetFocus("NPHRN_MiniMapWnd_OLD.Curtain");
	}
}


//================================================================================
// ShortcutWnd.
//================================================================================

class ShortcutWnd extends UICommonAPI;

var int CurrentShortcutPage;
var int CurrentShortcutPage2;
var int CurrentShortcutPage3;
var int CurrentShortcutPage4;
var int CurrentShortcutPage5;
var bool m_IsLocked;
var bool m_IsVertical;
var bool m_IsJoypad;
var bool m_IsJoypadExpand;
var bool m_IsJoypadOn;
var bool m_IsExpand1;
var bool m_IsExpand2;
var bool m_IsExpand3;
var bool m_IsExpand4;
var bool m_IsShortcutExpand;
var string m_ShortcutWndName;
var WindowHandle Me_Horizontal;
var ButtonHandle btnMove_Horizontal;
var MacroListWnd MacroHandler;
var NPHRN_KeyWnd NPHRN_KeyWnd;
enum EJoyShortcut {
	JOYSHORTCUT_Left,
	JOYSHORTCUT_Center,
	JOYSHORTCUT_Right
};

const MAX_ShortcutPerPage4= 48;
const MAX_ShortcutPerPage3= 36;
const MAX_ShortcutPerPage2= 24;
const MAX_ShortcutPerPage= 12;
const MAX_Page= 10;

function OnRegisterEvent ()
{
	RegisterEvent(630);
	RegisterEvent(640);
	RegisterEvent(660);
	RegisterEvent(650);
	RegisterEvent(690);
	RegisterEvent(590);
	RegisterEvent(600);
	RegisterEvent(610);
	RegisterEvent(620);
	RegisterEvent(150);
}

function OnLoad ()
{
	OnRegisterEvent();
	m_IsLocked = GetOptionBool("Game","IsLockShortcutWnd");
	m_IsExpand1 = GetOptionBool("Game","Is1ExpandShortcutWnd");
	m_IsExpand2 = GetOptionBool("Game","Is2ExpandShortcutWnd");
	m_IsExpand3 = GetOptionBool("Game","Is3ExpandShortcutWnd");
	m_IsExpand4 = GetOptionBool("Game","Is4ExpandShortcutWnd");
	m_IsVertical = GetOptionBool("Game","IsShortcutWndVertical");
	InitShortPageNum();
	ShowWindow("ShortcutWnd.ShortcutWndHorizontal.TooltipMaxBtn");
	HideWindow("ShortcutWnd.ShortcutWndHorizontal.TooltipMinBtn");
	ShowWindow("ShortcutWnd.ShortcutWndVertical.TooltipMaxBtn");
	HideWindow("ShortcutWnd.ShortcutWndVertical.TooltipMinBtn");
	Me_Horizontal = GetHandle("ShortcutWnd.ShortcutWndHorizontal");
	btnMove_Horizontal = ButtonHandle(GetHandle("ShortcutWnd.ShortcutWndHorizontal.btnMove"));
	btnMove_Horizontal.SetTooltipCustomType(MakeTooltipSimpleText("Disable shortcut Move"));
	NPHRN_KeyWnd = NPHRN_KeyWnd(GetScript("NPHRN_KeyWnd"));
	MacroHandler = MacroListWnd(GetScript("MacroListWnd"));
}

function OnDefaultPosition ()
{
	m_IsExpand1 = True;
	m_IsExpand2 = True;
	m_IsExpand3 = False;
	m_IsExpand4 = False;
	SetVertical(False);
	InitShortPageNum();
	ArrangeWnd();
	ExpandWnd();
}

function OnEnterState (name a_PreStateName)
{
	ArrangeWnd();
	ExpandWnd();
	if ( Class'UIAPI_CHECKBOX'.IsChecked("OptionWnd.Cb_HideAutoBuff") )
	{
		Class'UIAPI_WINDOW'.HideWindow("AutoSkillWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("AutoSkillWnd");
	}
	if ( Class'UIAPI_CHECKBOX'.IsChecked("OptionWnd.Cb_HideSkillSpam") )
	{
		Class'UIAPI_WINDOW'.HideWindow("AutoSkillSpamWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("AutoSkillSpamWnd");
	}
	AutoPotionsWndPosition();
	if ( UnknownFunction254(a_PreStateName,'LoadingState') )
	{
		InitShortPageNum();
	}
	if ( GetOptionBool("Custom","ShortcutMovable") )
	{
		btnMove_Horizontal.SetTexture("InterfaceTextures.Savoshortcut_unlock_over","InterfaceTextures.Savoshortcut_unlock","InterfaceTextures.Savoshortcut_unlock_over");
		btnMove_Horizontal.SetTooltipCustomType(MakeTooltipSimpleText("Disable shortcut Move"));
		Me_Horizontal.SetDraggable(True);
	} else {
		btnMove_Horizontal.SetTexture("InterfaceTextures.Savoshortcut_lock_over","InterfaceTextures.Savoshortcut_lock","InterfaceTextures.Savoshortcut_lock_over");
		btnMove_Horizontal.SetTooltipCustomType(MakeTooltipSimpleText("Enable shortcut Move"));
		Me_Horizontal.SetDraggable(False);
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 150:
		break;
		case 640:
		HandleShortcutPageUpdate(a_Param);
		break;
		case 660:
		HandleShortcutJoypad(a_Param);
		break;
		case 590:
		HandleJoypadLButtonDown(a_Param);
		break;
		case 600:
		HandleJoypadLButtonUp(a_Param);
		break;
		case 610:
		HandleJoypadRButtonDown(a_Param);
		break;
		case 620:
		HandleJoypadRButtonUp(a_Param);
		break;
		case 630:
		HandleShortcutUpdate(a_Param);
		break;
		case 650:
		HandleShortcutClear();
		ArrangeWnd();
		ExpandWnd();
		break;
		default:
	}
}

function InitShortPageNum ()
{
	CurrentShortcutPage = 0;
	CurrentShortcutPage2 = 1;
	CurrentShortcutPage3 = 2;
	CurrentShortcutPage4 = 3;
	CurrentShortcutPage5 = 4;
}

function HandleShortcutPageUpdate (string param)
{
	local int i;
	local int nShortcutID;
	local int ShortcutPage;
	local string shortcutName;

	if ( ParseInt(param,"ShortcutPage",ShortcutPage) )
	{
		if ( UnknownFunction132(UnknownFunction151(0,ShortcutPage),UnknownFunction152(10,ShortcutPage)) )
		{
			return;
		}
		CurrentShortcutPage = ShortcutPage;
		NPHRN_KeyWnd.ComboPanel3.SetSelectedNum(CurrentShortcutPage);
		NPHRN_KeyWnd.OnClickButton("BtnApply");
		Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".PageNumTextBox"),string(UnknownFunction146(CurrentShortcutPage,1)));
		nShortcutID = UnknownFunction144(CurrentShortcutPage,12);
		i = 0;
		if ( UnknownFunction150(i,12) )
		{
			Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".Shortcut"),string(UnknownFunction146(i,1))),nShortcutID);
			UnknownFunction165(nShortcutID);
			UnknownFunction163(i);
			goto JL00D4;
		}
	}
}

function HandleShortcutUpdate (string param)
{
	local int nShortcutID;
	local int nShortcutNum;
	local string shortcutWndName;
	local ItemWindowHandle shortcutWndHandle;

	ParseInt(param,"ShortcutID",nShortcutID);
	nShortcutNum = UnknownFunction146(int(UnknownFunction173(nShortcutID,12)),1);
	if ( IsShortcutIDInCurPage(CurrentShortcutPage,nShortcutID) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".Shortcut"),string(nShortcutNum)),nShortcutID);
	}
	if ( IsShortcutIDInCurPage(CurrentShortcutPage2,nShortcutID) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"_1.Shortcut"),string(nShortcutNum)),nShortcutID);
	}
	if ( IsShortcutIDInCurPage(CurrentShortcutPage3,nShortcutID) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"_2.Shortcut"),string(nShortcutNum)),nShortcutID);
	}
	if ( IsShortcutIDInCurPage(CurrentShortcutPage4,nShortcutID) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"_3.Shortcut"),string(nShortcutNum)),nShortcutID);
	}
	if ( IsShortcutIDInCurPage(CurrentShortcutPage5,nShortcutID) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"_4.Shortcut"),string(nShortcutNum)),nShortcutID);
	}
}

function HandleShortcutClear ()
{
	local int i;

	i = 0;
	if ( UnknownFunction150(i,12) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndVertical.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndVertical_1.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndVertical_2.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndHorizontal.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndHorizontal_1.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndHorizontal_2.Shortcut",string(UnknownFunction146(i,1))));
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndJoypadExpand.Shortcut",string(UnknownFunction146(i,1))));
		UnknownFunction163(i);
		goto JL0007;
	}
	i = 0;
	if ( UnknownFunction150(i,4) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.Clear(UnknownFunction112("ShortcutWnd.ShortcutWndJoypad.Shortcut",string(UnknownFunction146(i,1))));
		UnknownFunction163(i);
		goto JL0219;
	}
}

function HandleShortcutJoypad (string a_Param)
{
	local int OnOff;

	if ( ParseInt(a_Param,"OnOff",OnOff) )
	{
		if ( UnknownFunction154(1,OnOff) )
		{
			m_IsJoypadOn = True;
			ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".JoypadBtn"));
		} else {
			if ( UnknownFunction154(0,OnOff) )
			{
				m_IsJoypadOn = False;
				HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".JoypadBtn"));
			}
		}
	}
}

function HandleJoypadLButtonUp (string a_Param)
{
	SetJoypadShortcut(1);
}

function HandleJoypadLButtonDown (string a_Param)
{
	SetJoypadShortcut(0);
}

function HandleJoypadRButtonUp (string a_Param)
{
	SetJoypadShortcut(1);
}

function HandleJoypadRButtonDown (string a_Param)
{
	SetJoypadShortcut(2);
}

function SetJoypadShortcut (EJoyShortcut a_JoyShortcut)
{
	local int i;
	local int nShortcutID;

	switch (a_JoyShortcut)
	{
		case 0:
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","L2UI_CH3.ShortcutWnd.joypad2_back_over1");
		Class'UIAPI_TEXTURECTRL'.SetAnchor("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","ShortcutWnd.ShortcutWndJoypadExpand","TopLeft","TopLeft",28,0);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadLButtonTex","L2UI_ch3.Joypad.joypad_L_HOLD");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadRButtonTex","L2UI_ch3.Joypad.joypad_R");
		nShortcutID = UnknownFunction146(UnknownFunction144(CurrentShortcutPage,12),4);
		i = 0;
		if ( UnknownFunction150(i,4) )
		{
JL01D0:
			Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112("ShortcutWnd.ShortcutWndJoypad.Shortcut",string(UnknownFunction146(i,1))),nShortcutID);
			UnknownFunction165(nShortcutID);
			UnknownFunction163(i);
			goto JL01D0;
		}
		break;
		case 1:
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","L2UI_CH3.ShortcutWnd.joypad2_back_over2");
		Class'UIAPI_TEXTURECTRL'.SetAnchor("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","ShortcutWnd.ShortcutWndJoypadExpand","TopLeft","TopLeft",158,0);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadLButtonTex","L2UI_ch3.Joypad.joypad_L");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadRButtonTex","L2UI_ch3.Joypad.joypad_R");
		nShortcutID = UnknownFunction144(CurrentShortcutPage,12);
		i = 0;
		if ( UnknownFunction150(i,4) )
		{
			Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112("ShortcutWnd.ShortcutWndJoypad.Shortcut",string(UnknownFunction146(i,1))),nShortcutID);
			UnknownFunction165(nShortcutID);
			UnknownFunction163(i);
			goto JL03F8;
		}
		break;
		case 2:
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","L2UI_CH3.ShortcutWnd.joypad2_back_over3");
		Class'UIAPI_TEXTURECTRL'.SetAnchor("ShortcutWnd.ShortcutWndJoypadExpand.JoypadButtonBackTex","ShortcutWnd.ShortcutWndJoypadExpand","TopLeft","TopLeft",288,0);
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadLButtonTex","L2UI_ch3.Joypad.joypad_L");
		Class'UIAPI_TEXTURECTRL'.SetTexture("ShortcutWnd.ShortcutWndJoypad.JoypadRButtonTex","L2UI_ch3.Joypad.joypad_R_HOLD");
		nShortcutID = UnknownFunction146(UnknownFunction144(CurrentShortcutPage,12),8);
		i = 0;
		if ( UnknownFunction150(i,4) )
		{
			Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112("ShortcutWnd.ShortcutWndJoypad.Shortcut",string(UnknownFunction146(i,1))),nShortcutID);
			UnknownFunction165(nShortcutID);
			UnknownFunction163(i);
			goto JL062C;
		}
		break;
		default:
	}
}

function OnClickButton (string a_strID)
{
	switch (a_strID)
	{
		case "PrevBtn":
		OnPrevBtn();
		break;
		case "NextBtn":
		OnNextBtn();
		break;
		case "PrevBtn2":
		OnPrevBtn2();
		break;
		case "NextBtn2":
		OnNextBtn2();
		break;
		case "PrevBtn3":
		OnPrevBtn3();
		break;
		case "PrevBtn4":
		OnPrevBtn4();
		break;
		case "PrevBtn5":
		OnPrevBtn5();
		break;
		case "NextBtn3":
		OnNextBtn3();
		break;
		case "NextBtn4":
		OnNextBtn4();
		break;
		case "NextBtn5":
		OnNextBtn5();
		break;
		case "LockBtn":
		OnClickLockBtn();
		break;
		case "UnlockBtn":
		OnClickUnlockBtn();
		break;
		case "RotateBtn":
		OnRotateBtn();
		break;
		case "JoypadBtn":
		OnJoypadBtn();
		break;
		case "ExpandBtn":
		OnExpandBtn();
		break;
		case "ExpandButton":
		OnClickExpandShortcutButton();
		break;
		case "ReduceButton":
		OnClickExpandShortcutButton();
		break;
		case "btnKeyOption":
		if ( Class'UIAPI_WINDOW'.IsShowWindow("NPHRN_KeyWnd") )
		{
			Class'UIAPI_WINDOW'.HideWindow("NPHRN_KeyWnd");
		} else {
			Class'UIAPI_WINDOW'.ShowWindow("NPHRN_KeyWnd");
		}
		break;
		case "btnMove":
		Me_Horizontal.SetDraggable(UnknownFunction129(Me_Horizontal.IsDraggable()));
		if ( Me_Horizontal.IsDraggable() )
		{
			btnMove_Horizontal.SetTexture("InterfaceTextures.Savoshortcut_unlock_over","InterfaceTextures.Savoshortcut_unlock","InterfaceTextures.Savoshortcut_unlock_over");
			btnMove_Horizontal.SetTooltipCustomType(MakeTooltipSimpleText("Disable shortcut Move"));
			SetOptionBool("Custom","ShortcutMovable",True);
		} else {
			btnMove_Horizontal.SetTexture("InterfaceTextures.Savoshortcut_lock_over","InterfaceTextures.Savoshortcut_lock","InterfaceTextures.Savoshortcut_lock_over");
			btnMove_Horizontal.SetTooltipCustomType(MakeTooltipSimpleText("Enable shortcut Move"));
			SetOptionBool("Custom","ShortcutMovable",False);
		}
		break;
		default:
	}
}

function OnPrevBtn ()
{
	local int nNewPage;

	nNewPage = UnknownFunction147(CurrentShortcutPage,1);
	if ( UnknownFunction151(0,nNewPage) )
	{
		nNewPage = UnknownFunction147(10,1);
	}
	SetCurPage(nNewPage);
}

function OnPrevBtn2 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction147(CurrentShortcutPage2,1);
	if ( UnknownFunction151(0,nNewPage) )
	{
		nNewPage = UnknownFunction147(10,1);
	}
	SetCurPage2(nNewPage);
}

function OnPrevBtn3 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction147(CurrentShortcutPage3,1);
	if ( UnknownFunction151(0,nNewPage) )
	{
		nNewPage = UnknownFunction147(10,1);
	}
	SetCurPage3(nNewPage);
}

function OnNextBtn ()
{
	local int nNewPage;

	nNewPage = UnknownFunction146(CurrentShortcutPage,1);
	if ( UnknownFunction152(10,nNewPage) )
	{
		nNewPage = 0;
	}
	SetCurPage(nNewPage);
}

function OnNextBtn2 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction146(CurrentShortcutPage2,1);
	if ( UnknownFunction152(10,nNewPage) )
	{
		nNewPage = 0;
	}
	SetCurPage2(nNewPage);
}

function OnNextBtn3 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction146(CurrentShortcutPage3,1);
	if ( UnknownFunction152(10,nNewPage) )
	{
		nNewPage = 0;
	}
	SetCurPage3(nNewPage);
}

function OnPrevBtn4 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction147(CurrentShortcutPage4,1);
	if ( UnknownFunction151(0,nNewPage) )
	{
		nNewPage = UnknownFunction147(10,1);
	}
	SetCurPage4(nNewPage);
}

function OnNextBtn4 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction146(CurrentShortcutPage4,1);
	if ( UnknownFunction152(10,nNewPage) )
	{
		nNewPage = 0;
	}
	SetCurPage4(nNewPage);
}

function OnPrevBtn5 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction147(CurrentShortcutPage5,1);
	if ( UnknownFunction151(0,nNewPage) )
	{
		nNewPage = UnknownFunction147(10,1);
	}
	SetCurPage5(nNewPage);
}

function OnNextBtn5 ()
{
	local int nNewPage;

	nNewPage = UnknownFunction146(CurrentShortcutPage5,1);
	if ( UnknownFunction152(10,nNewPage) )
	{
		nNewPage = 0;
	}
	SetCurPage5(nNewPage);
}

function OnClickLockBtn ()
{
	UnLock();
}

function OnClickUnlockBtn ()
{
	Lock();
}

function OnRotateBtn ()
{
	SetVertical(UnknownFunction129(m_IsVertical));
	if ( m_IsVertical )
	{
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndVertical","ShortcutWnd.ShortcutWndHorizontal","BottomRight","BottomRight",0,0);
		Class'UIAPI_WINDOW'.ClearAnchor("ShortcutWnd.ShortcutWndVertical");
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndHorizontal","ShortcutWnd.ShortcutWndVertical","BottomRight","BottomRight",0,0);
	} else {
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndHorizontal","ShortcutWnd.ShortcutWndVertical","BottomRight","BottomRight",0,0);
		Class'UIAPI_WINDOW'.ClearAnchor("ShortcutWnd.ShortcutWndHorizontal");
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndVertical","ShortcutWnd.ShortcutWndHorizontal","BottomRight","BottomRight",0,0);
	}
	if ( UnknownFunction242(m_IsExpand4,True) )
	{
		Expand1();
		Expand2();
		Expand3();
		Expand4();
	}
	if ( UnknownFunction242(m_IsExpand3,True) )
	{
		Expand1();
		Expand2();
		Expand3();
	}
	if ( UnknownFunction242(m_IsExpand2,True) )
	{
		Expand1();
		Expand2();
	}
	if ( UnknownFunction242(m_IsExpand1,True) )
	{
		Expand1();
	}
	Class'UIAPI_WINDOW'.SetFocus(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName));
	AutoPotionsWndPosition();
}

function OnJoypadBtn ()
{
	SetJoypad(UnknownFunction129(m_IsJoypad));
	Class'UIAPI_WINDOW'.SetFocus(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName));
}

function OnExpandBtn ()
{
	SetJoypadExpand(UnknownFunction129(m_IsJoypadExpand));
	Class'UIAPI_WINDOW'.SetFocus(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName));
}

function SetCurPage (int a_nCurPage)
{
	if ( UnknownFunction132(UnknownFunction151(0,a_nCurPage),UnknownFunction152(10,a_nCurPage)) )
	{
		return;
	}
	Class'ShortcutAPI'.SetShortcutPage(a_nCurPage);
}

function SetCurPage2 (int a_nCurPage)
{
	local int i;
	local int nShortcutID;

	if ( UnknownFunction132(UnknownFunction151(0,a_nCurPage),UnknownFunction152(10,a_nCurPage)) )
	{
		return;
	}
	CurrentShortcutPage2 = a_nCurPage;
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1"),".PageNumTextBox"),string(UnknownFunction146(CurrentShortcutPage2,1)));
	nShortcutID = UnknownFunction144(CurrentShortcutPage2,12);
	NPHRN_KeyWnd.ComboPanel1.SetSelectedNum(CurrentShortcutPage2);
	NPHRN_KeyWnd.OnClickButton("BtnApply");
	i = 0;
	if ( UnknownFunction150(i,12) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1"),".Shortcut"),string(UnknownFunction146(i,1))),nShortcutID);
		UnknownFunction165(nShortcutID);
		UnknownFunction163(i);
		goto JL00C5;
	}
}

function SetCurPage3 (int a_nCurPage)
{
	local int i;
	local int nShortcutID;

	if ( UnknownFunction132(UnknownFunction151(0,a_nCurPage),UnknownFunction152(10,a_nCurPage)) )
	{
		return;
	}
	CurrentShortcutPage3 = a_nCurPage;
	NPHRN_KeyWnd.ComboPanel2.SetSelectedNum(CurrentShortcutPage3);
	NPHRN_KeyWnd.OnClickButton("BtnApply");
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_2"),".PageNumTextBox"),string(UnknownFunction146(CurrentShortcutPage3,1)));
	nShortcutID = UnknownFunction144(CurrentShortcutPage3,12);
	i = 0;
	if ( UnknownFunction150(i,12) )
	{
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_2"),".Shortcut"),string(UnknownFunction146(i,1))),nShortcutID);
		UnknownFunction165(nShortcutID);
		UnknownFunction163(i);
		goto JL00D3;
	}
}

function SetCurPage4 (int a_nCurPage)
{
	local int i;
	local int nShortcutID;

	if ( UnknownFunction132(UnknownFunction151(0,a_nCurPage),UnknownFunction152(10,a_nCurPage)) )
	{
		return;
	}
	CurrentShortcutPage4 = a_nCurPage;
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_3"),".PageNumTextBox"),string(UnknownFunction146(CurrentShortcutPage4,1)));
	nShortcutID = UnknownFunction144(CurrentShortcutPage4,12);
	i = 0;
	if ( UnknownFunction150(i,12) )
	{
		Debug(UnknownFunction168(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_3"),".Shortcut"),string(UnknownFunction146(i,1))),string(nShortcutID)));
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_3"),".Shortcut"),string(UnknownFunction146(i,1))),nShortcutID);
		UnknownFunction165(nShortcutID);
		UnknownFunction163(i);
		goto JL009D;
	}
}

function SetCurPage5 (int a_nCurPage)
{
	local int i;
	local int nShortcutID;

	if ( UnknownFunction132(UnknownFunction151(0,a_nCurPage),UnknownFunction152(10,a_nCurPage)) )
	{
		return;
	}
	CurrentShortcutPage5 = a_nCurPage;
	Class'UIAPI_TEXTBOX'.SetText(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_4"),".PageNumTextBox"),string(UnknownFunction146(CurrentShortcutPage5,1)));
	nShortcutID = UnknownFunction144(CurrentShortcutPage5,12);
	i = 0;
	if ( UnknownFunction150(i,12) )
	{
		Debug(UnknownFunction168(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_4"),".Shortcut"),string(UnknownFunction146(i,1))),string(nShortcutID)));
		Class'UIAPI_SHORTCUTITEMWINDOW'.UpdateShortcut(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),"."),m_ShortcutWndName),"_1."),m_ShortcutWndName),"_4"),".Shortcut"),string(UnknownFunction146(i,1))),nShortcutID);
		UnknownFunction165(nShortcutID);
		UnknownFunction163(i);
		goto JL009D;
	}
}

function bool IsShortcutIDInCurPage (int PageNum, int a_nShortcutID)
{
	if ( UnknownFunction151(UnknownFunction144(PageNum,12),a_nShortcutID) )
	{
		return False;
	}
	if ( UnknownFunction152(UnknownFunction144(UnknownFunction146(PageNum,1),12),a_nShortcutID) )
	{
		return False;
	}
	return True;
}

function Lock ()
{
	m_IsLocked = True;
	SetOptionBool("Game","IsLockShortcutWnd",True);
	ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".LockBtn"));
	HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".UnlockBtn"));
}

function UnLock ()
{
	m_IsLocked = False;
	SetOptionBool("Game","IsLockShortcutWnd",False);
	ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".UnlockBtn"));
	HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".LockBtn"));
}

function SetVertical (bool a_IsVertical)
{
	m_IsVertical = a_IsVertical;
	SetOptionBool("Game","IsShortcutWndVertical",m_IsVertical);
	ArrangeWnd();
	ExpandWnd();
}

function SetJoypad (bool a_IsJoypad)
{
	m_IsJoypad = a_IsJoypad;
	ArrangeWnd();
}

function SetJoypadExpand (bool a_IsJoypadExpand)
{
	m_IsJoypadExpand = a_IsJoypadExpand;
	if ( m_IsJoypadExpand )
	{
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndJoypadExpand","ShortcutWnd.ShortcutWndJoypad","TopLeft","TopLeft",0,0);
		Class'UIAPI_WINDOW'.ClearAnchor("ShortcutWnd.ShortcutWndJoypadExpand");
	} else {
		Class'UIAPI_WINDOW'.SetAnchor("ShortcutWnd.ShortcutWndJoypad","ShortcutWnd.ShortcutWndJoypadExpand","TopLeft","TopLeft",0,0);
		Class'UIAPI_WINDOW'.ClearAnchor("ShortcutWnd.ShortcutWndJoypad");
	}
	ArrangeWnd();
}

function ArrangeWnd ()
{
	local Rect WindowRect;

	if ( m_IsJoypad )
	{
		HideWindow("ShortcutWnd.ShortcutWndVertical");
		HideWindow("ShortcutWnd.ShortcutWndHorizontal");
		if ( m_IsJoypadExpand )
		{
			HideWindow("ShortcutWnd.ShortcutWndJoypad");
			ShowWindow("ShortcutWnd.ShortcutWndJoypadExpand");
			m_ShortcutWndName = "ShortcutWndJoypadExpand";
		} else {
			HideWindow("ShortcutWnd.ShortcutWndJoypadExpand");
			ShowWindow("ShortcutWnd.ShortcutWndJoypad");
			m_ShortcutWndName = "ShortcutWndJoypad";
		}
	} else {
		HideWindow("ShortcutWnd.ShortcutWndJoypadExpand");
		HideWindow("ShortcutWnd.ShortcutWndJoypad");
		if ( m_IsVertical )
		{
			m_ShortcutWndName = "ShortcutWndVertical";
			WindowRect = Class'UIAPI_WINDOW'.GetRect("ShortcutWnd.ShortcutWndVertical");
			if ( UnknownFunction150(WindowRect.nY,0) )
			{
				Class'UIAPI_WINDOW'.MoveTo("ShortcutWnd.ShortcutWndVertical",WindowRect.nX,0);
			}
			HideWindow("ShortcutWnd.ShortcutWndHorizontal");
			ShowWindow("ShortcutWnd.ShortcutWndVertical");
		} else {
			m_ShortcutWndName = "ShortcutWndHorizontal";
			WindowRect = Class'UIAPI_WINDOW'.GetRect("ShortcutWnd.ShortcutWndHorizontal");
			if ( UnknownFunction150(WindowRect.nX,0) )
			{
				Class'UIAPI_WINDOW'.MoveTo("ShortcutWnd.ShortcutWndHorizontal",0,WindowRect.nY);
			}
			HideWindow("ShortcutWnd.ShortcutWndVertical");
			ShowWindow("ShortcutWnd.ShortcutWndHorizontal");
		}
		if ( m_IsJoypadOn )
		{
			ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".JoypadBtn"));
		} else {
			HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".JoypadBtn"));
		}
	}
	if ( m_IsLocked )
	{
		Lock();
	} else {
		UnLock();
	}
	SetCurPage(CurrentShortcutPage);
	SetCurPage2(CurrentShortcutPage2);
	SetCurPage3(CurrentShortcutPage3);
	SetCurPage4(CurrentShortcutPage4);
	SetCurPage5(CurrentShortcutPage5);
	if ( UnknownFunction242(m_IsExpand1,True) )
	{
		m_IsShortcutExpand = True;
		HandleExpandButton();
	} else {
		if ( UnknownFunction242(m_IsExpand2,True) )
		{
			m_IsShortcutExpand = True;
			HandleExpandButton();
		} else {
			if ( UnknownFunction242(m_IsExpand3,True) )
			{
				m_IsShortcutExpand = True;
				HandleExpandButton();
			} else {
				if ( UnknownFunction242(m_IsExpand4,True) )
				{
					m_IsShortcutExpand = False;
					HandleExpandButton();
				} else {
					m_IsShortcutExpand = True;
					HandleExpandButton();
				}
			}
		}
	}
}

function ExpandWnd ()
{
	if ( UnknownFunction132(UnknownFunction132(UnknownFunction132(UnknownFunction242(m_IsExpand1,True),UnknownFunction242(m_IsExpand2,True)),UnknownFunction242(m_IsExpand3,True)),UnknownFunction242(m_IsExpand4,True)) )
	{
		if ( UnknownFunction242(m_IsExpand4,True) )
		{
			m_IsShortcutExpand = False;
			Expand4();
		}
		if ( UnknownFunction242(m_IsExpand3,True) )
		{
			m_IsShortcutExpand = False;
			Expand3();
		}
		if ( UnknownFunction242(m_IsExpand2,True) )
		{
			m_IsShortcutExpand = False;
			Expand2();
		}
		if ( UnknownFunction242(m_IsExpand1,True) )
		{
			m_IsShortcutExpand = False;
			Expand1();
		}
	} else {
		m_IsShortcutExpand = True;
		Reduce();
	}
}

function Expand1 ()
{
	m_IsShortcutExpand = True;
	m_IsExpand1 = True;
	SetOptionBool("Game","Is1ExpandShortcutWnd",m_IsExpand1);
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndVertical_1");
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndHorizontal_1");
	HandleExpandButton();
}

function Expand2 ()
{
	m_IsShortcutExpand = True;
	m_IsExpand2 = True;
	SetOptionBool("Game","Is2ExpandShortcutWnd",m_IsExpand2);
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndVertical_2");
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndHorizontal_2");
	HandleExpandButton();
}

function Expand3 ()
{
	m_IsShortcutExpand = True;
	m_IsExpand3 = True;
	SetOptionBool("Game","Is3ExpandShortcutWnd",m_IsExpand3);
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndVertical_3");
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndHorizontal_3");
	HandleExpandButton();
}

function Expand4 ()
{
	m_IsShortcutExpand = False;
	m_IsExpand4 = True;
	SetOptionBool("Game","Is4ExpandShortcutWnd",m_IsExpand4);
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndVertical_4");
	Class'UIAPI_WINDOW'.ShowWindow("ShortcutWnd.ShortcutWndHorizontal_4");
	HandleExpandButton();
}

function Reduce ()
{
	m_IsShortcutExpand = True;
	m_IsExpand1 = False;
	m_IsExpand2 = False;
	m_IsExpand3 = False;
	m_IsExpand4 = False;
	SetOptionBool("Game","Is1ExpandShortcutWnd",m_IsExpand1);
	SetOptionBool("Game","Is2ExpandShortcutWnd",m_IsExpand2);
	SetOptionBool("Game","Is3ExpandShortcutWnd",m_IsExpand3);
	SetOptionBool("Game","Is4ExpandShortcutWnd",m_IsExpand4);
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndVertical_1");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndVertical_2");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndVertical_3");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndVertical_4");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndHorizontal_1");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndHorizontal_2");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndHorizontal_3");
	Class'UIAPI_WINDOW'.HideWindow("ShortcutWnd.ShortcutWndHorizontal_4");
	HandleExpandButton();
}

function OnClickExpandShortcutButton ()
{
	if ( m_IsExpand4 )
	{
		Reduce();
	} else {
		if ( m_IsExpand3 )
		{
			Expand4();
		} else {
			if ( m_IsExpand2 )
			{
				Expand3();
			} else {
				if ( m_IsExpand1 )
				{
					Expand2();
				} else {
					Expand1();
				}
			}
		}
	}
	AutoPotionsWndPosition();
}

function HandleExpandButton ()
{
	if ( m_IsShortcutExpand )
	{
		ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".ExpandButton"));
		HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".ReduceButton"));
	} else {
		HideWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".ExpandButton"));
		ShowWindow(UnknownFunction112(UnknownFunction112("ShortcutWnd.",m_ShortcutWndName),".ReduceButton"));
	}
}

function AutoPotionsWndPosition ()
{
	if ( UnknownFunction129(m_IsVertical) )
	{
		if ( IsShowWindow("ShortcutWndHorizontal_4") )
		{
			Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ShortcutWnd.ShortcutWndHorizontal_4","TopRight","TopRight",-1,-29);
			Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ShortcutWnd.ShortcutWndHorizontal_4","TopLeft","TopLeft",33,-29);
			if ( GetOptionBool("Custom","HideAutoBuff") )
			{
				Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ShortcutWnd.ShortcutWndHorizontal_4","TopLeft","TopLeft",33,-29);
			} else {
				Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
			}
		} else {
			if ( IsShowWindow("ShortcutWndHorizontal_3") )
			{
				Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ShortcutWnd.ShortcutWndHorizontal_3","TopRight","TopRight",-1,-29);
				Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ShortcutWnd.ShortcutWndHorizontal_3","TopLeft","TopLeft",33,-29);
				if ( GetOptionBool("Custom","HideAutoBuff") )
				{
					Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ShortcutWnd.ShortcutWndHorizontal_3","TopLeft","TopLeft",33,-29);
				} else {
					Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
				}
			} else {
				if ( IsShowWindow("ShortcutWndHorizontal_2") )
				{
					Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ShortcutWnd.ShortcutWndHorizontal_2","TopRight","TopRight",-1,-29);
					Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ShortcutWnd.ShortcutWndHorizontal_2","TopLeft","TopLeft",33,-29);
					if ( GetOptionBool("Custom","HideAutoBuff") )
					{
						Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ShortcutWnd.ShortcutWndHorizontal_2","TopLeft","TopLeft",33,-29);
					} else {
						Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
					}
				} else {
					if ( IsShowWindow("ShortcutWndHorizontal_1") )
					{
						Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ShortcutWnd.ShortcutWndHorizontal_1","TopRight","TopRight",-1,-29);
						Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ShortcutWnd.ShortcutWndHorizontal_1","TopLeft","TopLeft",33,-29);
						if ( GetOptionBool("Custom","HideAutoBuff") )
						{
							Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ShortcutWnd.ShortcutWndHorizontal_1","TopLeft","TopLeft",33,-29);
						} else {
							Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
						}
					} else {
						if ( IsShowWindow("ShortcutWndHorizontal") )
						{
							Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ShortcutWnd.ShortcutWndHorizontal","TopRight","TopRight",-1,-29);
							Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ShortcutWnd.ShortcutWndHorizontal","TopLeft","TopLeft",33,-29);
							if ( GetOptionBool("Custom","HideAutoBuff") )
							{
								Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ShortcutWnd.ShortcutWndHorizontal","TopLeft","TopLeft",33,-29);
							} else {
								Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
							}
						}
					}
				}
			}
		}
	} else {
		Class'UIAPI_WINDOW'.SetAnchor("AutoPotionsWnd","ElfenMenu","TopRight","TopRight",-5,-29);
		Class'UIAPI_WINDOW'.SetAnchor("AutoSkillWnd","ElfenMenu","TopRight","TopRight",-210,-29);
		if ( GetOptionBool("Custom","HideAutoBuff") )
		{
			Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","ElfenMenu","TopRight","TopRight",-210,-29);
		} else {
			Class'UIAPI_WINDOW'.SetAnchor("AutoSkillSpamWnd","AutoSkillWnd","TopLeft","TopLeft",0,-30);
		}
	}
}

function OnLButtonDown (WindowHandle WindowHandle, int X, int Y)
{
	local string WindowName;
	local string parentWindowName;
	local string windowNumber;
	local string shortcutNumber;

	WindowName = WindowHandle.GetWindowName();
	parentWindowName = WindowHandle.GetParentWindowName();
	if ( UnknownFunction132(UnknownFunction129(StartsWith("Shortcut",WindowName)),UnknownFunction129(StartsWith("ShortcutWnd",parentWindowName))) )
	{
		return;
	}
	shortcutNumber = UnknownFunction127(WindowName,8,2);
	windowNumber = Class'UIAPI_TEXTBOX'.GetText(UnknownFunction112(parentWindowName,".PageNumTextBox"));
	MacroHandler.HandleInventoryMacro(UnknownFunction112(UnknownFunction112(windowNumber," "),shortcutNumber));
}


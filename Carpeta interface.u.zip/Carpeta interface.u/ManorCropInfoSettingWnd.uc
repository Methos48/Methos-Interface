//================================================================================
// ManorCropInfoSettingWnd.
//================================================================================

class ManorCropInfoSettingWnd extends UICommonAPI;

const DIALOG_ID_SETTODAY=888;
const DIALOG_ID_STOP=777;
const COLUMN_CNT=12;
const REWARD_TYPE_2=11;
const REWARD_TYPE_1=10;
const CROP_LELEL=9;
const MAX_CROP_PRICE=8;
const MIN_CROP_PRICE=7;
const NEXT_PROCURE_TYPE=6;
const NEXT_CROP_PRICE=5;
const NEXT_CROP_TOTAL_CNT=4;
const TODAY_PROCURE_TYPE=3;
const TODAY_CROP_PRICE=2;
const TODAY_CROP_TOTOAL_CNT=1;
const CROP_NAME=0;
var int m_ManorID;
var int m_SumOfDefaultPrice;

function OnLoad ()
{
	RegisterEvent(2665);
	RegisterEvent(2666);
	RegisterEvent(2667);
	RegisterEvent(2668);
	RegisterEvent(1710);
	m_ManorID = -1;
	m_SumOfDefaultPrice = 0;
}

function OnEvent (int Event_ID, string a_Param)
{
	switch (Event_ID)
	{
		case 2665:
		HandleShow(a_Param);
		break;
		case 2666:
		HandleAddItem(a_Param);
		break;
		case 2667:
		CalculateSumOfDefaultPrice();
		ShowWindowWithFocus("ManorCropInfoSettingWnd");
		break;
		case 2668:
		HandleChangeValue(a_Param);
		break;
		case 1710:
		HandleDialogOK();
		break;
		default:
	}
}

function HandleDialogOK ()
{
	local int dialogID;

	if ( UnknownFunction129(DialogIsMine()) )
	{
		return;
	}
	dialogID = DialogGetID();
	switch (dialogID)
	{
		case 777:
		HandleStop();
		break;
		case 888:
		HandleSetToday();
		break;
		default:
	}
}

function HandleStop ()
{
	local int i;
	local int RecordCnt;
	local LVDataRecord Record;
	local LVDataRecord recordClear;

	RecordCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	i = 0;
	if ( UnknownFunction150(i,RecordCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i);
		Record.LVDataList[4].szData = "0";
		Record.LVDataList[5].szData = "0";
		Record.LVDataList[6].szData = "0";
		Class'UIAPI_LISTCTRL'.ModifyRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i,Record);
		UnknownFunction163(i);
		goto JL0052;
	}
	CalculateSumOfDefaultPrice();
}

function HandleSetToday ()
{
	local int i;
	local int RecordCnt;
	local LVDataRecord Record;
	local LVDataRecord recordClear;

	RecordCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	i = 0;
	if ( UnknownFunction150(i,RecordCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i);
		Record.LVDataList[4].szData = Record.LVDataList[1].szData;
		Record.LVDataList[5].szData = Record.LVDataList[2].szData;
		Record.LVDataList[6].szData = Record.LVDataList[3].szData;
		Class'UIAPI_LISTCTRL'.ModifyRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i,Record);
		UnknownFunction163(i);
		goto JL0052;
	}
	CalculateSumOfDefaultPrice();
}

function HandleShow (string a_Param)
{
	local int ManorID;
	local string ManorName;

	ParseInt(a_Param,"ManorID",ManorID);
	ParseString(a_Param,"ManorName",ManorName);
	m_ManorID = ManorID;
	Class'UIAPI_TEXTBOX'.SetText("ManorCropInfoSettingWnd.txtManorName",ManorName);
	DeleteAll();
}

function DeleteAll ()
{
	Class'UIAPI_LISTCTRL'.DeleteAllItem("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
}

function OnDBClickListCtrlRecord (string strID)
{
	switch (strID)
	{
		case "ManorCropInfoSettingListCtrl":
		OnChangeBtn();
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	Debug(UnknownFunction112(" ",strID));
	switch (strID)
	{
		case "btnChangeSell":
		OnChangeBtn();
		break;
		case "btnSetToday":
		DialogSetID(888);
		DialogShow(4,GetSystemMessage(1601));
		break;
		case "btnStop":
		DialogSetID(777);
		DialogShow(4,GetSystemMessage(1600));
		break;
		case "btnOk":
		OnOk();
		HideWindow("ManorCropInfoSettingWnd");
		break;
		case "btnCancel":
		HideWindow("ManorCropInfoSettingWnd");
		break;
		default:
	}
}

function OnOk ()
{
	local int RecordCount;
	local LVDataRecord Record;
	local LVDataRecord recordClear;
	local int i;
	local string param;

	RecordCount = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	ParamAdd(param,"ManorID",string(m_ManorID));
	ParamAdd(param,"CropCnt",string(RecordCount));
	i = 0;
	if ( UnknownFunction150(i,RecordCount) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i);
		ParamAdd(param,UnknownFunction112("CropID",string(i)),string(Record.nReserved1));
		ParamAdd(param,UnknownFunction112("BuyCnt",string(i)),Record.LVDataList[4].szData);
		ParamAdd(param,UnknownFunction112("Price",string(i)),Record.LVDataList[5].szData);
		ParamAdd(param,UnknownFunction112("ProcureType",string(i)),Record.LVDataList[6].szData);
		UnknownFunction163(i);
		goto JL0088;
	}
	RequestSetCrop(param);
}

function HandleAddItem (string a_Param)
{
	local LVDataRecord Record;
	local int CropID;
	local string CropName;
	local int TodayCropTotalCnt;
	local int TodayCropPrice;
	local int TodayProcureType;
	local int NextCropTotalCnt;
	local int NextCropPrice;
	local int NextProcureType;
	local int MinCropPrice;
	local int MaxCropPrice;
	local int CropLevel;
	local string RewardType1;
	local string RewardType2;
	local int MaxCropTotalCnt;
	local int DefaultCropPrice;

	ParseInt(a_Param,"CropID",CropID);
	ParseString(a_Param,"CropName",CropName);
	ParseInt(a_Param,"TodayCropTotalCnt",TodayCropTotalCnt);
	ParseInt(a_Param,"TodayCropPrice",TodayCropPrice);
	ParseInt(a_Param,"TodayProcureType",TodayProcureType);
	ParseInt(a_Param,"NextCropTotalCnt",NextCropTotalCnt);
	ParseInt(a_Param,"NextCropPrice",NextCropPrice);
	ParseInt(a_Param,"NextProcureType",NextProcureType);
	ParseInt(a_Param,"MinCropPrice",MinCropPrice);
	ParseInt(a_Param,"MaxCropPrice",MaxCropPrice);
	ParseInt(a_Param,"CropLevel",CropLevel);
	ParseString(a_Param,"RewardType1",RewardType1);
	ParseString(a_Param,"RewardType2",RewardType2);
	ParseInt(a_Param,"MaxCropTotalCnt",MaxCropTotalCnt);
	ParseInt(a_Param,"DefaultCropPrice",DefaultCropPrice);
	Record.LVDataList.Length = 12;
	Record.LVDataList[0].szData = CropName;
	Record.LVDataList[1].szData = string(TodayCropTotalCnt);
	Record.LVDataList[2].szData = string(TodayCropPrice);
	Record.LVDataList[3].szData = string(TodayProcureType);
	Record.LVDataList[4].szData = string(NextCropTotalCnt);
	Record.LVDataList[5].szData = string(NextCropPrice);
	Record.LVDataList[6].szData = string(NextProcureType);
	Record.LVDataList[7].szData = string(MinCropPrice);
	Record.LVDataList[8].szData = string(MaxCropPrice);
	Record.LVDataList[9].szData = string(CropLevel);
	Record.LVDataList[10].szData = RewardType1;
	Record.LVDataList[11].szData = RewardType2;
	Record.nReserved1 = CropID;
	Record.nReserved2 = MaxCropTotalCnt;
	Record.nReserved3 = DefaultCropPrice;
	Class'UIAPI_LISTCTRL'.InsertRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",Record);
}

function CalculateSumOfDefaultPrice ()
{
	local LVDataRecord Record;
	local LVDataRecord recordClear;
	local int ItemCnt;
	local int i;
	local int tmpMulti;
	local string adenaString;

	m_SumOfDefaultPrice = 0;
	ItemCnt = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	i = 0;
	if ( UnknownFunction150(i,ItemCnt) )
	{
		Record = recordClear;
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",i);
		tmpMulti = UnknownFunction144(int(Record.LVDataList[5].szData),int(Record.LVDataList[4].szData));
		UnknownFunction161(m_SumOfDefaultPrice,tmpMulti);
		UnknownFunction163(i);
		goto JL0059;
	}
	adenaString = MakeCostString(string(m_SumOfDefaultPrice));
	Class'UIAPI_TEXTBOX'.SetText("ManorCropInfoSettingWnd.txtVarNextTotalExpense",adenaString);
}

function OnChangeBtn ()
{
	local LVDataRecord Record;
	local string param;

	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	ParamAdd(param,"CropName",Record.LVDataList[0].szData);
	ParamAdd(param,"TomorrowVolumeOfBuy",Record.LVDataList[4].szData);
	ParamAdd(param,"TomorrowLimit",string(Record.nReserved2));
	ParamAdd(param,"TomorrowPrice",Record.LVDataList[5].szData);
	ParamAdd(param,"TomorrowProcure",Record.LVDataList[6].szData);
	ParamAdd(param,"MinCropPrice",Record.LVDataList[7].szData);
	ParamAdd(param,"MaxCropPrice",Record.LVDataList[8].szData);
	ExecuteEvent(2670,param);
}

function HandleChangeValue (string a_Param)
{
	local int TomorrowAmountOfPurchase;
	local int TomorrowPurchasePrice;
	local int TomorrowProcure;
	local LVDataRecord Record;
	local int SelectedIndex;

	ParseInt(a_Param,"TomorrowAmountOfPurchase",TomorrowAmountOfPurchase);
	ParseInt(a_Param,"TomorrowPurchasePrice",TomorrowPurchasePrice);
	ParseInt(a_Param,"TomorrowProcure",TomorrowProcure);
	SelectedIndex = Class'UIAPI_LISTCTRL'.GetSelectedIndex("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl");
	Record.LVDataList[4].szData = string(TomorrowAmountOfPurchase);
	Record.LVDataList[5].szData = string(TomorrowPurchasePrice);
	Record.LVDataList[6].szData = string(TomorrowProcure);
	Class'UIAPI_LISTCTRL'.ModifyRecord("ManorCropInfoSettingWnd.ManorCropInfoSettingListCtrl",SelectedIndex,Record);
	CalculateSumOfDefaultPrice();
}


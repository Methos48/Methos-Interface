//================================================================================
// SelectDeliverWnd.
//================================================================================

class SelectDeliverWnd extends UICommonAPI;

function OnLoad ()
{
	RegisterEvent(2140);
	RegisterEvent(2150);
}

function OnEvent (int Event_ID, string param)
{
	switch (Event_ID)
	{
		case 2140:
		Class'UIAPI_COMBOBOX'.Clear("SelectDeliverWnd.SelectDeliverCombo");
		ShowWindow("SelectDeliverWnd");
		Class'UIAPI_WINDOW'.SetFocus("SelectDeliverWnd");
		break;
		case 2150:
		HandleAddName(param);
		break;
		default:
		break;
	}
}

function HandleAddName (string param)
{
	local string Name;
	local int Id;

	ParseString(param,"name",Name);
	ParseInt(param,"id",Id);
	Class'UIAPI_COMBOBOX'.AddStringWithReserved("SelectDeliverWnd.SelectDeliverCombo",Name,Id);
}

function OnClickButton (string ControlName)
{
	if ( UnknownFunction122(ControlName,"OKButton") )
	{
		HandleOKButtonClick();
	} else {
		if ( UnknownFunction122(ControlName,"CancelButton") )
		{
			HideWindow("SelectDeliverWnd");
		}
	}
}

function HandleOKButtonClick ()
{
	local int selected;
	local int reservedID;

	selected = Class'UIAPI_COMBOBOX'.GetSelectedNum("SelectDeliverWnd.SelectDeliverCombo");
	if ( UnknownFunction153(selected,0) )
	{
		reservedID = Class'UIAPI_COMBOBOX'.GetReserved("SelectDeliverWnd.SelectDeliverCombo",selected);
		RequestPackageSendableItemList(reservedID);
	}
	HideWindow("SelectDeliverWnd");
}


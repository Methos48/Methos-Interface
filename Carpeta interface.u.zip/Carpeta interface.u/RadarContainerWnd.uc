//================================================================================
// RadarContainerWnd.
//================================================================================

class RadarContainerWnd extends UICommonAPI;

function OnLoad ()
{
	RegisterEvent(1730);
	RegisterEvent(1740);
	RegisterEvent(1750);
	RegisterEvent(11223344);
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 1730:
		HandleRadarAddTarget(a_Param);
		break;
		case 1740:
		HandleRadarDeleteTarget(a_Param);
		break;
		case 1750:
		HandleRadarDeleteAllTarget();
		break;
		case 11223344:
		HandleRadarShowHide();
		break;
		default:
	}
}

function HandleRadarShowHide ()
{
	local int idx;

	idx = GetOptionInt("Custom","Minimap");
	switch (idx)
	{
		case 0:
		Class'UIAPI_WINDOW'.HideWindow("RadarContainerWnd.Radar");
		break;
		case 1:
		Class'UIAPI_WINDOW'.ShowWindow("RadarContainerWnd.Radar");
		break;
		case 2:
		Class'UIAPI_WINDOW'.HideWindow("RadarContainerWnd.Radar");
		break;
		case 3:
		Class'UIAPI_WINDOW'.HideWindow("RadarContainerWnd.Radar");
		break;
		default:
	}
}

function HandleRadarAddTarget (string a_Param)
{
	local int X;
	local int Y;
	local int Z;

	if ( UnknownFunction130(UnknownFunction130(ParseInt(a_Param,"X",X),ParseInt(a_Param,"Y",Y)),ParseInt(a_Param,"Z",Z)) )
	{
		Class'UIAPI_RADAR'.AddTarget("RadarContainterWnd.Radar",X,Y,Z);
	}
}

function HandleRadarDeleteTarget (string a_Param)
{
	local int X;
	local int Y;
	local int Z;

	if ( UnknownFunction130(UnknownFunction130(ParseInt(a_Param,"X",X),ParseInt(a_Param,"Y",Y)),ParseInt(a_Param,"Z",Z)) )
	{
		Class'UIAPI_RADAR'.DeleteTarget("RadarContainterWnd.Radar",X,Y,Z);
	}
}

function HandleRadarDeleteAllTarget ()
{
	Class'UIAPI_RADAR'.DeleteAllTarget("RadarContainterWnd.Radar");
}

function OnClickButton (string a_strID)
{
	switch (a_strID)
	{
		case "RadarBtn":
		if ( Class'UIAPI_WINDOW'.IsShowWindow("RadarWnd") )
		{
			Class'UIAPI_WINDOW'.HideWindow("RadarWnd");
		} else {
			Class'UIAPI_WINDOW'.ShowWindow("RadarWnd");
		}
		break;
		default:
	}
}


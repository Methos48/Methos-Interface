//================================================================================
// ActionWnd.
//================================================================================

class ActionWnd extends UICommonAPI;

var bool m_bShow;

function OnLoad ()
{
	RegisterEvent(1300);
	RegisterEvent(1310);
	RegisterEvent(1900);
	m_bShow = False;
	HideScrollBar();
}

function OnShow ()
{
	Class'ActionAPI'.RequestActionList();
	m_bShow = True;
	SetFocus();
}

function OnHide ()
{
	m_bShow = False;
}

function OnEvent (int Event_ID, string param)
{
	if ( Equals(Event_ID,1300) )
	{
		HandleActionListStart();
	} else {
		if ( Equals(Event_ID,1310) )
		{
			HandleActionList(param);
		} else {
			if ( Equals(Event_ID,1900) )
			{
				HandleLanguageChanged();
			}
		}
	}
}

function OnClickItem (string strID, int Index)
{
	local ItemInfo infItem;

	if ( UnknownFunction130(UnknownFunction122(strID,"ActionBasicItem"),UnknownFunction151(Index,-1)) )
	{
		if ( UnknownFunction129(Class'UIAPI_ITEMWINDOW'.GetItem("ActionWnd.ActionBasicItem",Index,infItem)) )
		{
			return;
		}
	} else {
		if ( UnknownFunction130(UnknownFunction122(strID,"ActionPartyItem"),UnknownFunction151(Index,-1)) )
		{
			if ( UnknownFunction129(Class'UIAPI_ITEMWINDOW'.GetItem("ActionWnd.ActionPartyItem",Index,infItem)) )
			{
				return;
			}
		} else {
			if ( UnknownFunction130(UnknownFunction122(strID,"ActionSocialItem"),UnknownFunction151(Index,-1)) )
			{
				if ( UnknownFunction129(Class'UIAPI_ITEMWINDOW'.GetItem("ActionWnd.ActionSocialItem",Index,infItem)) )
				{
					return;
				}
			}
		}
	}
	DoAction(infItem.ClassID);
}

function OnClickButton (string strID)
{
	if ( StrEquals(strID,"BtnClose") )
	{
		HideWindow("ActionWnd");
	}
}

function HideScrollBar ()
{
	Class'UIAPI_ITEMWINDOW'.ShowScrollBar("ActionWnd.ActionBasicItem",False);
	Class'UIAPI_ITEMWINDOW'.ShowScrollBar("ActionWnd.ActionPartyItem",False);
	Class'UIAPI_ITEMWINDOW'.ShowScrollBar("ActionWnd.ActionSocialItem",False);
}

function HandleLanguageChanged ()
{
	Class'ActionAPI'.RequestActionList();
}

function HandleActionListStart ()
{
	Clear();
}

function Clear ()
{
	Class'UIAPI_ITEMWINDOW'.Clear("ActionWnd.ActionBasicItem");
	Class'UIAPI_ITEMWINDOW'.Clear("ActionWnd.ActionPartyItem");
	Class'UIAPI_ITEMWINDOW'.Clear("ActionWnd.ActionSocialItem");
}

function HandleActionList (string param)
{
	local string WndName;
	local int tmp;
	local EActionCategory Type;
	local int ActionID;
	local string strActionName;
	local string strIconName;
	local string strDescription;
	local string strCommand;
	local ItemInfo infItem;

	ParseInt(param,"Type",tmp);
	ParseInt(param,"ActionID",ActionID);
	ParseString(param,"Name",strActionName);
	ParseString(param,"IconName",strIconName);
	ParseString(param,"Description",strDescription);
	ParseString(param,"Command",strCommand);
	infItem.ClassID = ActionID;
	infItem.Name = strActionName;
	infItem.IconName = strIconName;
	infItem.Description = strDescription;
	infItem.ItemSubType = 3;
	infItem.MacroCommand = strCommand;
	Type = tmp;
	if ( UnknownFunction154(Type,1) )
	{
		WndName = "ActionBasicItem";
	} else {
		if ( UnknownFunction154(Type,2) )
		{
			WndName = "ActionPartyItem";
		} else {
			if ( UnknownFunction154(Type,3) )
			{
				WndName = "ActionSocialItem";
			} else {
				return;
			}
		}
	}
	Class'UIAPI_ITEMWINDOW'.AddItem(UnknownFunction112("ActionWnd.",WndName),infItem);
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.ActionBasicItem");
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.ActionPartyItem");
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.ActionSocialItem");
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.txtBasic1");
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.txtBasic2");
	Class'UIAPI_WINDOW'.SetFocus("ActionWnd.txtBasic3");
}


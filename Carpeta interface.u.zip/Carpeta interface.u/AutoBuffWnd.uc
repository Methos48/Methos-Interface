//================================================================================
// AutoBuffWnd.
//================================================================================

class AutoBuffWnd extends UICommonAPI;

var string m_WindowName;
var WindowHandle Me;
var string BuffParam;
var array<BuffInfo> buffInfoArr_1;
var array<BuffInfo> buffInfoArr_2;
var bool b_UnkBool1;
var bool b_UnkBool2;
var bool b_UnkBool3;
var ItemWindowHandle BItemWnd;
var ItemWindowHandle TItemWnd;
var int targetID;
var int PlayerID;
var bool b_UnkBool4;
const SKILL_TIMER= 4448;
const SKILL_TIMER_DELAY= 1000;
const NOBL_TIMER= 4452;
const SPIRIT_ORE= 3031;

function OnLoad ()
{
	RegisterEvent(1280);
	RegisterEvent(1290);
	RegisterEvent(950);
	RegisterEvent(980);
	RegisterEvent(90);
	RegisterEvent(190);
	RegisterEvent(40);
	Me = GetHandle("AutoBuffWnd");
	BItemWnd = ItemWindowHandle(GetHandle(StrCat(m_WindowName,".BItemWnd")));
	TItemWnd = ItemWindowHandle(GetHandle(StrCat(m_WindowName,".TItemWnd")));
	PlayerID = Class'UIDATA_PLAYER'.GetPlayerID();
	Me.SetWindowTitle("Auto Buff");
}

function OnShow ()
{
	RequestSkillList();
}

function HandleShortcutCommand (string param)
{
	local string Command;

	if ( ParseString(param,"Command",Command) )
	{
		switch (Command)
		{
			case "ToggleOpenAutoBuffWnd":
			ToggleOpenAutoBuffWnd();
			break;
			default:
		}
	}
}

function OnEvent (int Index, string param)
{
	switch (Index)
	{
		case 1280:
		HandleSkillListStart();
		break;
		case 1290:
		HandleSkillList(param);
		break;
		case 950:
		HandleAddNormalStatus(param);
		BuffParam = param;
		break;
		case 980:
		TargetUpdate();
		break;
		case 90:
		HandleShortcutCommand(param);
		break;
		case 190:
		HandleUpdateHP(param);
		break;
		case 40:
		Me.KillTimer(4448);
		break;
		default:
	}
}

function ToggleOpenAutoBuffWnd ()
{
	if ( IsShowWindow("AutoBuffWnd") )
	{
		HideWindow("AutoBuffWnd");
		PlaySound("InterfaceSound.charstat_close_01");
	} else {
		ShowWindowWithFocus("AutoBuffWnd");
		PlaySound("InterfaceSound.charstat_open_01");
	}
}

function OnClickItem (string param, int Index)
{
	LooksLikeEnableDisableAutoBuff(param,Index);
}

function OnRClickItem (string param, int Index)
{
	LooksLikeEnableDisableAutoBuff(param,Index);
}

function LooksLikeEnableDisableAutoBuff (string param, int Index)
{
	local ItemInfo Info;

	if ( GreaterThan(Index,-1) )
	{
		if ( StrEquals(param,"TItemWnd") )
		{
			if ( TItemWnd.GetItem(Index,Info) )
			{
				if ( StrEquals(Info.ForeTexture,"") )
				{
					if ( MaybeSkillValid(Info.ClassID) )
					{
						UnknownFunction_4(Info);
						Info.ForeTexture = "InterfaceTextures.Auto";
						TItemWnd.SetItem(Index,Info);
					}
				} else {
					UnknownFunction_5(Info.ClassID);
					Info.ForeTexture = "";
					TItemWnd.SetItem(Index,Info);
				}
			}
		} else {
			if ( StrEquals(param,"BItemWnd") )
			{
				if ( BItemWnd.GetItem(Index,Info) )
				{
					if ( StrEquals(Info.ForeTexture,"") )
					{
						if ( MaybeSkillValid(Info.ClassID) )
						{
							if ( Equals(Info.ClassID,1323) )
							{
								b_UnkBool2 = True;
								TargetUpdate();
							} else {
								UnknownFunction_1(Info);
							}
							Info.ForeTexture = "InterfaceTextures.Auto";
							BItemWnd.SetItem(Index,Info);
						}
					} else {
						if ( Equals(Info.ClassID,1323) )
						{
							b_UnkBool2 = False;
						} else {
							UnknownFunction_2(Info.ClassID);
						}
						Info.ForeTexture = "";
						BItemWnd.SetItem(Index,Info);
					}
				}
			}
		}
		Me.KillTimer(4448);
		if ( LogicalOR(LogicalOR(GreaterThan(buffInfoArr_1.Length,0),GreaterThan(buffInfoArr_2.Length,0)),b_UnkBool2) )
		{
			HandleAddNormalStatus(BuffParam);
			Me.SetTimer(4448,1000);
		}
	}
}

function bool MaybeSkillValid (int SkillID)
{
	return GreaterThan(Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("MagicSkillWnd.ASkill.SkillItem",SkillID),-1);
}

function UnknownFunction_4 (ItemInfo Info)
{
	buffInfoArr_1.Length = DoAdd(buffInfoArr_1.Length,1);
	buffInfoArr_1[IntSub(buffInfoArr_1.Length,1)].Id = Info.ClassID;
	buffInfoArr_1[IntSub(buffInfoArr_1.Length,1)].BuffInfo_Bool = False;
	buffInfoArr_1[IntSub(buffInfoArr_1.Length,1)].BuffInfo_Int = UnkFuncSomeID_1(Info.ClassID);
	buffInfoArr_1[IntSub(buffInfoArr_1.Length,1)].Name = Info.Name;
}

function UnknownFunction_5 (int Id)
{
	local int i;

	i = 0;
	if ( LessThan(i,buffInfoArr_1.Length) )
	{
		if ( Equals(buffInfoArr_1[i].Id,Id) )
		{
			buffInfoArr_1[i] = buffInfoArr_1[IntSub(buffInfoArr_1.Length,1)];
			buffInfoArr_1.Length = IntSub(buffInfoArr_1.Length,1);
		} else {
			IntIncrement(i);
			goto JL0007;
		}
	}
}

function UnknownFunction_1 (ItemInfo Info)
{
	buffInfoArr_2.Length = DoAdd(buffInfoArr_2.Length,1);
	buffInfoArr_2[IntSub(buffInfoArr_2.Length,1)].Id = Info.ClassID;
	buffInfoArr_2[IntSub(buffInfoArr_2.Length,1)].BuffInfo_Bool = False;
	buffInfoArr_2[IntSub(buffInfoArr_2.Length,1)].BuffInfo_Int = UnkFuncSomeID_1(Info.ClassID);
	buffInfoArr_2[IntSub(buffInfoArr_2.Length,1)].Name = Info.Name;
}

function UnknownFunction_2 (int Id)
{
	local int i;

	i = 0;
	if ( LessThan(i,buffInfoArr_2.Length) )
	{
		if ( Equals(buffInfoArr_2[i].Id,Id) )
		{
			buffInfoArr_2[i] = buffInfoArr_2[IntSub(buffInfoArr_2.Length,1)];
			buffInfoArr_2.Length = IntSub(buffInfoArr_2.Length,1);
		} else {
			IntIncrement(i);
			goto JL0007;
		}
	}
}

function OnTimer (int Index)
{
	local int i;

	if ( Equals(Index,4448) )
	{
		if ( LogicalAND(b_UnkBool2,NotBool(b_UnkBool1)) )
		{
			if ( Equals(targetID,PlayerID) )
			{
				isCanUseNoblesse();
			} else {
				RequestSelfTarget();
			}
		}
		i = 0;
		if ( LessThan(i,buffInfoArr_1.Length) )
		{
			if ( NotBool(buffInfoArr_1[i].BuffInfo_Bool) )
			{
				if ( GreaterThan(buffInfoArr_1[i].BuffInfo_Int,-1) )
				{
					if ( Equals(buffInfoArr_1[i].BuffInfo_Int,getWeaponType()) )
					{
						TryUseSkill(buffInfoArr_1[i].Id);
					} else {
						ChatSystemMsg(StrCat(StrCat("Cannot use ",buffInfoArr_1[i].Name),". Change Weapon!"),GetColor("Amber"));
					}
				} else {
					if ( Equals(buffInfoArr_1[i].Id,337) )
					{
						if ( GreaterThan(getUserHP(),150) )
						{
							TryUseSkill(buffInfoArr_1[i].Id);
						}
					} else {
						TryUseSkill(buffInfoArr_1[i].Id);
					}
				}
			}
			IntIncrement(i);
			goto JL0057;
		}
		i = 0;
		if ( LessThan(i,buffInfoArr_2.Length) )
		{
			if ( NotBool(buffInfoArr_2[i].BuffInfo_Bool) )
			{
				if ( UnknownFunction_3() )
				{
					if ( GreaterThan(buffInfoArr_2[i].BuffInfo_Int,-1) )
					{
						if ( Equals(buffInfoArr_2[i].BuffInfo_Int,getWeaponType()) )
						{
							TryUseSkill(buffInfoArr_2[i].Id);
						} else {
							ChatSystemMsg(StrCat(StrCat("[AI SKILLS] Cannot use ",buffInfoArr_2[i].Name),". Change Weapon!"),GetColor("Amber"));
						}
					} else {
						TryUseSkill(buffInfoArr_2[i].Id);
					}
				}
			}
			IntIncrement(i);
			goto JL019F;
		}
	}
}

function HandleAddNormalStatus (string param)
{
	local int i;
	local int j;
	local int Max;
	local int ClassID;
	local bool localBool;

	b_UnkBool3 = False;
	ParseInt(param,"Max",Max);
	i = 0;
	if ( LessThan(i,Max) )
	{
		b_UnkBool1 = False;
		ParseInt(param,StrCat("SkillID_",string(i)),ClassID);
		if ( NoblesseCele(ClassID) )
		{
			b_UnkBool1 = True;
		} else {
			if ( isInvincible(ClassID) )
			{
				b_UnkBool3 = True;
			}
			IntIncrement(i);
			goto JL0024;
		}
	}
	i = 0;
	if ( LessThan(i,buffInfoArr_1.Length) )
	{
		localBool = False;
		j = IntSub(Max,1);
		if ( IntGreaterOrEqual(j,0) )
		{
			ParseInt(param,StrCat("SkillID_",string(j)),ClassID);
			if ( Equals(buffInfoArr_1[i].Id,ClassID) )
			{
				buffInfoArr_1[i].BuffInfo_Bool = True;
				localBool = True;
			} else {
				IntDec(j);
				goto JL00D8;
			}
		}
		if ( NotBool(localBool) )
		{
			buffInfoArr_1[i].BuffInfo_Bool = False;
		}
		IntIncrement(i);
		goto JL00AA;
	}
	i = 0;
	if ( LessThan(i,buffInfoArr_2.Length) )
	{
		localBool = False;
		j = 0;
		if ( LessThan(j,Max) )
		{
			ParseInt(param,StrCat("SkillID_",string(j)),ClassID);
			if ( Equals(buffInfoArr_2[i].Id,ClassID) )
			{
				buffInfoArr_2[i].BuffInfo_Bool = True;
				localBool = True;
			} else {
				IntIncrement(j);
				goto JL01B2;
			}
		}
		if ( NotBool(localBool) )
		{
			buffInfoArr_2[i].BuffInfo_Bool = False;
		}
		IntIncrement(i);
		goto JL018F;
	}
}

function TargetUpdate ()
{
	if ( b_UnkBool2 )
	{
		PlayerID = Class'UIDATA_PLAYER'.GetPlayerID();
		targetID = Class'UIDATA_TARGET'.GetTargetID();
		if ( NotBool(b_UnkBool1) )
		{
			if ( Equals(PlayerID,targetID) )
			{
				isCanUseNoblesse();
			}
		}
	}
}

function isCanUseNoblesse ()
{
	if ( IntGreaterOrEqual(getItemCount(3031),5) )
	{
		TryUseSkill(1323);
	} else {
		ChatSystemMsg("[AI SKILLS] Cannot use Noblesse Blessing. Missing SPIRIT ORES",GetColor("Amber"));
	}
}

function HandleUpdateHP (string param)
{
	local int ServerID;

	if ( b_UnkBool2 )
	{
		ParseInt(param,"ServerID",ServerID);
		if ( Equals(ServerID,PlayerID) )
		{
			if ( UnknownFunction130(b_UnkBool4,isNotUserDead()) )
			{
				RequestSelfTarget();
				b_UnkBool4 = False;
			}
			if ( isNotUserDead() )
			{
				b_UnkBool4 = False;
			} else {
				b_UnkBool4 = True;
			}
		}
	}
}

function HandleSkillListStart ()
{
	Clear();
}

function Clear ()
{
	BItemWnd.Clear();
	TItemWnd.Clear();
}

function HandleSkillList (string param)
{
	local int SkillID;
	local int SkillLevel;
	local int Lock;
	local string IconName;
	local string strSkillName;
	local string Description;
	local string strEnchantName;
	local string strCommand;
	local int i;
	local ItemInfo Info;

	ParseInt(param,"ClassID",SkillID);
	ParseInt(param,"Level",SkillLevel);
	ParseInt(param,"Lock",Lock);
	ParseString(param,"Name",strSkillName);
	ParseString(param,"IconName",IconName);
	ParseString(param,"Description",Description);
	ParseString(param,"EnchantName",strEnchantName);
	ParseString(param,"Command",strCommand);
	Info.ClassID = SkillID;
	Info.Level = SkillLevel;
	Info.Name = strSkillName;
	Info.AdditionalName = strEnchantName;
	Info.IconName = IconName;
	Info.Description = Description;
	Info.ItemSubType = 2;
	Info.MacroCommand = strCommand;
	if ( GreaterThan(Lock,0) )
	{
		Info.bIsLock = True;
	} else {
		Info.bIsLock = False;
	}
	Info.ForeTexture = "";
	if ( UnknownFunction_6(SkillID) )
	{
		i = 0;
		if ( LessThan(i,buffInfoArr_1.Length) )
		{
			if ( Equals(buffInfoArr_1[i].Id,SkillID) )
			{
				Info.ForeTexture = "InterfaceTextures.Auto";
			} else {
				IntIncrement(i);
				goto JL0194;
			}
		}
		TItemWnd.AddItem(Info);
	} else {
		if ( LogicalOR(UnknownFunction_7(SkillID),UnknownFunction_8(SkillID)) )
		{
			if ( Equals(SkillID,1323) )
			{
				if ( b_UnkBool2 )
				{
					Info.ForeTexture = "InterfaceTextures.Auto";
				}
			} else {
				i = 0;
				if ( LessThan(i,buffInfoArr_2.Length) )
				{
					if ( Equals(buffInfoArr_2[i].Id,SkillID) )
					{
						Info.ForeTexture = "InterfaceTextures.Auto";
					} else {
						IntIncrement(i);
						goto JL0279;
					}
				}
			}
			BItemWnd.AddItem(Info);
			if ( Equals(SkillID,1323) )
			{
				BItemWnd.SwapItems(0,IntSub(BItemWnd.GetItemNum(),1));
			}
		}
	}
}

function bool UnknownFunction_3 ()
{
	if ( NotBool(b_UnkBool3) )
	{
		return True;
	}
	return False;
}

function bool UnknownFunction_8 (int ClassID)
{
	switch (ClassID)
	{
		case 264:
		case 265:
		case 266:
		case 267:
		case 268:
		case 269:
		case 270:
		case 271:
		case 272:
		case 273:
		case 274:
		case 275:
		case 276:
		case 277:
		case 304:
		case 305:
		case 306:
		case 307:
		case 308:
		case 309:
		case 310:
		case 311:
		case 349:
		case 363:
		case 364:
		case 365:
		case 366:
		return True;
		default:
	}
	return False;
}

function bool UnknownFunction_6 (int ClassID)
{
	switch (ClassID)
	{
		case 196:
		case 197:
		case 221:
		case 222:
		case 256:
		case 288:
		case 312:
		case 318:
		case 322:
		case 334:
		case 335:
		case 336:
		case 337:
		case 338:
		case 339:
		case 340:
		case 422:
		case 424:
		case 1001:
		case 1262:
		case 1283:
		case 4476:
		return True;
		break;
		default:
		return False;
		break;
	}
}

function bool UnknownFunction_7 (int ClassID)
{
	switch (ClassID)
	{
		case 1323:
		case 78:
		case 82:
		case 94:
		case 99:
		case 112:
		case 130:
		case 297:
		case 317:
		case 357:
		case 356:
		case 355:
		case 413:
		case 414:
		case 410:
		case 415:
		case 416:
		case 421:
		case 423:
		case 1003:
		case 1008:
		case 1005:
		case 1004:
		case 1249:
		case 1250:
		case 1260:
		case 1261:
		case 1282:
		case 1307:
		case 1364:
		case 1365:
		return True;
		break;
		default:
		return False;
		break;
	}
}

function int UnkFuncSomeID_1 (int SkillID)
{
	switch (SkillID)
	{
		case 357:
		case 356:
		case 355:
		case 410:
		return 3;
		break;
		case 317:
		case 421:
		return 4;
		break;
		case 271:
		case 272:
		case 273:
		case 274:
		case 275:
		case 276:
		case 277:
		case 309:
		case 310:
		case 311:
		case 307:
		case 365:
		return 8;
		break;
		case 222:
		return 5;
		default:
		return -1;
	}
}

function bool isNotUserDead ()
{
	if ( GreaterThan(getUserHP(),0) )
	{
		return True;
	} else {
		return False;
	}
}

function int getUserHP ()
{
	local UserInfo Info;

	if ( GetPlayerInfo(Info) )
	{
		return Info.nCurHP;
	}
	return 0;
}

function int getItemCount (int ItemID)
{
	local int i;
	local int idx;
	local int resultInt;
	local ItemInfo Info;
	local ItemInfo info2;

	idx = Class'UIAPI_ITEMWINDOW'.GetItemNum("InventoryWnd.InventoryItem");
	i = Class'UIAPI_ITEMWINDOW'.FindItemWithClassID("InventoryWnd.InventoryItem",ItemID);
	if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",i,Info) )
	{
		if ( Equals(Info.ItemNum,1) )
		{
			i = 0;
			if ( IntLessOrEqual(i,idx) )
			{
				if ( Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.InventoryItem",i,info2) )
				{
					if ( Equals(info2.ClassID,ItemID) )
					{
						IntIncrement(resultInt);
					}
				}
				IntPreIncrement(i);
				goto JL00BA;
			}
		} else {
			if ( Equals(Info.ItemNum,0) )
			{
				resultInt = 0;
			} else {
				resultInt = Info.ItemNum;
			}
		}
	}
	return resultInt;
}

function TryUseSkill (int SkillID)
{
	if ( isNotUserDead() )
	{
		UseSkill(SkillID);
	}
}

function ChatSystemMsg (string param, Color Color)
{
	if ( GetOptionBool("Game","SystemMsgWnd") )
	{
		Class'UIAPI_TEXTLISTBOX'.AddString("SystemMsgWnd.SystemMsgList",param,Color);
	} else {
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.NormalChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.TradeChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.PartyChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.ClanChat",param,Color);
		Class'UIAPI_TEXTLISTBOX'.AddString("ChatWnd.AllyChat",param,Color);
	}
}

function Color GetColor (string Colors)
{
	local Color RGB;

	RGB.A = 255;
	switch (Colors)
	{
		case "Yellow":
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 0;
		break;
		case "System":
		RGB.R = 176;
		RGB.G = 155;
		RGB.B = 121;
		break;
		case "Amber":
		RGB.R = 218;
		RGB.G = 165;
		RGB.B = 32;
		break;
		case "White":
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 255;
		break;
		case "Dim":
		RGB.R = 177;
		RGB.G = 173;
		RGB.B = 172;
		break;
		case "Magenta":
		RGB.R = 255;
		RGB.G = 0;
		RGB.B = 255;
		break;
		default:
		RGB.R = 255;
		RGB.G = 255;
		RGB.B = 255;
		break;
	}
	return RGB;
}

function bool NoblesseCele (int SkillID)
{
	switch (SkillID)
	{
		case 1323:
		case 408:
		case 1418:
		return True;
		default:
	}
	return False;
}

function bool isInvincible (int ClassID)
{
	switch (ClassID)
	{
		case 1418:
		case 1427:
		return True;
		break;
		default:
	}
	return False;
}

function ItemInfo GetWeapon ()
{
	local ItemInfo Info;

	Class'UIAPI_ITEMWINDOW'.GetItem("InventoryWnd.EquipItem_RHand",0,Info);
	return Info;
}

function int getWeaponType ()
{
	return GetWeapon().WeaponType;
}

defaultproperties
{
    m_WindowName="AutoBuffWnd"

}

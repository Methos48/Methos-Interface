//================================================================================
// StatusWnd.
//================================================================================

class StatusWnd extends UIScript;

var int m_UserID;
var bool m_bReceivedUserInfo;

function OnLoad ()
{
	RegisterEvent(70);
	RegisterEvent(180);
	RegisterEvent(190);
	RegisterEvent(200);
	RegisterEvent(210);
	RegisterEvent(220);
	RegisterEvent(230);
	RegisterEvent(240);
}

function OnEnterState (name a_PreStateName)
{
	m_bReceivedUserInfo = False;
	UpdateUserInfo();
}

function UpdateUserInfo ()
{
	local UserInfo UserInfo;

	if ( GetPlayerInfo(UserInfo) )
	{
		m_bReceivedUserInfo = True;
		m_UserID = UserInfo.nID;
		Class'UIAPI_STATUSBARCTRL'.SetPoint("StatusWnd.CPBar",UserInfo.nCurCP,UserInfo.nMaxCP);
		Class'UIAPI_STATUSBARCTRL'.SetPoint("StatusWnd.HPBar",UserInfo.nCurHP,UserInfo.nMaxHP);
		Class'UIAPI_STATUSBARCTRL'.SetPoint("StatusWnd.MPBar",UserInfo.nCurMP,UserInfo.nMaxMP);
		Class'UIAPI_NAMECTRL'.SetName("StatusWnd.UserName",UnknownFunction112(UserInfo.Name," OKTUBRE      "),0,1);
		Class'UIAPI_TEXTBOX'.SetInt("StatusWnd.StatusWnd_LevelTextBox",UserInfo.nLevel);
	}
}

function OnLButtonDown (WindowHandle a_WindowHandle, int X, int Y)
{
	local Rect rectWnd;

	rectWnd = Class'UIAPI_WINDOW'.GetRect("StatusWnd");
	if ( UnknownFunction130(UnknownFunction151(X,UnknownFunction146(rectWnd.nX,13)),UnknownFunction150(X,UnknownFunction147(UnknownFunction146(rectWnd.nX,rectWnd.nWidth),10))) )
	{
		RequestSelfTarget();
	}
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 180:
		UpdateUserInfo();
		break;
		case 200:
		HandleUpdateInfo(a_Param);
		break;
		case 210:
		HandleUpdateInfo(a_Param);
		break;
		case 220:
		HandleUpdateInfo(a_Param);
		break;
		case 230:
		HandleUpdateInfo(a_Param);
		break;
		case 240:
		HandleUpdateInfo(a_Param);
		break;
		case 70:
		HandleRegenStatus(a_Param);
		break;
		default:
		break;
	}
}

function HandleUpdateInfo (string param)
{
	local int ServerID;

	ParseInt(param,"ServerID",ServerID);
	if ( UnknownFunction132(UnknownFunction154(m_UserID,ServerID),UnknownFunction129(m_bReceivedUserInfo)) )
	{
		UpdateUserInfo();
	}
}

function HandleRegenStatus (string a_Param)
{
	local int Type;
	local int Duration;
	local int ticks;
	local float amount;

	ParseInt(a_Param,"Type",Type);
	if ( UnknownFunction154(Type,1) )
	{
		ParseInt(a_Param,"Duration",Duration);
		ParseInt(a_Param,"Ticks",ticks);
		ParseFloat(a_Param,"Amount",amount);
		Class'UIAPI_STATUSBARCTRL'.SetRegenInfo("StatusWnd.HPBar",Duration,ticks,amount);
	}
}


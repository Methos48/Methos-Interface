//================================================================================
// MacroListWnd.
//================================================================================

class MacroListWnd extends UICommonAPI;

const MACRO_MAX_COUNT= 24;
var WindowHandle WndHandle;
var bool m_bShow;
var int m_DeleteID;
var int m_Max;
var ItemWindowHandle ItemWindowHandle;
var array<int> arrInt1;
var array<int> arrInt2;
var array<string> arrStr;
var int unkInt1;
var int unkInt2;
var int unkInt3;
var int unkInt4;
var int unkInt5;
var int unkInt6;
var int curMacroShortcutId;
var string unkStr1;
var string unkStr2;
var string unkStr3;
var string unkStr4;
var string unkStr5;
var MacroEditWnd MacroEditWnd;
var array<MacroShortcut> macroShortcuts;

function OnLoad ()
{
	unkStr2 = "MacroListWnd";
	WndHandle = GetHandle(unkStr2);
	ItemWindowHandle = ItemWindowHandle(GetHandle(StrCat(unkStr2,".MacroItem")));
	MacroEditWnd = MacroEditWnd(GetScript("MacroEditWnd"));
	RegisterEvent(1710);
	RegisterEvent(1230);
	RegisterEvent(1240);
	RegisterEvent(1250);
	m_bShow = False;
	m_DeleteID = 0;
	Init();
}

function Init ()
{
	unkStr3 = "L2ui.Macro_Icon";
	unkStr4 = "l2_skilltime.ToggleEffect001";
	unkStr5 = "";
	unkStr1 = StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("/",lowerDigitNumber(13)),""),lowerDigitNumber(3)),""),lowerDigitNumber(19)),""),lowerDigitNumber(11)),""),lowerDigitNumber(6)),"");
	unkInt2 = int(StrCat(StrCat(StrCat(StrCat("",lowerDigitNumber(27)),""),lowerDigitNumber(28)),""));
	unkInt3 = int(lowerDigitNumber(33));
	unkInt5 = int(lowerDigitNumber(27));
	unkInt4 = int(lowerDigitNumber(36));
	unkInt6 = int(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat(StrCat("",lowerDigitNumber(27)),""),lowerDigitNumber(36)),""),lowerDigitNumber(36)),""),lowerDigitNumber(36)),""));
}

function OnEnterState (name a_PreStateName)
{
	Class'MacroAPI'.RequestMacroList();
}

function OnShow ()
{
	m_bShow = True;
	SetFocus();
}

function OnHide ()
{
	m_bShow = False;
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnHelp":
		OnClickHelp();
		break;
		case "BtnAdd":
		OnClickAdd();
		break;
		case "BtnClose":
		WndHandle.HideWindow();
		break;
		default:
	}
}

function OnEvent (int Event_ID, string param)
{
	if ( Equals(Event_ID,1230) )
	{
		HandleMacroShowListWnd();
	} else {
		if ( Equals(Event_ID,1240) )
		{
			reqMacroList();
		} else {
			if ( Equals(Event_ID,1250) )
			{
				HandleMacroList(param);
			} else {
				if ( Equals(Event_ID,1710) )
				{
					if ( DialogIsMine() )
					{
						if ( GreaterThan(m_DeleteID,unkInt4) )
						{
							Class'MacroAPI'.RequestDeleteMacro(m_DeleteID);
							m_DeleteID = unkInt4;
							if ( Equals(m_Max,unkInt5) )
							{
								HandleMacroList(unkStr5);
							}
						}
					}
				}
			}
		}
	}
}

function OnClickItem (string strID, int Index)
{
	local ItemInfo ItemInfo;

	if ( LogicalAND(StrEquals(strID,"MacroItem"),GreaterThan(Index,-1)) )
	{
		if ( ItemWindowHandle.GetItem(Index,ItemInfo) )
		{
			AutoSkillWnd(GetScript("AutoSkillWnd")).(ItemInfo.ClassID);
		}
	}
}

function OnRClickItem (string strID, int unkLocInt2)
{
	local ItemInfo ItemInfo;
	local MacroInfo MacroInfo;
	local int idx;

	if ( LogicalAND(StrEquals(strID,"MacroItem"),GreaterThan(unkLocInt2,-1)) )
	{
		unkFunc();
		if ( ItemWindowHandle.GetItem(unkLocInt2,ItemInfo) )
		{
			if ( Equals(ItemInfo.ClassID,unkInt1) )
			{
				unkInt1 = unkInt4;
				reqMacroList();
				return;
			}
			unkInt1 = ItemInfo.ClassID;
			if ( Class'UIDATA_MACRO'.GetMacroInfo(ItemInfo.ClassID,MacroInfo) )
			{
				idx = unkInt4;
				if ( LessThan(idx,unkInt2) )
				{
					if ( StrNotEquals2(StrLeft(MacroInfo.CommandList[idx],IntSub(unkInt3,unkInt5)),unkStr1) )
					{
						arrInt1[idx] = idx;
						arrInt2[idx] = int(StrRight(MacroInfo.CommandList[idx],IntSub(StrLen(MacroInfo.CommandList[idx]),unkInt3)));
					} else {
						arrStr[idx] = MacroInfo.CommandList[idx];
					}
					IntIncrement(idx);
					goto JL00B8;
				}
			}
		}
	}
	WndHandle.SetTimer(unkInt4,IntDiv(unkInt6,4));
	reqMacroList();
}

function OnClickHelp ()
{
	local string strParam;

	ParamAdd(strParam,"FilePath","..L2texthelp_macro.htm");
	ExecuteEvent(1210,strParam);
}

function OnClickAdd ()
{
	MacroEditWnd.m_bShow = False;
	Class'UIAPI_MULTIEDITBOX'.SetString("MacroInfoWnd.txtInfo","");
	ExecuteEvent(1260,"");
}

function reqMacroList ()
{
	Class'MacroAPI'.RequestMacroList();
}

function HandleMacroShowListWnd ()
{
	if ( m_bShow )
	{
		PlayConsoleSound(6);
		Class'UIAPI_WINDOW'.HideWindow("MacroListWnd");
	} else {
		PlayConsoleSound(5);
		Class'UIAPI_WINDOW'.ShowWindow("MacroListWnd");
		Class'UIAPI_WINDOW'.SetFocus("MacroListWnd");
	}
}

function Clear ()
{
	Class'UIAPI_ITEMWINDOW'.Clear("MacroListWnd.MacroItem");
}

function unkFunc ()
{
	local int idx;

	idx = unkInt4;
	if ( LessThan(idx,unkInt2) )
	{
		WndHandle.KillTimer(idx);
		IntIncrement(idx);
		goto JL000B;
	}
	arrInt1.Length = unkInt4;
	arrInt2.Length = unkInt4;
	arrStr.Length = unkInt4;
	reqMacroList();
}

function HandleMacroList (string param)
{
	local int idx;
	local int unkLocInt1;
	local int MacroID;
	local string strIconName;
	local string strMacroName;
	local string strDescription;
	local string unkLocStr1;
	local string strTmp;
	local ItemInfo ItemInfo;
	local int unkLocInt2;

	curMacroShortcutId = 0;
	Clear();
	ParseInt(param,"Max",unkLocInt1);
	m_Max = unkLocInt1;
	idx = unkInt4;
	if ( LessThan(idx,unkLocInt1) )
	{
		MacroID = unkInt4;
		strIconName = unkStr5;
		strMacroName = unkStr5;
		strDescription = unkStr5;
		unkLocStr1 = unkStr5;
		ParseInt(param,StrCat("ID_",string(idx)),MacroID);
		ParseString(param,StrCat("IconName_",string(idx)),strIconName);
		ParseString(param,StrCat("MacroName_",string(idx)),strMacroName);
		ParseString(param,StrCat("Description_",string(idx)),strDescription);
		ParseString(param,StrCat("TextureName_",string(idx)),unkLocStr1);
		ItemInfo.ClassID = MacroID;
		ItemInfo.Name = strMacroName;
		ItemInfo.AdditionalName = strIconName;
		ItemInfo.IconName = unkLocStr1;
		ItemInfo.Description = strDescription;
		ItemInfo.ItemSubType = 4;
		if ( Equals(ItemInfo.ClassID,unkInt1) )
		{
			ItemInfo.ForeTexture = unkStr4;
		} else {
			ItemInfo.ForeTexture = unkStr5;
		}
		if ( StrEquals(unkLocStr1,unkStr5) )
		{
			unkLocInt2 = GetMacroNum(ItemInfo.Name);
			if ( GreaterThan(unkLocInt2,unkInt3) )
			{
				ItemInfo.IconName = StrCat("L2UI.Macro_Icon",string(unkLocInt2));
			}
		}
		Class'UIAPI_ITEMWINDOW'.AddItem("MacroListWnd.MacroItem",ItemInfo);
		IntIncrement(idx);
		AddInventoryMacroShortcut(ItemInfo);
		goto JL0038;
	}
	if ( LessThan(unkLocInt1,10) )
	{
		strTmp = StrCat(strTmp,"0");
	}
	strTmp = StrCat(strTmp,string(unkLocInt1));
	strTmp = StrCat(StrCat(StrCat(StrCat("(",strTmp),"/"),string(24)),")");
	Class'UIAPI_TEXTBOX'.SetText("MacroListWnd.txtCount",strTmp);
}

function PrintInventoryMacros ()
{
	local int i;

	i = 0;
	if ( UnknownFunction150(i,macroShortcuts.Length) )
	{
		Debug2(UnknownFunction112(UnknownFunction112(UnknownFunction112(UnknownFunction112(macroShortcuts[i].MacroName,": "),string(macroShortcuts[i].wnd)),"-"),string(macroShortcuts[i].Shortcut)));
		UnknownFunction165(i);
		goto JL0007;
	}
}

function AddInventoryMacroShortcut (ItemInfo macro)
{
	local MacroShortcut MacroShortcut;
	local array<string> slotArray;
	local array<string> shortcutsArray;
	local MacroInfo MacroInfo;
	local int i;
	local string curWnd;
	local string curShortcut;

	Class'UIDATA_MACRO'.GetMacroInfo(macro.ClassID,MacroInfo);
	if ( UnknownFunction132(UnknownFunction129(StartsWith("INV",macro.Name)),UnknownFunction129(StartsWith("/slot",MacroInfo.CommandList[0]))) )
	{
		return;
	}
	Split(MacroInfo.CommandList[0]," ",slotArray);
	i = 1;
	if ( UnknownFunction150(i,slotArray.Length) )
	{
		curWnd = UnknownFunction127(slotArray[i],0,2);
		curShortcut = UnknownFunction127(slotArray[i],2,2);
		MacroShortcut.MacroName = macro.Name;
		MacroShortcut.MacroID = macro.ClassID;
		MacroShortcut.wnd = int(curWnd);
		MacroShortcut.Shortcut = int(curShortcut);
		macroShortcuts[UnknownFunction165(curMacroShortcutId)] = MacroShortcut;
		UnknownFunction165(i);
		goto JL007B;
	}
}

function OnDropItem (string strID, ItemInfo ItemInfo, int X, int Y)
{
	switch (strID)
	{
		case "BtnTrash":
		DeleteMacro(ItemInfo);
		break;
		case "BtnEdit":
		EditMacro(ItemInfo);
		break;
		default:
	}
}

function OnTimer (int unkLocInt2)
{
	WndHandle.KillTimer(unkLocInt2);
	if ( Equals(arrInt1[unkLocInt2],unkInt4) )
	{
		ExecuteCommand(arrStr[unkLocInt2]);
		if ( LogicalOR(NotEquals(arrStr[DoAdd(unkLocInt2,unkInt5)],unkStr5),IntNotEquals(arrInt1[DoAdd(unkLocInt2,unkInt5)],unkInt4)) )
		{
			WndHandle.SetTimer(DoAdd(unkLocInt2,unkInt5),unkInt6);
		} else {
			WndHandle.SetTimer(unkInt4,unkInt6);
		}
	} else {
		WndHandle.SetTimer(DoAdd(unkLocInt2,unkInt5),IntMul(arrInt2[unkLocInt2],unkInt6));
	}
}

function DeleteMacro (ItemInfo ItemInfo)
{
	local string strMsg;

	if ( IntNotEquals(ItemInfo.ItemSubType,4) )
	{
		return;
	}
	strMsg = MakeFullSystemMsg(GetSystemMessage(828),ItemInfo.Name,unkStr5);
	m_DeleteID = ItemInfo.ClassID;
	DialogShow(4,strMsg);
	if ( Equals(ItemInfo.ClassID,unkInt1) )
	{
		unkFunc();
	}
}

function EditMacro (ItemInfo ItemInfo)
{
	local int MacroID;
	local string param;

	if ( NotBool(Class'UIAPI_WINDOW'.IsShowWindow("MacroEditWnd")) )
	{
		Class'UIAPI_WINDOW'.ShowWindow("MacroEditWnd");
	}
	if ( IntNotEquals(ItemInfo.ItemSubType,4) )
	{
		return;
	}
	MacroID = ItemInfo.ClassID;
	ParamAdd(param,"MacroID",string(MacroID));
	ExecuteEvent(1260,param);
}

function bool HandleInventoryMacro (string Shortcut)
{
	local array<string> arr;
	local int i;
	local int wnd;
	local int sct;

	Split(Shortcut," ",arr);
	wnd = int(arr[0]);
	sct = int(arr[1]);
	i = 0;
	if ( UnknownFunction150(i,macroShortcuts.Length) )
	{
		if ( UnknownFunction130(UnknownFunction154(macroShortcuts[i].wnd,wnd),UnknownFunction154(macroShortcuts[i].Shortcut,sct)) )
		{
			AutoSkillWnd(GetScript("AutoSkillWnd")).(macroShortcuts[i].MacroID);
			return True;
		}
		UnknownFunction165(i);
		goto JL0038;
	}
	return False;
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.TxtHead");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.TxtCount");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.MacroItem");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.BtnAdd");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.BtnHelp");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.BtnEdit");
	Class'UIAPI_WINDOW'.SetFocus("MacroListWnd.BtnTrash");
}


//================================================================================
// NPHRN_PlayerSkillGauge.
//================================================================================

class NPHRN_PlayerSkillGauge extends UICommonAPI;

var int m_UserID;
var StatusWnd dlgBox;
var WindowHandle Me;
var TextureHandle texHandle1;
var TextBoxHandle TextBoxHandle;
var float F;
var bool idx;

function OnLoad ()
{
	unkFunc4();
	OnRegisterEvent();
}

function unkFunc4 ()
{
	Me = GetHandle("NPHRN_PlayerSkillGauge");
	texHandle1 = TextureHandle(GetHandle("NPHRN_PlayerSkillGauge.Slider.Substrate"));
	TextBoxHandle = TextBoxHandle(GetHandle("NPHRN_PlayerSkillGauge.Slider.Title"));
	dlgBox = StatusWnd(GetScript("StatusWnd"));
}

function OnRegisterEvent ()
{
	RegisterEvent(150);
	RegisterEvent(290);
	RegisterEvent(50);
	RegisterEvent(2960);
	RegisterEvent(580);
}

function OnEvent (int EventID, string idx)
{
	local int Lm_UserID1;
	local int Lm_UserID2;

	switch (EventID)
	{
		case 150:
		Me.SetTimer(1,1000);
		break;
		case 290:
		if ( BoolEquals(GetOptionBool("Custom","SkillCastingBox"),True) )
		{
			ParseInt(idx,"AttackerID",Lm_UserID1);
			if ( Equals(Lm_UserID1,m_UserID) )
			{
				sdfhserheawrhawh(idx);
			}
		}
		break;
		case 580:
		ParseInt(idx,"Index",Lm_UserID2);
		if ( IntNotEquals(Lm_UserID2,27) )
		{
			return;
		}
		case 2960:
		case 50:
		Me.HideWindow();
		break;
		default:
	}
}

function sdfhserheawrhawh (string strParam)
{
	local int f_IntINC;
	local SkillInfo SkillInfo;
	local UserInfo UserInfo;
	local float f1;
	local float f2;

	ParseInt(strParam,"SkillID",f_IntINC);
	if ( LogicalOR(idx,unkIDSFunc(f_IntINC)) )
	{
		if ( unkSkillFunc3(f_IntINC) )
		{
			F = 0.1;
		}
		return;
	}
	if ( GetSkillInfo(f_IntINC,1,SkillInfo) )
	{
		idx = True;
		Me.ShowWindow();
		TextBoxHandle.SetText(SkillInfo.SkillName);
		if ( GetPlayerInfo(UserInfo) )
		{
			if ( Equals(SkillInfo.IsMagic,1) )
			{
				f2 = FloatDiv(UserInfo.nMagicCastingSpeed,1000.0);
				FloatParamAdd(f2,F);
			} else {
				f2 = FloatDiv(UserInfo.nPhysicalAttackSpeed,1000.0);
			}
			F = 0.0;
		}
		f1 = FloatSub(SkillInfo.HitTime,FloatMul(f2,FloatDiv(SkillInfo.HitTime,1.5)));
		if ( FloatLessThan(f1,0.5) )
		{
			f1 = FloatDiv(SkillInfo.HitTime,6.0);
		}
		texHandle1.Move(205,0,f1);
		Me.SetTimer(2,DoAdd(int(FloatMul(f1,1000.0)),300));
	}
}

function OnTimer (int TimerID)
{
	switch (TimerID)
	{
		case 2:
		Me.KillTimer(2);
		asdfhashawsh();
		break;
		case 1:
		Me.KillTimer(1);
		m_UserID = dlgBox.m_UserID;
		break;
		default:
	}
}

function asdfhashawsh ()
{
	local Rect Rect;

	Rect = Me.GetRect();
	texHandle1.MoveTo(IntSub(Rect.nX,24),Rect.nY);
	Me.HideWindow();
	idx = False;
}

function bool unkIDSFunc (int f_IntINC)
{
	local bool locBool1;

	locBool1 = False;
	switch (f_IntINC)
	{
		case 2039:
		case 2150:
		case 2151:
		case 2152:
		case 2153:
		case 2154:
		case 2047:
		case 2155:
		case 2156:
		case 2157:
		case 2158:
		case 2159:
		case 2061:
		case 2160:
		case 2161:
		case 2162:
		case 2163:
		case 2164:
		case 26060:
		case 26061:
		case 26062:
		case 26063:
		case 26064:
		case 22036:
		case 22037:
		case 22038:
		case 2033:
		case 2008:
		case 2009:
		case 26050:
		case 26051:
		case 26052:
		case 26053:
		case 26054:
		case 26055:
		case 26056:
		case 26057:
		case 26058:
		case 26059:
		case 22369:
		case 2498:
		case 2499:
		case 2359:
		case 2166:
		case 2034:
		case 2037:
		case 2035:
		case 2036:
		case 2011:
		case 2032:
		case 2864:
		case 2398:
		case 2402:
		case 2403:
		case 2395:
		case 2401:
		case 2169:
		case 2397:
		case 2396:
		case 2012:
		case 2074:
		case 2077:
		case 2592:
		case 2038:
		case 2627:
		case 2289:
		case 2287:
		case 2288:
		case 2169:
		case 2076:
		case 22042:
		case 2903:
		case 2901:
		case 2900:
		case 2902:
		case 2897:
		case 22029:
		case 2899:
		case 22031:
		case 22164:
		case 2898:
		case 22030:
		case 22163:
		case 22162:
		case 22158:
		case 2282:
		case 2283:
		case 2284:
		case 2514:
		case 2513:
		case 2244:
		case 2278:
		case 2485:
		case 2247:
		case 2281:
		case 2486:
		case 2245:
		case 2279:
		case 2246:
		case 2280:
		case 2285:
		case 2512:
		case 2580:
		locBool1 = True;
		break;
		default:
	}
	return locBool1;
}

function bool unkSkillFunc3 (int f_IntINC)
{
	local bool locBool1;

	locBool1 = False;
	switch (f_IntINC)
	{
		case 2039:
		case 2150:
		case 2151:
		case 2152:
		case 2153:
		case 2154:
		case 2047:
		case 2155:
		case 2156:
		case 2157:
		case 2158:
		case 2159:
		case 2061:
		case 2160:
		case 2161:
		case 2162:
		case 2163:
		case 2164:
		case 26060:
		case 26061:
		case 26062:
		case 26063:
		case 26064:
		case 26050:
		case 26051:
		case 26052:
		case 26053:
		case 26054:
		case 26055:
		case 26056:
		case 26057:
		case 26058:
		case 26059:
		case 22369:
		locBool1 = True;
		break;
		default:
	}
	return locBool1;
}


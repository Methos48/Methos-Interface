//================================================================================
// LoginMenuWnd.
//================================================================================

class LoginMenuWnd extends UICommonAPI;

function OnShow ()
{
	HideWindow("LoginFunctionWnd");
}

function OnClickButton (string a_ButtonID)
{
	switch (a_ButtonID)
	{
		case "btnOption":
		onOption();
		break;
		case "btnCredit":
		onCredit();
		break;
		case "btnReplay":
		onReplay();
		break;
		default:
	}
}

function onOption ()
{
	if ( IsShowWindow("OptionWnd") )
	{
		PlayConsoleSound(6);
		HideWindow("OptionWnd");
	} else {
		PlayConsoleSound(5);
		ShowWindowWithFocus("OptionWnd");
	}
}

function onCredit ()
{
	SetUIState("CreditState");
}

function onReplay ()
{
	SetUIState("ReplaySelectState");
}


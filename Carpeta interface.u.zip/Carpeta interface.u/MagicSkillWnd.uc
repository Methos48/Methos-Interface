//================================================================================
// MagicSkillWnd.
//================================================================================

class MagicSkillWnd extends UICommonAPI;

var bool m_bShow;
var string m_WindowName;
const Skill_MAX_COUNT= 24;

function OnLoad ()
{
	RegisterEvent(1280);
	RegisterEvent(1290);
	RegisterEvent(1900);
	m_bShow = False;
}

function OnShow ()
{
	RequestSkillList();
	m_bShow = True;
	SetFocus();
}

function OnHide ()
{
	m_bShow = False;
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,1280) )
	{
		HandleSkillListStart();
	} else {
		if ( UnknownFunction154(Event_ID,1290) )
		{
			HandleSkillList(param);
		} else {
			if ( UnknownFunction154(Event_ID,1900) )
			{
				HandleLanguageChanged();
			}
		}
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "BtnClose":
		HideWindow("MagicSkillWnd");
		break;
		default:
	}
}

function OnClickItem (string strID, int Index)
{
	local ItemInfo infItem;

	if ( UnknownFunction130(UnknownFunction122(strID,"SkillItem"),UnknownFunction151(Index,-1)) )
	{
		if ( Class'UIAPI_ITEMWINDOW'.GetItem(UnknownFunction112(m_WindowName,".ASkill.SkillItem"),Index,infItem) )
		{
			UseSkill(infItem.ClassID);
		}
	}
}

function HandleLanguageChanged ()
{
	RequestSkillList();
}

function HandleSkillListStart ()
{
	Clear();
}

function Clear ()
{
	Class'UIAPI_ITEMWINDOW'.Clear(UnknownFunction112(m_WindowName,".ASkill.SkillItem"));
	Class'UIAPI_ITEMWINDOW'.Clear(UnknownFunction112(m_WindowName,".PSkill.PItemWnd"));
}

function HandleSkillList (string param)
{
	local string WndName;
	local int tmp;
	local ESkillCategory Type;
	local int SkillID;
	local int SkillLevel;
	local int Lock;
	local string strIconName;
	local string strSkillName;
	local string strDescription;
	local string strEnchantName;
	local string strCommand;
	local ItemInfo infItem;

	ParseInt(param,"Type",tmp);
	ParseInt(param,"ClassID",SkillID);
	ParseInt(param,"Level",SkillLevel);
	ParseInt(param,"Lock",Lock);
	ParseString(param,"Name",strSkillName);
	ParseString(param,"IconName",strIconName);
	ParseString(param,"Description",strDescription);
	ParseString(param,"EnchantName",strEnchantName);
	ParseString(param,"Command",strCommand);
	infItem.ClassID = SkillID;
	infItem.Level = SkillLevel;
	infItem.Name = strSkillName;
	infItem.AdditionalName = strEnchantName;
	infItem.IconName = strIconName;
	infItem.Description = strDescription;
	infItem.ItemSubType = 2;
	infItem.MacroCommand = strCommand;
	if ( UnknownFunction151(Lock,0) )
	{
		infItem.bIsLock = True;
	} else {
		infItem.bIsLock = False;
	}
	Type = tmp;
	if ( UnknownFunction154(Type,1) )
	{
		WndName = "PSkill.PItemWnd";
	} else {
		WndName = "ASkill.SkillItem";
	}
	Class'UIAPI_ITEMWINDOW'.AddItem(UnknownFunction112(UnknownFunction112(m_WindowName,"."),WndName),infItem);
}

function SetFocus ()
{
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.Container.Tex");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.Slots");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.SkillItem");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.PItemWnd");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.TabCtrl");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.BtnClose");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.SkillItem");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.PItemWnd");
	Class'UIAPI_WINDOW'.SetFocus("MagicSkillWnd.TabCtrl");
}

defaultproperties
{
    m_WindowName="MagicSkillWnd"

}

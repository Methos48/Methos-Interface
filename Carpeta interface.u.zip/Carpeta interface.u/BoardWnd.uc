//================================================================================
// BoardWnd.
//================================================================================

class BoardWnd extends UIScript;

var bool m_bShow;
var bool m_bBtnLock;
var string m_Command[8];

function OnLoad ()
{
	RegisterEvent(1190);
	RegisterEvent(1200);
	m_bShow = False;
	m_bBtnLock = False;
}

function OnShow ()
{
	m_bShow = True;
}

function OnHide ()
{
	m_bShow = False;
}

function OnEvent (int Event_ID, string param)
{
	if ( UnknownFunction154(Event_ID,1190) )
	{
		HandleShowBBS(param);
	} else {
		if ( UnknownFunction154(Event_ID,1200) )
		{
			HandleShowBoardPacket(param);
		}
	}
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnBookmark":
		OnClickBookmark();
		break;
		default:
	}
	if ( UnknownFunction122(UnknownFunction128(strID,7),"TabCtrl") )
	{
		strID = UnknownFunction127(strID,7);
		if ( UnknownFunction129(Class'UIAPI_WINDOW'.IsMinimizedWindow("BoardWnd")) )
		{
			ShowBBSTab(int(strID));
		}
	}
}

function Clear ()
{
}

function HandleShowBBS (string param)
{
	local int Index;
	local int Init;

	ParseInt(param,"Index",Index);
	ParseInt(param,"Init",Init);
	if ( UnknownFunction151(Init,0) )
	{
		if ( m_bShow )
		{
			PlayConsoleSound(6);
			Class'UIAPI_WINDOW'.HideWindow("BoardWnd");
			return;
		} else {
			if ( UnknownFunction129(Class'UIAPI_HTMLCTRL'.IsPageLock("BoardWnd.HtmlViewer")) )
			{
				Class'UIAPI_HTMLCTRL'.SetPageLock("BoardWnd.HtmlViewer",True);
				Class'UIAPI_TABCTRL'.SetTopOrder("BoardWnd.TabCtrl",0,False);
				Class'UIAPI_HTMLCTRL'.Clear("BoardWnd.HtmlViewer");
				RequestBBSBoard();
			}
		}
	} else {
		Class'UIAPI_TABCTRL'.SetTopOrder("BoardWnd.TabCtrl",Index,False);
		Class'UIAPI_HTMLCTRL'.Clear("BoardWnd.HtmlViewer");
		ShowBBSTab(Index);
	}
}

function HandleShowBoardPacket (string param)
{
	local int idx;
	local int OK;
	local string Address;

	ParseInt(param,"OK",OK);
	if ( UnknownFunction150(OK,1) )
	{
		Class'UIAPI_WINDOW'.HideWindow("BoardWnd");
		return;
	}
JL0041:
	idx = 0;
	if ( UnknownFunction150(idx,8) )
	{
		m_Command[idx] = "";
		UnknownFunction165(idx);
		goto JL0041;
	}
	ParseString(param,"Command1",m_Command[0]);
	ParseString(param,"Command2",m_Command[1]);
	ParseString(param,"Command3",m_Command[2]);
	ParseString(param,"Command4",m_Command[3]);
	ParseString(param,"Command5",m_Command[4]);
	ParseString(param,"Command6",m_Command[5]);
	ParseString(param,"Command7",m_Command[6]);
	ParseString(param,"Command8",m_Command[7]);
	m_bBtnLock = False;
	ParseString(param,"Address",Address);
	Class'UIAPI_HTMLCTRL'.SetHtmlBuffData("BoardWnd.HtmlViewer",Address);
	if ( UnknownFunction129(m_bShow) )
	{
		PlayConsoleSound(5);
		Class'UIAPI_WINDOW'.ShowWindow("BoardWnd");
		Class'UIAPI_WINDOW'.SetFocus("BoardWnd");
	}
}

function ShowBBSTab (int Index)
{
	local string strBypass;
	local EControlReturnType Ret;

	switch (Index)
	{
		case 0:
		strBypass = "bypass _bbshome";
		break;
		case 1:
		strBypass = "bypass _bbsgetfav";
		break;
		case 2:
		strBypass = "bypass _bbsloc";
		break;
		case 3:
		strBypass = "bypass _bbsclan";
		break;
		case 4:
		strBypass = "bypass _bbsmemo";
		break;
		case 5:
		strBypass = "bypass _maillist_0_1_0_";
		break;
		case 6:
		strBypass = "bypass _friendlist_0_";
		break;
		default:
	}
	if ( UnknownFunction151(UnknownFunction125(strBypass),0) )
	{
		Ret = Class'UIAPI_HTMLCTRL'.ControllerExecution("BoardWnd.HtmlViewer",strBypass);
		if ( UnknownFunction154(Ret,1) )
		{
			m_bBtnLock = True;
		}
	}
}

function OnClickBookmark ()
{
	local EControlReturnType Ret;

	if ( UnknownFunction130(UnknownFunction151(UnknownFunction125(m_Command[7]),0),UnknownFunction129(m_bBtnLock)) )
	{
		Ret = Class'UIAPI_HTMLCTRL'.ControllerExecution("BoardWnd.HtmlViewer",m_Command[7]);
		if ( UnknownFunction154(Ret,1) )
		{
			m_bBtnLock = True;
		}
	}
}


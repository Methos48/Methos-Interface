//================================================================================
// TownMapWnd.
//================================================================================

class TownMapWnd extends UIScript;

function OnLoad ()
{
	RegisterEvent(1770);
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 1770:
		HandleShowTownMap(a_Param);
		break;
		default:
	}
}

function HandleShowTownMap (string a_Param)
{
	local string strTownMapName;
	local int UserPosX;
	local int UserPosY;

	if ( ParseString(a_Param,"TownMapName",strTownMapName) )
	{
		Class'UIAPI_TEXTURECTRL'.SetTexture("TownMapWnd.TownMapTex",strTownMapName);
		Class'UIAPI_TEXTURECTRL'.SetUV("TownMapWnd.TownMapTex",0,0);
	}
	if ( UnknownFunction130(ParseInt(a_Param,"UserPosX",UserPosX),ParseInt(a_Param,"UserPosY",UserPosY)) )
	{
		Class'UIAPI_WINDOW'.SetAnchor("TownMapWnd.UserTex","TownMapWnd.TownMapTex","TopLeft","TopLeft",UserPosX,UserPosY);
	}
	Class'UIAPI_WINDOW'.ShowWindow("TownMapWnd");
}


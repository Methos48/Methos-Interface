//================================================================================
// InterfaceAI_MainWnd.
//================================================================================

class InterfaceAI_MainWnd extends UICommonAPI;

var WindowHandle Me;
var ButtonHandle btn_Timer;
var ButtonHandle btn_Enchant;
var ButtonHandle btn_LifeStone;
var ButtonHandle btn_Skill;
var ButtonHandle btnOptions;
var bool ShowEffect;
const TIMER_DELAY2=100;
const TIMER_DELAY=100;
const TIMER_ID2=9801;
const TIMER_ID=9800;

function OnLoad ()
{
	RegisterEvents();
	InitHandle();
	LoadData();
}

function RegisterEvents ()
{
	RegisterEvent(19000);
}

function LoadData ()
{
	btn_Timer.SetTooltipCustomType(SetTooltip("Timer"));
	btn_Enchant.SetTooltipCustomType(SetTooltip("Automatic Enchant Items"));
	btn_LifeStone.SetTooltipCustomType(SetTooltip("Automatic Augmentation"));
	btn_Skill.SetTooltipCustomType(SetTooltip("Automatic Enchant Skills"));
	btnOptions.SetTooltipCustomType(SetTooltip("Options"));
}

function InitHandle ()
{
	Me = GetHandle("InterfaceAI_MainWnd");
	btn_Timer = ButtonHandle(GetHandle("InterfaceAI_MainWnd.btnMenuTimer"));
	btn_Enchant = ButtonHandle(GetHandle("InterfaceAI_MainWnd.btnMenuScroll"));
	btn_LifeStone = ButtonHandle(GetHandle("InterfaceAI_MainWnd.btnMenuLS"));
	btn_Skill = ButtonHandle(GetHandle("InterfaceAI_MainWnd.btnMenuSkill"));
	btnOptions = ButtonHandle(GetHandle("InterfaceAI_MainWnd.btnOptions"));
}

function OnClickButton (string strID)
{
	switch (strID)
	{
		case "btnMenuScroll":
		ShowAutomatic(0);
		break;
		case "btnMenuLS":
		ShowAutomatic(1);
		break;
		case "btnMenuSkill":
		ShowAutomatic(2);
		break;
		case "btnMenuTimer":
		OnClickTimer();
		break;
		default:
	}
}

function OnClickTimer ()
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("InterfaceAI_TimerWnd") )
	{
		Class'UIAPI_WINDOW'.HideWindow("InterfaceAI_TimerWnd");
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("InterfaceAI_TimerWnd");
	}
}

function ShowAutomatic (int Type)
{
	if ( Class'UIAPI_WINDOW'.IsShowWindow("EnchantAIWnd") )
	{
		if ( UnknownFunction154(Class'UIAPI_TABCTRL'.GetTopIndex("EnchantAIWnd.TabEnchant"),Type) )
		{
			Class'UIAPI_WINDOW'.HideWindow("EnchantAIWnd");
		} else {
			Class'UIAPI_TABCTRL'.SetTopOrder("EnchantAIWnd.TabEnchant",Type,True);
		}
	} else {
		Class'UIAPI_WINDOW'.ShowWindow("EnchantAIWnd");
		Class'UIAPI_TABCTRL'.SetTopOrder("EnchantAIWnd.TabEnchant",Type,True);
	}
}

function CustomTooltip SetTooltip (string Text)
{
	local CustomTooltip ToolTip;
	local DrawItemInfo Info;

	ToolTip.DrawList.Length = 1;
	Info.eType = 1;
	Info.t_strText = Text;
	ToolTip.DrawList[0] = Info;
	return ToolTip;
}


//================================================================================
// StartWnd.
//================================================================================

class StartWnd extends UICommonAPI;

var bool SHOW_PICTURE;
var WindowHandle Me;
const TIME_HIDE= 1800000;
const TIME_SHOW= 15000;
const TIMER_ID=9379;

function OnLoad ()
{
	RegisterEvent(150);
	Me = GetHandle("StartWnd");
}

function OnEvent (int a_EventID, string a_Param)
{
	switch (a_EventID)
	{
		case 150:
		if ( UnknownFunction243(GetSuperRaceShop(),True) )
		{
			SHOW_PICTURE = True;
			celestine();
		}
		break;
		default:
	}
}

function Reset ()
{
}

function OnHide ()
{
}

function celestine ()
{
	if ( SHOW_PICTURE )
	{
		SHOW_PICTURE = False;
		Class'UIAPI_WINDOW'.KillUITimer("StartWnd",9379);
		Class'UIAPI_WINDOW'.SetUITimer("StartWnd",9379,15000);
		ShowWindow("StartWnd");
		Class'UIAPI_WINDOW'.SetFocus("StartWnd");
	} else {
		SHOW_PICTURE = True;
		Class'UIAPI_WINDOW'.KillUITimer("StartWnd",9379);
		Class'UIAPI_WINDOW'.SetUITimer("StartWnd",9379,1800000);
		HideWindow("StartWnd");
	}
}

function OnTimer (int TimerID)
{
	if ( UnknownFunction154(TimerID,9379) )
	{
		celestine();
	}
}


//================================================================================
// ManorCropSellWnd.
//================================================================================

class ManorCropSellWnd extends UICommonAPI;

const COLUMN_CNT=10;
const REWARD_TYPE_2=9;
const REWARD_TYPE_1=8;
const CROP_LEVEL=7;
const SELL_CNT=6;
const MY_CROP_CNT=5;
const PROCURE_TYPE=4;
const CROP_PRICE=3;
const CROP_REMAIN_CNT=2;
const MANOR_NAME=1;
const CROP_NAME=0;

function OnLoad ()
{
	RegisterEvent(2640);
	RegisterEvent(2645);
	RegisterEvent(2646);
}

function OnEvent (int Event_ID, string a_Param)
{
	switch (Event_ID)
	{
		case 2640:
		if ( IsShowWindow("ManorCropSellWnd") )
		{
			HideWindow("ManorCropSellWnd");
		} else {
			DeleteAll();
			ShowWindowWithFocus("ManorCropSellWnd");
		}
		break;
		case 2645:
		HandleAddItem(a_Param);
		break;
		case 2646:
		HandleSetCropSell(a_Param);
		break;
		default:
	}
}

function DeleteAll ()
{
	Class'UIAPI_LISTCTRL'.DeleteAllItem("ManorCropSellWnd.ManorCropSellListCtrl");
}

function OnDBClickListCtrlRecord (string strID)
{
	switch (strID)
	{
		case "ManorCropSellListCtrl":
		OnChangeBtn();
		break;
		default:
	}
}

function OnClickButton (string strID)
{
	Debug(UnknownFunction112(" ",strID));
	switch (strID)
	{
		case "btnChangeSell":
		OnChangeBtn();
		break;
		case "btnSell":
		OnSellBtn();
		break;
		case "btnCancel":
		HideWindow("ManorCropSellWnd");
		break;
		default:
	}
}

function OnSellBtn ()
{
	local int RecordCount;
	local LVDataRecord Record;
	local int SellCnt;
	local int CropCnt;
	local int CropNum;
	local int i;
	local string param;

	RecordCount = Class'UIAPI_LISTCTRL'.GetRecordCount("ManorCropSellWnd.ManorCropSellListCtrl");
	CropCnt = 0;
	i = 0;
	if ( UnknownFunction150(i,RecordCount) )
	{
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropSellWnd.ManorCropSellListCtrl",i);
		SellCnt = int(Record.LVDataList[6].szData);
		if ( UnknownFunction151(SellCnt,0) )
		{
			UnknownFunction165(CropCnt);
		}
		UnknownFunction163(i);
		goto JL004B;
	}
	ParamAdd(param,"CropCnt",string(CropCnt));
	CropNum = 0;
	i = 0;
	if ( UnknownFunction150(i,RecordCount) )
	{
		Record = Class'UIAPI_LISTCTRL'.GetRecord("ManorCropSellWnd.ManorCropSellListCtrl",i);
		SellCnt = int(Record.LVDataList[6].szData);
		if ( UnknownFunction152(SellCnt,0) )
		{
			goto JL022B;
		}
		ParamAdd(param,UnknownFunction112("CropServerID",string(CropNum)),string(Record.nReserved3));
		ParamAdd(param,UnknownFunction112("CropID",string(CropNum)),string(Record.nReserved2));
		ParamAdd(param,UnknownFunction112("ManorID",string(CropNum)),string(Record.nReserved1));
		ParamAdd(param,UnknownFunction112("SellCount",string(CropNum)),Record.LVDataList[6].szData);
		UnknownFunction165(CropNum);
		UnknownFunction163(i);
		goto JL00FB;
	}
	RequestProcureCropList(param);
	HideWindow("ManorCropSellWnd");
}

function OnChangeBtn ()
{
	local LVDataRecord Record;
	local int SelectedIndex;
	local int CropID;
	local string ManorCropSellChangeWndString;
	local string param;

	SelectedIndex = Class'UIAPI_LISTCTRL'.GetSelectedIndex("ManorCropSellWnd.ManorCropSellListCtrl");
	if ( UnknownFunction154(SelectedIndex,-1) )
	{
		return;
	}
	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorCropSellWnd.ManorCropSellListCtrl");
	CropID = Record.nReserved2;
	ManorCropSellChangeWndString = UnknownFunction112(UnknownFunction112("manor_menu_select?ask=9&state=",string(CropID)),"&time=0");
	RequestBypassToServer(ManorCropSellChangeWndString);
	ParamAdd(param,"CropName",Record.LVDataList[0].szData);
	ParamAdd(param,"RewardType1",Record.LVDataList[8].szData);
	ParamAdd(param,"RewardType2",Record.LVDataList[9].szData);
	ExecuteEvent(2649,param);
}

function HandleAddItem (string a_Param)
{
	local LVDataRecord Record;
	local string CropName;
	local string ManorName;
	local int CropRemainCnt;
	local int CropPrice;
	local int ProcureType;
	local int MyCropCnt;
	local int CropLevel;
	local string RewardType1;
	local string RewardType2;
	local int ManorID;
	local int CropID;
	local int CropServerID;

	Record.LVDataList.Length = 10;
	ParseString(a_Param,"CropName",CropName);
	ParseString(a_Param,"ManorName",ManorName);
	ParseInt(a_Param,"CropRemainCnt",CropRemainCnt);
	ParseInt(a_Param,"CropPrice",CropPrice);
	ParseInt(a_Param,"ProcureType",ProcureType);
	ParseInt(a_Param,"MyCropCnt",MyCropCnt);
	ParseInt(a_Param,"CropLevel",CropLevel);
	ParseString(a_Param,"RewardType1",RewardType1);
	ParseString(a_Param,"RewardType2",RewardType2);
	ParseInt(a_Param,"ManorID",ManorID);
	ParseInt(a_Param,"CropID",CropID);
	ParseInt(a_Param,"CropServerID",CropServerID);
	Record.LVDataList[0].szData = CropName;
	Record.LVDataList[1].szData = ManorName;
	Record.LVDataList[2].szData = string(CropRemainCnt);
	Record.LVDataList[3].szData = string(CropPrice);
	Record.LVDataList[4].szData = string(ProcureType);
	Record.LVDataList[5].szData = string(MyCropCnt);
	Record.LVDataList[6].szData = "0";
	Record.LVDataList[7].szData = string(CropLevel);
	Record.LVDataList[8].szData = RewardType1;
	Record.LVDataList[9].szData = RewardType2;
	Record.nReserved1 = ManorID;
	Record.nReserved2 = CropID;
	Record.nReserved3 = CropServerID;
	Class'UIAPI_LISTCTRL'.InsertRecord("ManorCropSellWnd.ManorCropSellListCtrl",Record);
}

function HandleSetCropSell (string a_Param)
{
	local string SellCntString;
	local int ManorID;
	local string ManorName;
	local string CropRemainCntString;
	local string CropPriceString;
	local string ProcureTypeString;
	local int SelectedIndex;
	local LVDataRecord Record;

	ParseString(a_Param,"SellCntString",SellCntString);
	ParseInt(a_Param,"ManorID",ManorID);
	ParseString(a_Param,"ManorName",ManorName);
	ParseString(a_Param,"CropRemainCntString",CropRemainCntString);
	ParseString(a_Param,"CropPriceString",CropPriceString);
	ParseString(a_Param,"ProcureTypeString",ProcureTypeString);
	Record = Class'UIAPI_LISTCTRL'.GetSelectedRecord("ManorCropSellWnd.ManorCropSellListCtrl");
	Record.LVDataList[1].szData = ManorName;
	Record.LVDataList[2].szData = CropRemainCntString;
	Record.LVDataList[3].szData = CropPriceString;
	Record.LVDataList[4].szData = ProcureTypeString;
	Record.LVDataList[6].szData = SellCntString;
	Record.nReserved1 = ManorID;
	SelectedIndex = Class'UIAPI_LISTCTRL'.GetSelectedIndex("ManorCropSellWnd.ManorCropSellListCtrl");
	Class'UIAPI_LISTCTRL'.ModifyRecord("ManorCropSellWnd.ManorCropSellListCtrl",SelectedIndex,Record);
}


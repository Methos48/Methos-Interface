class DamageLite extends UICommonAPI;

var bool Critical;
var WindowHandle OnMsgWnd9;
var int nOption;
var string stringoption;
var bool ManaBurnPending;
var string ManaBurnTargetName;

function OnLoad()
{
	RegisterEvent(580);
	RegisterEvent(40);
	InitHandle();
}

function InitHandle()
{
	OnMsgWnd9 = GetHandle("OnScreenMessageWnd9");
}

function OnEvent(int Event_ID, string a_Param)
{
	switch (Event_ID)
	{
		case 580:
			nOption = Class'NWindow.UIAPI_COMBOBOX'.static.GetSelectedNum("OptionWnd.DamageCB");
			stringoption = Class'NWindow.UIAPI_COMBOBOX'.static.GetString("OptionWnd.DamageCB", nOption);
			if (stringoption == "Top Screen")
			{
				HandleSystemMessage(a_Param);
			}
			break;

		case 40:
			OnMsgWnd9.HideWindow();
			break;

		default:
			break;
	}
}

function OnTimer(int a_TimerID)
{
	switch (a_TimerID)
	{
		case 10:
			OnMsgWnd9.HideWindow();
			OnMsgWnd9.KillTimer(10);
			break;

		case 11:
			ManaBurnPending = false;
			ManaBurnTargetName = "";
			OnMsgWnd9.KillTimer(11);
			break;

		default:
			break;
	}
}

function ShowDmg(string MessageText, string Color)
{
	local string out_Param, ColorR, ColorG, ColorB;

	switch (Color)
	{
		case "White":
			ColorR = "255";
			ColorG = "255";
			ColorB = "255";
			break;

		case "Yellow":
			ColorR = "255";
			ColorG = "255";
			ColorB = "0";
			break;

		case "Red":
			ColorR = "255";
			ColorG = "0";
			ColorB = "0";
			break;

		case "Gold":
			ColorR = "230";
			ColorG = "213";
			ColorB = "164";
			break;

		case "Orange":
			ColorR = "230";
			ColorG = "153";
			ColorB = "77";
			break;

		default:
			break;
	}

	ParamAdd(out_Param, "MsgType", string(1));
	ParamAdd(out_Param, "MsgNo", string(0));
	ParamAdd(out_Param, "WindowType", string(9));
	ParamAdd(out_Param, "FontSize", "24");
	ParamAdd(out_Param, "FontType", string(0));
	ParamAdd(out_Param, "MsgColor", "1");
	ParamAdd(out_Param, "MsgColorR", ColorR);
	ParamAdd(out_Param, "MsgColorG", ColorG);
	ParamAdd(out_Param, "MsgColorB", ColorB);
	ParamAdd(out_Param, "ShadowType", "0");
	ParamAdd(out_Param, "BackgroundType", "0");
	ParamAdd(out_Param, "LifeTime", string(1000));
	ParamAdd(out_Param, "AnimationType", "0");
	ParamAdd(out_Param, "Msg", MessageText);

	ExecuteEvent(140, out_Param);

	OnMsgWnd9.ShowWindow();
	OnMsgWnd9.KillTimer(10);
	OnMsgWnd9.SetTimer(10, 5000);
}

function HandleSystemMessage(string a_Param)
{
	local int Index, Param1;
	local string ParamString1;
	local UserInfo TargetInfo;

	ParseInt(a_Param, "Index", Index);
	ParseInt(a_Param, "Param1", Param1);

	switch (Index)
	{
		case 46:
			ParseString(a_Param, "Param1", ParamString1);
			if (ParamString1 == "Mana Burn")
			{
				ManaBurnPending = true;
				ManaBurnTargetName = "";

				if (GetTargetInfo(TargetInfo))
				{
					ManaBurnTargetName = TargetInfo.Name;
				}

				OnMsgWnd9.KillTimer(11);
				OnMsgWnd9.SetTimer(11, 5000);
			}
			else if (ManaBurnPending)
			{
				ManaBurnPending = false;
				ManaBurnTargetName = "";
				OnMsgWnd9.KillTimer(11);
			}
			break;

		case 139:
		case 43:
		case 158:
		case 1996:
			Resist();
			break;

		case 44:
		case 361:
		case 1280:
			Critical = true;
			break;

		case 35:
		case 1130:
			Damage(string(Param1));
			break;

		case 1867:
			if (ManaBurnPending)
			{
				OnMsgWnd9.SetAnchor("", "TopCenter", "TopCenter", 0, 80);
				OnMsgWnd9.ClearAnchor();

				if (ManaBurnTargetName != "")
				{
					ShowDmg("Tu Quemaste " $ string(Param1) $ " mana a " $ ManaBurnTargetName, "White");
				}
				else
				{
					ShowDmg("You burned " $ string(Param1) $ " mana", "White");
				}

				ManaBurnPending = false;
				ManaBurnTargetName = "";
				OnMsgWnd9.KillTimer(11);
			}
			break;

		default:
			break;
	}
}

function Damage(string DmgText)
{
	OnMsgWnd9.SetAnchor("", "TopCenter", "TopCenter", 0, 80);
	OnMsgWnd9.ClearAnchor();

	if (Critical)
	{
		ShowDmg(DmgText, "Yellow");
	}
	else
	{
		ShowDmg(DmgText, "White");
	}

	Critical = false;
}

function Resist()
{
	OnMsgWnd9.SetAnchor("", "TopCenter", "TopCenter", 0, 150);
	OnMsgWnd9.ClearAnchor();
	ShowDmg("RESISTED", "Red");
}
